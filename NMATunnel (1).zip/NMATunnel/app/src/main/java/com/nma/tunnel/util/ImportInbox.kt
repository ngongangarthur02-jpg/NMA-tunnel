package com.nma.tunnel.util

import android.content.Context
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.io.File

/** Boîte de réception des imports : fichiers .nma ouverts depuis une autre application ou choisis dans le sélecteur. */
object ImportInbox {
    /** Texte à importer (contenu d'un fichier .nma). Lu puis vidé par l'écran principal. */
    var text by mutableStateOf<String?>(null)

    private const val MAX_BYTES = 256 * 1024

    fun fromUri(ctx: Context, uri: Uri) {
        text = try {
            ctx.contentResolver.openInputStream(uri)?.use { input ->
                val out = java.io.ByteArrayOutputStream()
                val buf = ByteArray(8192)
                var total = 0
                while (total <= MAX_BYTES) {
                    val n = input.read(buf)
                    if (n < 0) break
                    out.write(buf, 0, n)
                    total += n
                }
                if (total > MAX_BYTES) "" else String(out.toByteArray(), Charsets.UTF_8)
            } ?: ""
        } catch (e: Exception) {
            ""
        }
    }

    /** Écrit le code dans un fichier « nom.nma » prêt à être partagé. */
    fun writeFile(ctx: Context, name: String, code: String): File {
        val dir = File(ctx.cacheDir, "exports").apply { mkdirs() }
        dir.listFiles()?.forEach { it.delete() }
        val safe = name.replace(Regex("[^A-Za-z0-9._-]"), "_").trim('_').ifBlank { "NMA" }.take(40)
        val f = File(dir, "$safe.nma")
        f.writeText(code, Charsets.UTF_8)
        return f
    }
}
