package com.nma.tunnel

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nma.tunnel.BuildConfig
import com.nma.tunnel.lock.DeviceId
import com.nma.tunnel.settings.AppSettings
import com.nma.tunnel.ui.theme.NmaColors
import com.nma.tunnel.vpn.TunnelState
import com.nma.tunnel.update.Updater
import com.nma.tunnel.util.NetInfo
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import kotlinx.coroutines.launch
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults

@Composable
private fun Card(modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    Column(
        modifier.fillMaxWidth().padding(bottom = 12.dp)
            .background(NmaColors.NavyCard, RoundedCornerShape(14.dp))
            .border(1.dp, NmaColors.NavyBorder, RoundedCornerShape(14.dp))
            .padding(16.dp)
    ) { content() }
}

@Composable
fun MoreScreen(onAdmin: () -> Unit) {
    val ctx = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val myId = remember { runCatching { DeviceId.idString(ctx) }.getOrDefault("") }
    val mode = AppSettings.theme

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Text("More", color = NmaColors.TextPrimary, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
        Spacer(Modifier.height(16.dp))

        // Apparence
        Card {
            Text("Appearance", color = NmaColors.TextPrimary, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("light" to "Light", "dark" to "Dark", "auto" to "Auto").forEach { (k, label) ->
                    val on = mode == k
                    Text(
                        label,
                        color = if (on) Color.White else NmaColors.TextPrimary,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.weight(1f)
                            .background(if (on) NmaColors.Accent else NmaColors.Navy, RoundedCornerShape(10.dp))
                            .border(1.dp, NmaColors.NavyBorder, RoundedCornerShape(10.dp))
                            .clickable { AppSettings.setTheme(ctx, k) }
                            .padding(vertical = 12.dp),
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                }
            }
        }

        // Ma clé publique (ID de l'appareil)
        Card {
            Text("My public key", color = NmaColors.TextPrimary, fontWeight = FontWeight.Bold)
            Text(
                "Envoie cet ID à l'administrateur : il pourra créer des configurations verrouillées que seul ton téléphone peut ouvrir.",
                color = NmaColors.TextSecondary, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp)
            )
            Text(
                myId, color = NmaColors.Accent, fontSize = 11.sp, maxLines = 4,
                modifier = Modifier.fillMaxWidth().padding(top = 10.dp)
                    .background(NmaColors.Navy, RoundedCornerShape(10.dp)).padding(10.dp)
            )
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedButton(onClick = { clipboard.setText(AnnotatedString(myId)) }, modifier = Modifier.weight(1f)) {
                    Text("Copier", color = NmaColors.Accent)
                }
                OutlinedButton(
                    onClick = {
                        val send = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"; putExtra(Intent.EXTRA_TEXT, myId)
                        }
                        ctx.startActivity(Intent.createChooser(send, "Partager mon ID"))
                    },
                    modifier = Modifier.weight(1f)
                ) { Text("Partager", color = NmaColors.Accent) }
            }
        }

        // Host pot : partage de la connexion VPN par proxy
        Card {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Host pot (partager le VPN)", color = NmaColors.TextPrimary, fontWeight = FontWeight.Bold)
                    Text(
                        "Quand le VPN est actif, les autres appareils l'utilisent via un proxy sur ce téléphone. L'adresse s'affiche sur l'écran Home.",
                        color = NmaColors.TextSecondary, fontSize = 12.sp
                    )
                }
                Switch(
                    checked = AppSettings.hotspotOn,
                    onCheckedChange = { AppSettings.setHotspot(ctx, it) },
                    colors = SwitchDefaults.colors(checkedTrackColor = NmaColors.Accent)
                )
            }
            if (AppSettings.hotspotOn && TunnelState.status != TunnelState.Status.DISCONNECTED) {
                Text(
                    "Déconnecte puis reconnecte le VPN pour appliquer ce changement.",
                    color = NmaColors.Warn, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp)
                )
            }
        }

        UpdateCard()

        Row(
            Modifier.fillMaxWidth().padding(bottom = 12.dp)
                .background(NmaColors.NavyCard, RoundedCornerShape(14.dp))
                .border(1.dp, NmaColors.NavyBorder, RoundedCornerShape(14.dp))
                .clickable { onAdmin() }.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Filled.Lock, null, tint = NmaColors.Accent)
            Spacer(Modifier.width(12.dp))
            Text("Espace admin (configurations verrouillées)", color = NmaColors.TextPrimary, modifier = Modifier.weight(1f))
            Icon(Icons.Filled.ChevronRight, null, tint = NmaColors.TextSecondary)
        }

        Card { Text("À propos de NMA Tunnel", color = NmaColors.TextPrimary) }
        Card { Text("Version 1.3", color = NmaColors.TextPrimary) }
    }
}


@Composable
fun UpdateCard() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var msg by androidx.compose.runtime.remember { mutableStateOf<String?>(null) }
    Card {
        Text("Check update", color = NmaColors.TextPrimary, fontWeight = FontWeight.Bold)
        Text("Version installée : ${BuildConfig.VERSION_NAME}", color = NmaColors.TextSecondary, fontSize = 12.sp)
        Spacer(Modifier.height(8.dp))
        when (Updater.phase) {
            Updater.Phase.CHECKING -> Text("Vérification…", color = NmaColors.TextSecondary)
            Updater.Phase.UP_TO_DATE -> Text("Tu as la dernière version ✓", color = NmaColors.Connected)
            Updater.Phase.AVAILABLE, Updater.Phase.READY -> {
                Text("Nouvelle version ${Updater.latest} disponible", color = NmaColors.Accent, fontWeight = FontWeight.Bold)
                if (Updater.notes.isNotEmpty()) {
                    Text(Updater.notes, color = NmaColors.TextSecondary, fontSize = 12.sp, maxLines = 6,
                        modifier = Modifier.padding(top = 4.dp))
                }
                Spacer(Modifier.height(8.dp))
                Button(
                    onClick = {
                        if (Updater.phase == Updater.Phase.READY) msg = Updater.install(ctx)
                        else scope.launch { Updater.download(ctx) }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = NmaColors.Accent),
                    modifier = Modifier.fillMaxWidth()
                ) { Text(if (Updater.phase == Updater.Phase.READY) "Installer" else "Télécharger et installer", color = Color.White) }
            }
            Updater.Phase.DOWNLOADING -> {
                Text("Téléchargement… ${Updater.progress}%", color = NmaColors.TextSecondary)
                LinearProgressIndicator(
                    progress = { Updater.progress / 100f },
                    color = NmaColors.Accent,
                    modifier = Modifier.fillMaxWidth().padding(top = 6.dp)
                )
            }
            Updater.Phase.ERROR -> Text(Updater.error, color = NmaColors.Error, fontSize = 13.sp)
            Updater.Phase.IDLE -> {}
        }
        msg?.let { Text(it, color = NmaColors.Warn, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp)) }
        if (Updater.phase != Updater.Phase.DOWNLOADING) {
            OutlinedButton(
                onClick = { msg = null; scope.launch { Updater.check() } },
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
            ) { Text("Vérifier les mises à jour", color = NmaColors.Accent) }
        }
    }
}
