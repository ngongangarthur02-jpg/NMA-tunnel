package com.nma.tunnel.util

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.compose.runtime.mutableStateListOf
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.nma.tunnel.MainActivity
import com.nma.tunnel.settings.AppSettings
import org.json.JSONArray
import org.json.JSONObject

/** Notification reçue de l'application : mise à jour, message d'une configuration, expiration, arrêt du VPN… */
data class Notif(val id: Long, val time: Long, val title: String, val text: String, val read: Boolean)

/**
 * Boîte de réception des notifications (visible dans Settings) + notification Android facultative.
 * Une même information (même « clé ») n'est signalée qu'une seule fois.
 */
object NotifStore {
    private const val PREFS = "nma_notifs"
    private const val CHANNEL = "nma_info"
    private const val MAX_ITEMS = 60

    val items = mutableStateListOf<Notif>()
    val unread: Int get() = items.count { !it.read }

    private var loaded = false
    private val keys = LinkedHashSet<String>()

    private fun prefs(ctx: Context) =
        ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    @Synchronized
    fun load(ctx: Context) {
        if (loaded) return
        loaded = true
        val p = prefs(ctx)
        try {
            val arr = JSONArray(p.getString("items", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                items.add(Notif(o.getLong("id"), o.getLong("t"), o.getString("title"), o.getString("text"), o.optBoolean("r", false)))
            }
            val k = JSONArray(p.getString("keys", "[]"))
            for (i in 0 until k.length()) keys.add(k.getString(i))
        } catch (e: Exception) {
            // données illisibles : on repart d'une boîte vide
        }
    }

    private fun save(ctx: Context) {
        val arr = JSONArray()
        items.forEach {
            arr.put(JSONObject().put("id", it.id).put("t", it.time).put("title", it.title).put("text", it.text).put("r", it.read))
        }
        prefs(ctx).edit()
            .putString("items", arr.toString())
            .putString("keys", JSONArray(keys.toList().takeLast(300)).toString())
            .apply()
    }

    /** Ajoute une notification. [key] : identifiant d'unicité (null = toujours ajouter). */
    @Synchronized
    fun add(ctx: Context, key: String?, title: String, text: String) {
        load(ctx)
        if (key != null && !keys.add(key)) return
        val now = System.currentTimeMillis()
        items.add(0, Notif(now, now, title, text, false))
        while (items.size > MAX_ITEMS) items.removeAt(items.size - 1)
        save(ctx)
        if (AppSettings.notif(ctx)) post(ctx, now, title, text)
    }

    @Synchronized
    fun markAllRead(ctx: Context) {
        load(ctx)
        if (items.none { !it.read }) return
        for (i in items.indices) items[i] = items[i].copy(read = true)
        save(ctx)
    }

    @Synchronized
    fun clear(ctx: Context) {
        load(ctx)
        items.clear()
        save(ctx)
    }

    private fun post(ctx: Context, id: Long, title: String, text: String) {
        try {
            if (Build.VERSION.SDK_INT >= 33 &&
                ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
            ) return
            if (Build.VERSION.SDK_INT >= 26) {
                ctx.getSystemService(NotificationManager::class.java).createNotificationChannel(
                    NotificationChannel(CHANNEL, "Informations NMA Tunnel", NotificationManager.IMPORTANCE_DEFAULT)
                )
            }
            val open = PendingIntent.getActivity(
                ctx, 0, Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val n = NotificationCompat.Builder(ctx, CHANNEL)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle(com.nma.tunnel.i18n.I18n.tr(title))
                .setContentText(com.nma.tunnel.i18n.I18n.tr(text))
                .setStyle(NotificationCompat.BigTextStyle().bigText(com.nma.tunnel.i18n.I18n.tr(text)))
                .setContentIntent(open)
                .setAutoCancel(true)
                .build()
            NotificationManagerCompat.from(ctx).notify((id % Int.MAX_VALUE).toInt(), n)
        } catch (e: Exception) {
            // notification Android impossible : la boîte de réception reste disponible
        }
    }
}
