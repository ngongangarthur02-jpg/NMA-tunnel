package com.nma.tunnel.util

import android.content.Intent
import android.graphics.Typeface
import android.net.Uri
import android.text.Layout
import android.text.Spanned
import android.text.style.AlignmentSpan
import android.text.style.ForegroundColorSpan
import android.text.style.RelativeSizeSpan
import android.text.style.StrikethroughSpan
import android.text.style.StyleSpan
import android.text.style.TypefaceSpan
import android.text.style.URLSpan
import android.text.style.UnderlineSpan
import androidx.compose.foundation.text.ClickableText
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.ParagraphStyle
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.sp
import androidx.core.text.HtmlCompat
import com.nma.tunnel.ui.theme.NmaColors

/** Nombre maximum de caractères d'un message admin. */
const val MESSAGE_MAX = 5000

private val ALLOWED_SCHEMES = setOf("http", "https", "tg", "mailto", "tel")

/**
 * Transforme du texte HTML simple (b, i, u, big, small, font color, h1, a href, br…) en texte mis en forme.
 * Rien n'est exécuté : seuls des styles sont appliqués. Les images et les scripts sont ignorés.
 */
fun htmlToAnnotated(html: String, baseSizeSp: Float, defaultColor: Color, linkColor: Color): AnnotatedString {
    return try {
        val src = html.replace("\r", "").replace("\n", "<br>")
        val sp = HtmlCompat.fromHtml(src, HtmlCompat.FROM_HTML_MODE_COMPACT)
        // retire les retours à la ligne en fin de texte
        var end = sp.length
        while (end > 0 && sp[end - 1] == '\n') end--
        if (end == 0) return AnnotatedString("")
        val len = end

        // Taille effective de chaque caractère : les <big> et <small> imbriqués se multiplient (bornés)
        val mult = FloatArray(len) { 1f }
        for (s in sp.getSpans(0, sp.length, RelativeSizeSpan::class.java)) {
            val a = sp.getSpanStart(s).coerceIn(0, len)
            val b = sp.getSpanEnd(s).coerceIn(0, len)
            for (i in a until b) mult[i] *= s.sizeChange
        }

        val b = AnnotatedString.Builder(sp.subSequence(0, len).toString())
        b.addStyle(SpanStyle(color = defaultColor, fontSize = baseSizeSp.sp), 0, len)

        var i = 0
        while (i < len) {
            var j = i + 1
            while (j < len && mult[j] == mult[i]) j++
            val m = mult[i].coerceIn(0.6f, 2.2f)
            if (m != 1f) b.addStyle(SpanStyle(fontSize = (baseSizeSp * m).sp), i, j)
            i = j
        }

        for (s in sp.getSpans(0, sp.length, Any::class.java)) {
            val a = sp.getSpanStart(s).coerceIn(0, len)
            val e = sp.getSpanEnd(s).coerceIn(0, len)
            if (a >= e) continue
            when (s) {
                is StyleSpan -> when (s.style) {
                    Typeface.BOLD -> b.addStyle(SpanStyle(fontWeight = FontWeight.Bold), a, e)
                    Typeface.ITALIC -> b.addStyle(SpanStyle(fontStyle = FontStyle.Italic), a, e)
                    Typeface.BOLD_ITALIC -> b.addStyle(
                        SpanStyle(fontWeight = FontWeight.Bold, fontStyle = FontStyle.Italic), a, e
                    )
                }
                is ForegroundColorSpan -> {
                    var c = Color(s.foregroundColor)
                    // blanc sur fond clair ou noir sur fond sombre : on garde le texte lisible
                    val l = c.luminance()
                    if ((NmaColors.dark && l < 0.08f) || (!NmaColors.dark && l > 0.92f)) c = defaultColor
                    b.addStyle(SpanStyle(color = c), a, e)
                }
                is UnderlineSpan -> b.addStyle(SpanStyle(textDecoration = TextDecoration.Underline), a, e)
                is StrikethroughSpan -> b.addStyle(SpanStyle(textDecoration = TextDecoration.LineThrough), a, e)
                is TypefaceSpan -> if (s.family == "monospace") b.addStyle(SpanStyle(fontFamily = FontFamily.Monospace), a, e)
                is URLSpan -> {
                    val scheme = runCatching { Uri.parse(s.url).scheme?.lowercase() }.getOrNull()
                    if (scheme in ALLOWED_SCHEMES) {
                        b.addStyle(SpanStyle(color = linkColor, textDecoration = TextDecoration.Underline), a, e)
                        b.addStringAnnotation("URL", s.url, a, e)
                    }
                }
                is AlignmentSpan -> {
                    val al = (s as AlignmentSpan).alignment
                    if (al == Layout.Alignment.ALIGN_CENTER) b.addStyle(ParagraphStyle(textAlign = TextAlign.Center), a, e)
                    else if (al == Layout.Alignment.ALIGN_OPPOSITE) b.addStyle(ParagraphStyle(textAlign = TextAlign.End), a, e)
                }
            }
        }
        b.toAnnotatedString()
    } catch (e: Exception) {
        AnnotatedString(html)
    }
}

/** Affiche un message HTML mis en forme ; les liens http(s), Telegram, mail et téléphone sont cliquables. */
@Composable
fun HtmlMessage(html: String, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val text = htmlToAnnotated(html, 13f, NmaColors.TextPrimary, NmaColors.Accent)
    ClickableText(
        text = text,
        modifier = modifier,
        style = TextStyle(color = NmaColors.TextPrimary, fontSize = 13.sp),
        onClick = { offset ->
            text.getStringAnnotations("URL", offset, offset).firstOrNull()?.let {
                runCatching {
                    ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(it.item)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }
            }
        }
    )
}
