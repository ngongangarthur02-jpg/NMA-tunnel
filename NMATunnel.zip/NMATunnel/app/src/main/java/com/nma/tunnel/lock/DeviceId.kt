package com.nma.tunnel.lock

import android.content.Context
import com.nma.tunnel.model.Links
import java.security.KeyFactory
import java.security.KeyPair
import java.security.KeyPairGenerator
import java.security.MessageDigest
import java.security.PrivateKey
import java.security.PublicKey
import java.security.spec.ECGenParameterSpec
import java.security.spec.PKCS8EncodedKeySpec
import java.security.spec.X509EncodedKeySpec
import javax.crypto.KeyAgreement

/**
 * Identité de l'appareil : une paire de clés (courbe P-256) créée à la première ouverture.
 * La clé publique est l'« ID » que l'admin colle pour verrouiller un code sur cet appareil.
 * La clé privée ne quitte jamais l'application.
 */
object DeviceId {

    private const val PREFS = "nma_device"
    private const val PREFIX = "NMAID."

    /** En-tête fixe d'une clé publique P-256 au format X.509 (26 octets) : le reste est le point (65 octets). */
    private val X509_HEADER = byteArrayOf(
        0x30, 0x59, 0x30, 0x13, 0x06, 0x07, 0x2a, 0x86.toByte(), 0x48, 0xce.toByte(), 0x3d, 0x02, 0x01,
        0x06, 0x08, 0x2a, 0x86.toByte(), 0x48, 0xce.toByte(), 0x3d, 0x03, 0x01, 0x07, 0x03, 0x42, 0x00
    )
    const val RAW_SIZE = 65

    fun newKeyPair(): KeyPair {
        val gen = KeyPairGenerator.getInstance("EC")
        gen.initialize(ECGenParameterSpec("secp256r1"))
        return gen.generateKeyPair()
    }

    fun rawOf(pub: PublicKey): ByteArray {
        val enc = pub.encoded
        return enc.copyOfRange(enc.size - RAW_SIZE, enc.size)
    }

    fun publicFromRaw(raw: ByteArray): PublicKey {
        require(raw.size == RAW_SIZE && raw[0] == 4.toByte()) { "Clé publique invalide" }
        return KeyFactory.getInstance("EC").generatePublic(X509EncodedKeySpec(X509_HEADER + raw))
    }

    private val P = java.math.BigInteger("FFFFFFFF00000001000000000000000000000000FFFFFFFFFFFFFFFFFFFFFFFF", 16)
    private val B = java.math.BigInteger("5AC635D8AA3A93E7B3EBBD55769886BC651D06B0CC53B0F63BCE3C3E27D2604B", 16)

    /** Forme courte d'une clé publique : 33 octets au lieu de 65. */
    fun compress(raw: ByteArray): ByteArray {
        val out = ByteArray(33)
        out[0] = if ((raw[64].toInt() and 1) == 0) 2 else 3
        System.arraycopy(raw, 1, out, 1, 32)
        return out
    }

    /** Retrouve la clé publique complète (65 octets) depuis la forme courte. */
    fun decompress(c: ByteArray): ByteArray {
        require(c.size == 33 && (c[0] == 2.toByte() || c[0] == 3.toByte())) { "Clé invalide" }
        val x = java.math.BigInteger(1, c.copyOfRange(1, 33))
        val rhs = x.pow(3).subtract(x.multiply(java.math.BigInteger.valueOf(3))).add(B).mod(P)
        var y = rhs.modPow(P.add(java.math.BigInteger.ONE).shiftRight(2), P)
        if (y.testBit(0) != (c[0] == 3.toByte())) y = P.subtract(y)
        val out = ByteArray(65)
        out[0] = 4
        fun put(v: java.math.BigInteger, off: Int) {
            val b = v.toByteArray()
            val len = minOf(b.size, 32)
            System.arraycopy(b, b.size - len, out, off + 32 - len, len)
        }
        put(x, 1); put(y, 33)
        return out
    }

    @Synchronized
    private fun keyPair(ctx: Context): KeyPair {
        val p = ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val priv = p.getString("priv", null)
        val pub = p.getString("pub", null)
        if (priv != null && pub != null) {
            try {
                val kf = KeyFactory.getInstance("EC")
                val privateKey = kf.generatePrivate(PKCS8EncodedKeySpec(Links.b64Decode(priv)))
                val publicKey = publicFromRaw(Links.b64Decode(pub))
                return KeyPair(publicKey, privateKey)
            } catch (e: Exception) {
                // clés illisibles : on en crée de nouvelles
            }
        }
        val kp = newKeyPair()
        p.edit()
            .putString("priv", Links.b64Encode(kp.private.encoded))
            .putString("pub", Links.b64Encode(rawOf(kp.public)))
            .apply()
        return kp
    }

    fun privateKey(ctx: Context): PrivateKey = keyPair(ctx).private

    /** Clé publique de cet appareil (65 octets). */
    fun publicRaw(ctx: Context): ByteArray = rawOf(keyPair(ctx).public)

    /** L'ID à copier ou partager : « NMAID.… ». */
    fun idString(ctx: Context): String = PREFIX + Links.b64Encode(publicRaw(ctx))

    /** Lit un ID texte. Retourne les 65 octets de la clé publique, ou null si l'ID est invalide. */
    fun parseId(text: String): ByteArray? = try {
        val t = text.trim()
        if (!t.startsWith(PREFIX)) {
            null
        } else {
            val raw = Links.b64Decode(t.substring(PREFIX.length))
            publicFromRaw(raw)
            raw
        }
    } catch (e: Exception) {
        null
    }

    /** Empreinte courte lisible, ex : « A1B2-C3D4-E5F6 ». */
    fun fingerprint(raw: ByteArray): String {
        val h = MessageDigest.getInstance("SHA-256").digest(raw)
        return (0 until 6).joinToString("") { "%02X".format(h[it]) }.chunked(4).joinToString("-")
    }

    fun fingerprint(ctx: Context): String = fingerprint(publicRaw(ctx))

    /** Secret partagé ECDH entre une clé privée et une clé publique. */
    fun agree(priv: PrivateKey, pub: PublicKey): ByteArray {
        val ka = KeyAgreement.getInstance("ECDH")
        ka.init(priv)
        ka.doPhase(pub, true)
        return ka.generateSecret()
    }
}
