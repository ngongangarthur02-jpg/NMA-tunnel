package com.nma.tunnel.i18n

/** Politique de confidentialité, dans les deux langues de l'application. */
object Privacy {
    const val UPDATED_FR = "Dernière mise à jour : 6 novembre 2026"
    const val UPDATED_EN = "Last updated: 6 November 2026"

    fun text(): String = if (I18n.current() == "fr") FR else EN
    fun updated(): String = if (I18n.current() == "fr") UPDATED_FR else UPDATED_EN

    private const val FR = """NMA Tunnel est une application VPN éditée par Ngongang Mbida Arthur (Cameroun). Cette politique explique quelles informations l'application utilise et pourquoi.

1. Pas de compte, pas de collecte de ton trafic
L'application ne demande ni inscription, ni e-mail, ni numéro de téléphone. Nous ne lisons pas, n'enregistrons pas et ne vendons pas les sites que tu visites ni le contenu de ton trafic. Le trafic passe par le serveur de la configuration que tu utilises : c'est le fournisseur de ce serveur (celui qui t'a donné la configuration) qui le reçoit. Lis sa propre politique.

2. Informations gardées sur ton téléphone
• Tes serveurs et configurations (les configurations verrouillées restent chiffrées et leurs détails ne sont jamais affichés).
• Tes réglages : thème, langue, mode économie, partage de connexion, notifications.
• Ta consommation de données pour les configurations avec quota, et ta boîte de notifications.
• Ton ID public d'appareil (NMAID), créé sur ton téléphone. Il n'est envoyé que si tu le partages toi-même à un administrateur.
• Le journal (Logs) est gardé en mémoire et disparaît à la fermeture de l'application.
Ces informations restent sur ton téléphone. Tu peux les supprimer en effaçant les données de l'application ou en la désinstallant. Si la sauvegarde Android est active, Android peut en garder une copie dans ton compte Google.

3. Connexions faites par l'application
• Vérification de l'heure (gstatic.com) pour contrôler l'expiration des configurations.
• Mesure de la connexion (gstatic.com, cloudflare.com) pour afficher le ping.
• Recherche de mises à jour (api.github.com) et téléchargement de la mise à jour depuis GitHub.
Ces services peuvent voir l'adresse IP de ton téléphone, comme n'importe quel site.

4. Publicité (Google AdMob)
L'application affiche des bannières publicitaires Google AdMob. Google peut collecter des informations sur ton appareil (identifiant publicitaire, adresse IP, type d'appareil, interactions avec les pubs) pour afficher et mesurer les annonces. Les publicités ne passent pas par ton VPN. Tu peux réinitialiser ou supprimer ton identifiant publicitaire dans les paramètres Android (Google > Annonces). Plus d'informations : policies.google.com/technologies/ads

5. Autorisations utilisées
• VPN : pour créer le tunnel.
• Internet et état du réseau : pour te connecter et relancer le VPN si le réseau change.
• Notifications : pour t'informer des mises à jour, messages et expirations.
• Installation d'applications : seulement pour installer une mise à jour que tu demandes.
• Service au premier plan : pour garder le VPN actif.

6. Sécurité
Les configurations verrouillées sont chiffrées. Une option peut refuser leur usage sur un téléphone rooté ; ce contrôle se fait sur ton téléphone et rien n'est envoyé. Aucun système n'est parfait : utilise un serveur de confiance.

7. Enfants
L'application n'est pas destinée aux enfants de moins de 13 ans.

8. Changements
Cette politique peut évoluer. La date de mise à jour est indiquée en haut.

9. Contact
WhatsApp : +237 673 105 582
Telegram : t.me/mboa_low_surf"""

    private const val EN = """NMA Tunnel is a VPN app published by Ngongang Mbida Arthur (Cameroon). This policy explains what information the app uses and why.

1. No account, no collection of your traffic
The app does not ask for sign-up, e-mail or phone number. We do not read, record or sell the sites you visit or the content of your traffic. Your traffic goes through the server of the configuration you use: the provider of that server (the person who gave you the configuration) receives it. Read their own policy.

2. Information kept on your phone
• Your servers and configurations (locked configurations stay encrypted and their details are never shown).
• Your settings: theme, language, battery saver, connection sharing, notifications.
• Your data usage for configurations with a quota, and your notification inbox.
• Your public device ID (NMAID), created on your phone. It is only sent if you share it yourself with an administrator.
• The log (Logs) is kept in memory and disappears when the app is closed.
This information stays on your phone. You can delete it by clearing the app's data or uninstalling it. If Android backup is on, Android may keep a copy in your Google account.

3. Connections made by the app
• Time check (gstatic.com) to verify configuration expiry.
• Connection measurement (gstatic.com, cloudflare.com) to display the ping.
• Update check (api.github.com) and update download from GitHub.
These services can see your phone's IP address, like any website.

4. Advertising (Google AdMob)
The app shows Google AdMob banner ads. Google may collect information about your device (advertising ID, IP address, device type, interactions with ads) to serve and measure ads. Ads do not go through your VPN. You can reset or delete your advertising ID in Android settings (Google > Ads). More information: policies.google.com/technologies/ads

5. Permissions used
• VPN: to create the tunnel.
• Internet and network state: to connect and restart the VPN when the network changes.
• Notifications: to inform you of updates, messages and expiries.
• Install apps: only to install an update that you request.
• Foreground service: to keep the VPN running.

6. Security
Locked configurations are encrypted. An option can refuse their use on a rooted phone; this check is done on your phone and nothing is sent. No system is perfect: use a server you trust.

7. Children
The app is not intended for children under 13.

8. Changes
This policy may change. The update date is shown at the top.

9. Contact
WhatsApp: +237 673 105 582
Telegram: t.me/mboa_low_surf"""
}
