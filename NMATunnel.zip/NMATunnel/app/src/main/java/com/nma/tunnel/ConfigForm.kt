package com.nma.tunnel

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.OutlinedTextField
import com.nma.tunnel.i18n.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nma.tunnel.model.Field
import com.nma.tunnel.model.Forms
import com.nma.tunnel.model.Kind
import com.nma.tunnel.model.ProxyConfig
import com.nma.tunnel.ui.theme.NmaColors

/**
 * Formulaire générique « Add config manually » (V2Ray ou SSH).
 * [initial] != null : modification d'une configuration existante.
 */
@Composable
fun ConfigFormScreen(
    type: String,
    mode: String?,
    initial: ProxyConfig?,
    onCancel: () -> Unit,
    onSave: (ProxyConfig) -> Unit
) {
    val values = remember {
        mutableStateMapOf<String, String>().apply {
            putAll(if (initial != null) Forms.toValues(initial) else Forms.defaults(type, mode))
        }
    }
    var error by remember { mutableStateOf<String?>(null) }
    val fields = Forms.fields(type)

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Text(
            (if (initial != null) "Modifier : " else "") + Forms.title(type, mode),
            color = NmaColors.TextPrimary, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold
        )
        Spacer(Modifier.height(12.dp))

        fields.forEach { f ->
            val visible = f.showIf?.invoke(values) ?: true
            if (visible) {
                FieldEditor(f, values[f.key] ?: "") { values[f.key] = it; error = null }
                Spacer(Modifier.height(10.dp))
            }
        }

        error?.let { Text(it, color = NmaColors.Error, fontSize = 13.sp) }
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onCancel) { Text("Annuler", color = NmaColors.TextSecondary) }
            Button(
                onClick = {
                    val snap = HashMap(values)
                    val e = Forms.validate(type, snap)
                    if (e != null) error = e else onSave(Forms.build(type, snap))
                },
                colors = ButtonDefaults.buttonColors(containerColor = NmaColors.Accent)
            ) { Text("Enregistrer", color = androidx.compose.ui.graphics.Color.White) }
        }
        Spacer(Modifier.height(16.dp))
    }
}

@Composable
private fun FieldEditor(f: Field, value: String, onChange: (String) -> Unit) {
    when (f.kind) {
        Kind.CHOICE -> {
            var open by remember { mutableStateOf(false) }
            Column {
                Text(f.label, color = NmaColors.TextSecondary, fontSize = 12.sp)
                Box {
                    Row(
                        Modifier.fillMaxWidth().padding(top = 4.dp)
                            .background(NmaColors.NavyCard, RoundedCornerShape(10.dp))
                            .border(1.dp, NmaColors.NavyBorder, RoundedCornerShape(10.dp))
                            .clickable { open = true }.padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(value.ifEmpty { "(aucun)" }, color = NmaColors.TextPrimary)
                        Text("▾", color = NmaColors.TextSecondary)
                    }
                    DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
                        f.options.forEach { o ->
                            DropdownMenuItem(
                                text = { Text(o.ifEmpty { "(aucun)" }) },
                                onClick = { onChange(o); open = false }
                            )
                        }
                    }
                }
            }
        }
        else -> {
            Column {
                OutlinedTextField(
                    value = value,
                    onValueChange = onChange,
                    label = { Text(f.label) },
                    singleLine = f.kind != Kind.MULTILINE,
                    minLines = if (f.kind == Kind.MULTILINE) 4 else 1,
                    visualTransformation = if (f.kind == Kind.PASSWORD) PasswordVisualTransformation()
                        else VisualTransformation.None,
                    keyboardOptions = KeyboardOptions(
                        keyboardType = when (f.kind) {
                            Kind.NUMBER -> KeyboardType.Number
                            Kind.PASSWORD -> KeyboardType.Password
                            else -> KeyboardType.Text
                        }
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
                if (f.hint.isNotEmpty()) {
                    Text(f.hint, color = NmaColors.TextSecondary, fontSize = 11.sp, modifier = Modifier.padding(top = 2.dp))
                }
            }
        }
    }
}
