package com.nma.tunnel

import android.app.Activity
import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.outlined.Dns
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.MoreHoriz
import androidx.compose.material3.AlertDialog
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.HorizontalDivider
import com.nma.tunnel.model.Forms
import com.nma.tunnel.model.Links
import com.nma.tunnel.model.ProxyConfig
import com.nma.tunnel.settings.AppSettings
import com.nma.tunnel.update.Updater
import com.nma.tunnel.util.RootCheck
import com.nma.tunnel.util.NetInfo
import com.nma.tunnel.util.NotifStore
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Badge
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import com.nma.tunnel.i18n.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.nma.tunnel.lock.LockedConfig
import com.nma.tunnel.lock.TrustedTime
import com.nma.tunnel.lock.remainingText
import com.nma.tunnel.model.Server
import com.nma.tunnel.model.ServerStore
import com.nma.tunnel.model.key
import com.nma.tunnel.model.pingLabel
import com.nma.tunnel.model.pingServer
import com.nma.tunnel.ui.theme.NmaColors
import com.nma.tunnel.ui.theme.NmaTunnelTheme
import com.nma.tunnel.vpn.NmaVpnService
import com.nma.tunnel.vpn.TunnelState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppSettings.load(this)
        com.nma.tunnel.ads.Ads.init(this)
        handleIncoming(intent)
        setContent { NmaTunnelTheme { NmaApp() } }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIncoming(intent)
    }

    /** Fichier .nma ouvert depuis WhatsApp, Telegram, le gestionnaire de fichiers… */
    private fun handleIncoming(i: Intent?) {
        val uri: android.net.Uri? = when (i?.action) {
            Intent.ACTION_VIEW -> i.data
            Intent.ACTION_SEND ->
                if (android.os.Build.VERSION.SDK_INT >= 33)
                    i.getParcelableExtra(Intent.EXTRA_STREAM, android.net.Uri::class.java)
                else @Suppress("DEPRECATION") i.getParcelableExtra(Intent.EXTRA_STREAM)
            else -> null
        }
        if (uri != null) com.nma.tunnel.util.ImportInbox.fromUri(this, uri)
    }
}

private fun pingColor(v: Int?): Color = when {
    v == null || v == -2 -> NmaColors.TextSecondary
    v < 0 -> NmaColors.Error
    v < 200 -> NmaColors.Connected
    v < 500 -> NmaColors.Warn
    else -> NmaColors.Error
}

/** Formulaire en cours : nouveau serveur ou modification. */
private class FormRequest(val type: String, val mode: String?, val initial: ProxyConfig?, val editing: Server?)

@Composable
fun NmaApp() {
    var tab by remember { mutableIntStateOf(0) }
    var showAdmin by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    var adminUnlocked by remember { mutableStateOf(false) }
    var showCreator by remember { mutableStateOf(false) }
    var form by remember { mutableStateOf<FormRequest?>(null) }
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val store = remember { ServerStore(context) }
    val servers = remember {
        mutableStateListOf<Server>().apply {
            addAll(store.load())
            if (isEmpty()) add(Server("Aucun serveur", "VLESS"))
        }
    }
    var selected by remember {
        mutableStateOf(store.loadSelected()?.let { k -> servers.firstOrNull { it.key() == k } } ?: servers.first())
    }
    // Le choix de l'utilisateur est mémorisé, même après fermeture de l'application
    LaunchedEffect(selected) { if (selected.link != null) store.saveSelected(selected.key()) }

    LaunchedEffect(Unit) {
        withContext(Dispatchers.IO) { TrustedTime.sync(context) }
    }
    LaunchedEffect(Unit) {
        servers.toList().forEach { s -> scope.launch { pingServer(s) } }
    }
    // Vérifie discrètement s'il existe une mise à jour (pastille sur l'onglet More)
    LaunchedEffect(Unit) { Updater.check() }
    // Notifications : mise à jour disponible
    LaunchedEffect(Updater.phase) {
        if (Updater.phase == Updater.Phase.AVAILABLE) {
            NotifStore.add(context, "update-${Updater.latest}", "Mise à jour disponible",
                "NMA Tunnel ${Updater.latest} est disponible. Ouvre More > Check update.")
        }
    }
    // Notifications : configurations verrouillées bientôt expirées ou expirées
    LaunchedEffect(Unit) {
        while (true) {
            servers.toList().filter { it.locked && it.expiresAt > 0L && it.code != null }
                .groupBy { it.code }.forEach { (code, list) ->
                    val s = list.first()
                    val left = s.expiresAt - TrustedTime.now(context)
                    val label = s.name.replace(Regex(" \\d+$"), "")
                    if (left <= 0L) {
                        NotifStore.add(context, "exp-$code", "Configuration expirée", "« $label » a expiré. Demande un nouveau code.")
                    } else if (left < 24L * 3600_000L) {
                        NotifStore.add(context, "soon-$code", "Expire bientôt", "« $label » expire dans ${remainingText(left)}.")
                    }
                }
            delay(10 * 60_000L)
        }
    }

    fun handleImport(raw: String): String? {
        // 1) Configuration verrouillée (NMA1 / NMA2)
        val codes = LockedConfig.extractCodes(raw)
        if (codes.isNotEmpty()) {
            var err: String? = null
            var added = 0
            for (code in codes) {
                if (servers.any { it.code == code }) { err = "Cette configuration est déjà importée"; continue }
                val (p, e0) = LockedConfig.tryOpen(code, context)
                if (p == null) { err = e0 ?: "Code invalide, altéré ou créé avec une autre clé"; continue }
                val e = LockedConfig.checkImport(p, TrustedTime.now(context))
                if (e != null) { err = e; continue }
                if (p.blockRoot && RootCheck.isRooted(context)) { err = RootCheck.MESSAGE; continue }
                val list = LockedConfig.toServers(p, code)
                if (list.isEmpty()) { err = "Configuration vide"; continue }
                servers.removeAll { it.link == null }
                servers.addAll(list)
                if (p.message.isNotBlank()) {
                    val plain = androidx.core.text.HtmlCompat.fromHtml(
                        p.message.replace("\n", "<br>"), androidx.core.text.HtmlCompat.FROM_HTML_MODE_COMPACT
                    ).toString().trim().take(300)
                    NotifStore.add(context, "msg-${code.hashCode()}", "Message : ${p.name}", plain)
                }
                added += list.size
                if (selected.link == null) selected = list.first()
                list.forEach { s -> scope.launch { pingServer(s) } }
            }
            if (added > 0) {
                store.save(servers)
                TunnelState.log("Configuration verrouillée importée")
                return null
            }
            return err
        }

        // 2) Liens classiques (vless, vmess, trojan, ss, hysteria2)
        val found = Links.extract(raw)
        val parsed = found.mapNotNull { Links.toServer(it) }
        val fresh = parsed.filter { p -> servers.none { it.link == p.link } }
        return when {
            found.isEmpty() -> "Aucun lien (vless://, vmess://, trojan://, ss://…) ni code NMA trouvé"
            parsed.isEmpty() -> "Lien invalide"
            fresh.isEmpty() -> "Ce serveur existe déjà"
            else -> {
                servers.removeAll { it.link == null }
                servers.addAll(fresh)
                store.save(servers)
                if (selected.link == null) selected = fresh.first()
                TunnelState.log("${fresh.size} serveur(s) importé(s)")
                fresh.forEach { s -> scope.launch { pingServer(s) } }
                null
            }
        }
    }

    fun saveForm(req: FormRequest, cfg: ProxyConfig) {
        val s = Links.toServer(cfg.toLink()) ?: return
        val old = req.editing
        if (old != null) {
            val i = servers.indexOf(old)
            if (i >= 0) servers[i] = s else servers.add(s)
            if (selected == old) selected = s
            TunnelState.pings.remove(old.key())
        } else {
            servers.removeAll { it.link == null }
            servers.add(s)
            if (selected.link == null) selected = s
        }
        store.save(servers)
        scope.launch { pingServer(s) }
        TunnelState.log("Serveur enregistré")
        form = null
    }

    // Import d'un fichier .nma (ouverture directe ou sélecteur)
    var importResult by remember { mutableStateOf<String?>(null) }
    val pending = com.nma.tunnel.util.ImportInbox.text
    LaunchedEffect(pending) {
        if (pending != null) {
            com.nma.tunnel.util.ImportInbox.text = null
            tab = 1; showAdmin = false; form = null
            val err = handleImport(pending)
            importResult = err ?: "Configuration importée ✓"
        }
    }
    importResult?.let { msg ->
        AlertDialog(
            onDismissRequest = { importResult = null },
            containerColor = NmaColors.NavyCard,
            title = { Text("Import du fichier", color = NmaColors.TextPrimary) },
            text = { Text(msg, color = if (msg.endsWith("✓")) NmaColors.Connected else NmaColors.Error) },
            confirmButton = { TextButton(onClick = { importResult = null }) { Text("OK", color = NmaColors.Accent) } }
        )
    }

    Scaffold(
        containerColor = NmaColors.Navy,
        bottomBar = {
            androidx.compose.foundation.layout.Column {
                com.nma.tunnel.ads.AdBanner()
                BottomBar(tab) { tab = it; showAdmin = false; showCreator = false; showSettings = false; form = null }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            val f = form
            if (f != null) {
                ConfigFormScreen(
                    type = f.type, mode = f.mode, initial = f.initial,
                    onCancel = { form = null },
                    onSave = { cfg -> saveForm(f, cfg) }
                )
            } else if (showSettings) {
                SettingsScreen(onBack = { showSettings = false })
            } else if (showCreator) {
                AdminScreen(
                    servers = servers, unlocked = true, onUnlock = {},
                    onBack = { showCreator = false }, creator = true
                )
            } else if (showAdmin) {
                AdminScreen(
                    servers = servers,
                    unlocked = adminUnlocked,
                    onUnlock = { adminUnlocked = true },
                    onBack = { showAdmin = false; adminUnlocked = false }
                )
            } else {
                when (tab) {
                    0 -> HomeScreen(selected = selected, onOpenServers = { tab = 1 }, onOpenSettings = { showSettings = true })
                    1 -> ServersScreen(
                        servers = servers,
                        selected = selected,
                        onSelect = { selected = it; tab = 0 },
                        onRefresh = { servers.toList().forEach { s -> scope.launch { pingServer(s) } } },
                        onImport = { raw -> handleImport(raw) },
                        onAddManual = { type, mode -> form = FormRequest(type, mode, null, null) },
                        onEdit = { s ->
                            val cfg = s.link?.let { Links.fromLink(it) }
                            if (cfg != null && !s.locked) {
                                form = FormRequest(cfg.type, cfg.params["mode"], cfg, s)
                            }
                        },
                        onDelete = { s ->
                            val connectedOne = TunnelState.status != TunnelState.Status.DISCONNECTED && s == selected
                            if (!connectedOne) {
                                if (s.code != null) servers.removeAll { it.code == s.code } else servers.remove(s)
                                store.save(servers)
                                if (servers.isEmpty()) servers.add(Server("Aucun serveur", "VLESS"))
                                if (servers.none { it == selected }) selected = servers.first()
                                TunnelState.log("Serveur supprimé")
                            }
                        }
                    )
                    2 -> LogsScreen()
                    else -> MoreScreen(onAdmin = { showAdmin = true }, onCreator = { showCreator = true })
                }
            }
        }
    }
}

@Composable
fun HomeScreen(selected: Server, onOpenServers: () -> Unit, onOpenSettings: () -> Unit = {}) {
    val ctx = LocalContext.current
    val status = TunnelState.status
    val connected = status == TunnelState.Status.CONNECTED
    val connecting = status == TunnelState.Status.CONNECTING

    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) { now = System.currentTimeMillis(); delay(1000) }
    }
    val trustedNow = remember(now) { TrustedTime.now(ctx) }

    fun startVpn() {
        val i = Intent(ctx, NmaVpnService::class.java)
            .putExtra(NmaVpnService.EXTRA_LINK, selected.link)
            .putExtra(NmaVpnService.EXTRA_EXPIRES, selected.expiresAt)
            .putExtra(NmaVpnService.EXTRA_LOCKED, selected.locked)
            .putExtra(NmaVpnService.EXTRA_BLOCK_ROOT, selected.blockRoot)
            .putExtra(NmaVpnService.EXTRA_QUOTA_MB, selected.quotaMb)
            .putExtra(NmaVpnService.EXTRA_QUOTA_KEY, selected.code?.let { com.nma.tunnel.util.QuotaStore.key(it) } ?: "")
        ContextCompat.startForegroundService(ctx, i)
    }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        if (it.resultCode == Activity.RESULT_OK) startVpn()
    }
    fun toggle() {
        if (connected || connecting) {
            ctx.startService(Intent(ctx, NmaVpnService::class.java).setAction(NmaVpnService.ACTION_STOP))
            return
        }
        if (selected.link == null) {
            TunnelState.error = "Importe d'abord un serveur (onglet Servers)"
            return
        }
        if (selected.locked && selected.expiresAt > 0L && TrustedTime.now(ctx) >= selected.expiresAt) {
            TunnelState.error = "Configuration expirée. Demande un nouveau code."
            return
        }
        if (selected.blockRoot && RootCheck.isRooted(ctx)) {
            TunnelState.error = RootCheck.MESSAGE
            return
        }
        TunnelState.error = null
        val i = VpnService.prepare(ctx)
        if (i != null) permLauncher.launch(i) else startVpn()
    }

    val statusColor = when {
        connected -> NmaColors.Connected
        connecting -> NmaColors.Warn
        else -> NmaColors.Accent
    }
    val statusText = when {
        connected -> "CONNECTED"
        connecting -> "CONNECTING…"
        else -> "CONNECT"
    }
    val serverPing = TunnelState.pings[selected.key()]
    val pingText = when {
        connected && TunnelState.pingMs >= 0 -> "${TunnelState.pingMs} ms"
        connected && TunnelState.pingMs == -3 -> "timeout"
        connected -> "…"
        serverPing != null && serverPing >= 0 -> "$serverPing ms"
        serverPing == -1 -> "timeout"
        else -> "— ms"
    }
    val seconds = if (connected && TunnelState.connectedAt > 0)
        ((now - TunnelState.connectedAt) / 1000).coerceAtLeast(0) else 0L

    BoxWithConstraints(Modifier.fillMaxSize()) {
        // Tailles adaptées à l'écran (petits téléphones, grands écrans, paysage)
        val ring = minOf(maxWidth * 0.55f, maxHeight * 0.32f).coerceIn(120.dp, 220.dp)
        val inner = ring * 0.82f
        val gap = if (maxHeight < 640.dp) 8.dp else 12.dp
        val small = maxWidth < 360.dp
        val narrow = maxWidth < 400.dp

        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(Modifier.fillMaxWidth().padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(42.dp).border(1.dp, NmaColors.NavyBorder, RoundedCornerShape(12.dp))
                        .background(NmaColors.NavyCard, RoundedCornerShape(12.dp)),
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Filled.Shield, null, tint = NmaColors.Accent) }
                Spacer(Modifier.width(8.dp))
                // Le titre prend la place restante : le chip du serveur et l'engrenage gardent toujours leur taille
                val titleSize = if (narrow) 17.sp else 21.sp
                Column(Modifier.weight(1f)) {
                    Row {
                        Text("NMA", color = NmaColors.TextPrimary, fontSize = titleSize, fontWeight = FontWeight.ExtraBold, maxLines = 1, softWrap = false)
                        Text("TUNNEL", color = NmaColors.Accent, fontSize = titleSize, fontWeight = FontWeight.ExtraBold, maxLines = 1, softWrap = false)
                    }
                    Text("VPN • FAST • SECURE", color = NmaColors.TextSecondary, fontSize = 8.sp, maxLines = 1, softWrap = false)
                }
                Spacer(Modifier.width(6.dp))
                Row(
                    Modifier.height(42.dp).background(NmaColors.NavyCard, RoundedCornerShape(14.dp))
                        .border(1.dp, NmaColors.NavyBorder, RoundedCornerShape(14.dp))
                        .clickable { onOpenServers() }.padding(horizontal = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.widthIn(max = 84.dp)) {
                        Text(selected.name, color = NmaColors.TextPrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp, maxLines = 1)
                        Text(selected.protocol, color = NmaColors.TextSecondary, fontSize = 10.sp, maxLines = 1)
                    }
                    Icon(Icons.Filled.ChevronRight, null, tint = NmaColors.TextSecondary)
                }
                Spacer(Modifier.width(8.dp))
                // Réglages + notifications (grand bouton rond, toujours entièrement visible)
                Box(
                    Modifier.size(48.dp).clip(CircleShape).background(NmaColors.NavyCard)
                        .border(1.dp, NmaColors.NavyBorder, CircleShape).clickable { onOpenSettings() },
                    contentAlignment = Alignment.Center
                ) {
                    val unread = NotifStore.unread
                    if (unread > 0) {
                        BadgedBox(badge = { Badge { Text("$unread") } }) {
                            Icon(Icons.Filled.Settings, "Settings", tint = NmaColors.TextPrimary, modifier = Modifier.size(26.dp))
                        }
                    } else Icon(Icons.Filled.Settings, "Settings", tint = NmaColors.TextPrimary, modifier = Modifier.size(26.dp))
                }
            }

            Spacer(Modifier.height(gap * 2))

            Box(Modifier.size(ring).clickable { toggle() }, contentAlignment = Alignment.Center) {
                Canvas(Modifier.fillMaxSize()) {
                    val stroke = 9.dp.toPx()
                    val brush = when {
                        connected -> Brush.sweepGradient(listOf(NmaColors.Connected, NmaColors.Cyan, NmaColors.Connected))
                        connecting -> Brush.sweepGradient(listOf(NmaColors.Warn, NmaColors.Cyan, NmaColors.Warn))
                        else -> Brush.sweepGradient(listOf(NmaColors.Accent, NmaColors.Cyan, NmaColors.AccentSoft, NmaColors.Accent))
                    }
                    drawArc(
                        brush = brush, startAngle = 0f, sweepAngle = 360f, useCenter = false,
                        topLeft = Offset(stroke / 2, stroke / 2),
                        size = Size(size.width - stroke, size.height - stroke),
                        style = Stroke(stroke, cap = StrokeCap.Round)
                    )
                }
                Box(
                    Modifier.size(inner).clip(CircleShape).background(NmaColors.NavyCard)
                        .border(1.dp, NmaColors.NavyBorder, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Filled.PowerSettingsNew, null, tint = NmaColors.TextPrimary, modifier = Modifier.size(inner * 0.36f))
                }
            }

            Spacer(Modifier.height(gap))
            Text(statusText, color = statusColor, fontSize = if (small) 24.sp else 28.sp, fontWeight = FontWeight.ExtraBold)
            Text("Tunnel status", color = NmaColors.TextSecondary, fontSize = 12.sp)
            TunnelState.error?.let {
                Spacer(Modifier.height(4.dp))
                Text(it, color = NmaColors.Error, fontSize = 12.sp, textAlign = TextAlign.Center)
            }

            Spacer(Modifier.height(gap))

            Row(
                Modifier.fillMaxWidth().border(BorderStroke(1.5.dp, NmaColors.Accent), RoundedCornerShape(14.dp))
                    .clickable { onOpenServers() }.padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    if (selected.locked) Icons.Filled.Lock else Icons.Outlined.Dns,
                    null, tint = NmaColors.Accent, modifier = Modifier.size(26.dp)
                )
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("SELECTED SERVER", color = NmaColors.TextSecondary, fontSize = 10.sp)
                    Text(selected.name, color = NmaColors.TextPrimary, fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1)
                    Text(serverSummary(selected), color = NmaColors.TextSecondary, fontSize = 12.sp, maxLines = 1)
                }
                if (selected.link != null) {
                    Text(pingLabel(serverPing), color = pingColor(serverPing), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Spacer(Modifier.width(6.dp))
                }
                Icon(Icons.Filled.ChevronRight, null, tint = NmaColors.Accent)
            }

            if (selected.locked && selected.expiresAt > 0L) {
                val left = selected.expiresAt - trustedNow
                Spacer(Modifier.height(6.dp))
                Text(
                    "Configuration verrouillée • ${remainingText(left)}",
                    color = if (left <= 0L) NmaColors.Error else NmaColors.TextSecondary,
                    fontSize = 12.sp
                )
            }
            if (selected.locked && selected.quotaMb > 0L) {
                val qLeft = com.nma.tunnel.util.QuotaStore.remaining(ctx, selected.code?.let { com.nma.tunnel.util.QuotaStore.key(it) } ?: "", selected.quotaMb)
                Text(
                    "Quota : ${com.nma.tunnel.util.QuotaStore.format(qLeft)} restant sur ${com.nma.tunnel.util.QuotaStore.format(com.nma.tunnel.util.QuotaStore.mb(selected.quotaMb))}",
                    color = if (qLeft <= 0L) NmaColors.Error else NmaColors.TextSecondary,
                    fontSize = 12.sp
                )
            }

            if (selected.message.isNotBlank()) {
                Spacer(Modifier.height(gap))
                Column(
                    Modifier.fillMaxWidth().background(NmaColors.NavyCard, RoundedCornerShape(14.dp))
                        .border(1.dp, NmaColors.Accent, RoundedCornerShape(14.dp)).padding(12.dp)
                ) {
                    Text("MESSAGE", color = NmaColors.Accent, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    com.nma.tunnel.util.HtmlMessage(selected.message)
                }
            }

            Spacer(Modifier.height(gap))

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatCard("Download", TunnelState.downBytes, TunnelState.downBps, Modifier.weight(1f))
                StatCard("Upload", TunnelState.upBytes, TunnelState.upBps, Modifier.weight(1f))
            }

            Spacer(Modifier.height(gap))

            Row(
                Modifier.fillMaxWidth().background(NmaColors.NavyCard, RoundedCornerShape(14.dp)).padding(12.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                val h = seconds / 3600; val m = (seconds % 3600) / 60; val s = seconds % 60
                Text("Duration : %02d:%02d:%02d".format(h, m, s), color = NmaColors.TextPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Text("Ping : $pingText", color = if (pingText == "timeout") NmaColors.Error else NmaColors.TextPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }

            Spacer(Modifier.height(gap))
            Text("BY NMA", color = NmaColors.TextSecondary, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(gap))
        }
    }
}

/** Taille en base 1024 : 1024 Mo = 1 Go. Retourne (valeur, unité). */
private fun sizeParts(bytes: Long): Pair<String, String> {
    val units = listOf("B", "KB", "MB", "GB", "TB")
    var v = bytes.toDouble()
    var i = 0
    while (v >= 1024.0 && i < units.size - 1) { v /= 1024.0; i++ }
    return (if (i == 0) "%.0f".format(v) else "%.2f".format(v)) to units[i]
}

/** Débit réel en unités réseau standard. */
private fun speedText(bytesPerSec: Long): String {
    // Unités réseau standard (comme un test de vitesse) : 1 Mbps = 1000 Kbps
    var v = bytesPerSec * 8 / 1000.0
    val units = listOf("Kbps", "Mbps", "Gbps")
    var i = 0
    while (v >= 1000.0 && i < units.size - 1) { v /= 1000.0; i++ }
    return "%.2f %s".format(v, units[i])
}

@Composable
fun StatCard(label: String, bytes: Long, bps: Long, modifier: Modifier = Modifier) {
    val (value, unit) = sizeParts(bytes)
    Column(modifier.background(NmaColors.NavyCard, RoundedCornerShape(14.dp)).padding(12.dp)) {
        Text(label, color = NmaColors.TextSecondary, fontSize = 13.sp)
        Row(verticalAlignment = Alignment.Bottom) {
            Text(value, color = NmaColors.TextPrimary, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
            Spacer(Modifier.width(4.dp))
            Text(unit, color = NmaColors.TextSecondary, fontSize = 11.sp, modifier = Modifier.padding(bottom = 3.dp))
        }
        Text(speedText(bps), color = NmaColors.TextSecondary, fontSize = 11.sp)
    }
}

@Composable
fun ServersScreen(
    servers: List<Server>,
    selected: Server,
    onSelect: (Server) -> Unit,
    onRefresh: () -> Unit,
    onImport: (String) -> String?,
    onAddManual: (String, String?) -> Unit,
    onEdit: (Server) -> Unit,
    onDelete: (Server) -> Unit
) {
    val ctx = LocalContext.current
    // 0 = rien, 1 = import / choix, 2 = liste V2Ray, 3 = liste SSH
    var dialog by remember { mutableIntStateOf(0) }
    var text by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    val clipboard = LocalClipboardManager.current
    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) com.nma.tunnel.util.ImportInbox.fromUri(ctx, uri)
    }
    // VPN actif : le serveur connecté ne peut être ni changé, ni modifié, ni supprimé
    val busy = TunnelState.status != TunnelState.Status.DISCONNECTED

    var nowT by remember { mutableLongStateOf(TrustedTime.now(ctx)) }
    LaunchedEffect(Unit) {
        while (true) { delay(30_000); nowT = TrustedTime.now(ctx) }
    }

    @Composable
    fun ChoiceRow(label: String, onClick: () -> Unit) {
        Text(
            label, color = NmaColors.TextPrimary, fontWeight = FontWeight.SemiBold,
            modifier = Modifier.fillMaxWidth().clickable { onClick() }.padding(vertical = 12.dp)
        )
    }

    if (dialog == 1) {
        AlertDialog(
            onDismissRequest = { dialog = 0 },
            containerColor = NmaColors.NavyCard,
            title = { Text("Ajouter un serveur", color = NmaColors.TextPrimary) },
            text = {
                Column {
                    OutlinedTextField(
                        value = text,
                        onValueChange = { text = it; error = null },
                        placeholder = { Text("vless://… vmess://… ou NMA1.…") },
                        isError = error != null,
                        modifier = Modifier.fillMaxWidth()
                    )
                    error?.let { Text(it, color = NmaColors.Error, fontSize = 12.sp) }
                    TextButton(onClick = { clipboard.getText()?.let { text = it.text; error = null } }) {
                        Text("Coller depuis le presse-papiers", color = NmaColors.Accent)
                    }
                    TextButton(onClick = { dialog = 0; filePicker.launch(arrayOf("*/*")) }) {
                        Text("Choisir un fichier .nma", color = NmaColors.Accent)
                    }
                    HorizontalDivider(color = NmaColors.NavyBorder)
                    TextButton(onClick = { dialog = 2 }) {
                        Text("+ Add config manually", color = NmaColors.Accent, fontWeight = FontWeight.Bold)
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val err = onImport(text)
                    if (err == null) { dialog = 0; text = "" } else error = err
                }) { Text("Importer", color = NmaColors.Accent) }
            },
            dismissButton = {
                TextButton(onClick = { dialog = 0 }) { Text("Annuler", color = NmaColors.TextSecondary) }
            }
        )
    }
    if (dialog in 2..4) {
        val coreVersion = remember {
            runCatching { libv2ray.Libv2ray.checkVersionX() }.getOrNull()?.takeIf { it.isNotBlank() }
        }
        AlertDialog(
            onDismissRequest = { dialog = 0 },
            containerColor = NmaColors.NavyCard,
            title = { Text("Add config manually", color = NmaColors.TextPrimary) },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    Row {
                        listOf(2 to "V2Ray", 3 to "SSH", 4 to "Xray").forEach { (d, label) ->
                            TextButton(onClick = { dialog = d }, contentPadding = PaddingValues(horizontal = 8.dp)) {
                                Text(
                                    "$label Config",
                                    color = if (dialog == d) NmaColors.Accent else NmaColors.TextSecondary,
                                    fontWeight = if (dialog == d) FontWeight.Bold else FontWeight.Normal,
                                    fontSize = 13.sp
                                )
                            }
                        }
                    }
                    when (dialog) {
                        2 -> Forms.V2RAY_TYPES.filter { it.second != "custom" }.forEach { (label, type) ->
                            ChoiceRow(label) { dialog = 0; onAddManual(type, null) }
                        }
                        3 -> Forms.SSH_MODES.forEach { mode ->
                            ChoiceRow(mode) { dialog = 0; onAddManual("ssh", mode) }
                        }
                        else -> {
                            Text(
                                "Noyau : Xray" + (coreVersion?.let { " ($it)" } ?: ""),
                                color = NmaColors.TextSecondary, fontSize = 12.sp,
                                modifier = Modifier.padding(vertical = 6.dp)
                            )
                            ChoiceRow("Xray Core (JSON complet)") { dialog = 0; onAddManual("custom", null) }
                            Text(
                                "Colle une configuration Xray complète : elle est lancée telle quelle avec le noyau Xray de l'application.",
                                color = NmaColors.TextSecondary, fontSize = 12.sp
                            )
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { dialog = 0 }) { Text("Annuler", color = NmaColors.TextSecondary) }
            }
        )
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Servers", color = NmaColors.TextPrimary, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold,
                modifier = Modifier.weight(1f))
            IconButton(onClick = onRefresh) {
                Icon(Icons.Filled.Refresh, "Actualiser les pings", tint = NmaColors.Accent)
            }
            Button(
                onClick = { error = null; dialog = 1 },
                colors = ButtonDefaults.buttonColors(containerColor = NmaColors.Accent)
            ) { Text("+ Ajouter", color = Color.White) }
        }
        Spacer(Modifier.height(12.dp))
        if (busy) {
            Text(
                "VPN actif : déconnecte-le pour choisir un autre serveur ou modifier celui-ci.",
                color = NmaColors.Warn, fontSize = 12.sp, modifier = Modifier.padding(bottom = 10.dp)
            )
        }
        servers.forEach { s ->
            val active = s == selected
            val connectedOne = busy && active
            val ping = TunnelState.pings[s.key()]
            val left = s.expiresAt - nowT
            Row(
                Modifier.fillMaxWidth().padding(bottom = 10.dp)
                    .background(NmaColors.NavyCard, RoundedCornerShape(14.dp))
                    .border(if (active) 1.5.dp else 1.dp, if (active) NmaColors.Accent else NmaColors.NavyBorder, RoundedCornerShape(14.dp))
                    .alpha(if (busy && !active) 0.45f else 1f)
                    .clickable(enabled = !busy || active) { onSelect(s) }.padding(start = 14.dp, top = 8.dp, bottom = 8.dp, end = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(if (s.locked) Icons.Filled.Lock else Icons.Outlined.Dns, null, tint = NmaColors.Accent)
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(s.name, color = NmaColors.TextPrimary, fontWeight = FontWeight.Bold, maxLines = 1)
                    Text(
                        serverSummary(s),
                        color = NmaColors.TextSecondary, fontSize = 12.sp
                    )
                    if (s.locked && s.expiresAt > 0L) {
                        Text(
                            remainingText(left),
                            color = if (left <= 0L) NmaColors.Error else NmaColors.TextSecondary,
                            fontSize = 12.sp
                        )
                    }
                }
                if (s.link != null) {
                    Text(pingLabel(ping), color = pingColor(ping), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    // Le crayon n'apparaît que pour les configurations déverrouillées
                    if (!s.locked && !connectedOne) {
                        IconButton(onClick = { onEdit(s) }) {
                            Icon(Icons.Filled.Edit, "Modifier", tint = NmaColors.Accent)
                        }
                    }
                    if (!connectedOne) {
                        IconButton(onClick = { onDelete(s) }) {
                            Icon(Icons.Filled.Delete, "Supprimer", tint = NmaColors.TextSecondary)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun LogsScreen() {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Logs", color = NmaColors.TextPrimary, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold,
                modifier = Modifier.weight(1f))
            if (TunnelState.logs.isNotEmpty()) {
                Text("${TunnelState.logs.size}", color = NmaColors.TextSecondary, fontSize = 12.sp)
                IconButton(onClick = { TunnelState.logs.clear() }) {
                    Icon(Icons.Filled.Delete, "Effacer les logs", tint = NmaColors.TextSecondary)
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        if (TunnelState.logs.isEmpty()) {
            Text("Aucun log pour le moment", color = NmaColors.TextSecondary)
        }
        TunnelState.logs.asReversed().forEach {
            Text("• ${com.nma.tunnel.i18n.I18n.trLog(it)}", color = NmaColors.TextSecondary, fontSize = 12.sp, modifier = Modifier.padding(vertical = 3.dp))
        }
    }
}

@Composable
fun BottomBar(current: Int, onSelect: (Int) -> Unit) {
    val items: List<Pair<String, ImageVector>> = listOf(
        "Home" to Icons.Outlined.Home,
        "Servers" to Icons.Outlined.Dns,
        "Logs" to Icons.Outlined.History,
        "More" to Icons.Outlined.MoreHoriz
    )
    NavigationBar(containerColor = NmaColors.Navy) {
        items.forEachIndexed { i, (label, icon) ->
            NavigationBarItem(
                selected = current == i,
                onClick = { onSelect(i) },
                icon = {
                    if (label == "More" && Updater.phase == Updater.Phase.AVAILABLE) {
                        BadgedBox(badge = { Badge() }) { Icon(icon, label) }
                    } else Icon(icon, label)
                },
                label = { Text(label, fontSize = 11.sp) },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = NmaColors.Accent,
                    selectedTextColor = NmaColors.Accent,
                    unselectedIconColor = NmaColors.TextSecondary,
                    unselectedTextColor = NmaColors.TextSecondary,
                    indicatorColor = NmaColors.NavyCard
                )
            )
        }
    }
}


/** Partage de connexion : affiche l'adresse du proxy à saisir sur les autres appareils. */
@Composable
fun HostPotCard() {
    val ctx = LocalContext.current
    val clipboard = LocalClipboardManager.current
    var addrs by remember { mutableStateOf(NetInfo.addresses()) }
    LaunchedEffect(Unit) {
        while (true) { addrs = NetInfo.addresses(); delay(2000) }
    }
    val running = TunnelState.hotspotActive
    Column(
        Modifier.fillMaxWidth().background(NmaColors.NavyCard, RoundedCornerShape(14.dp))
            .border(1.dp, NmaColors.NavyBorder, RoundedCornerShape(14.dp)).padding(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Host pot", color = NmaColors.TextPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text(
                    when {
                        running -> "Partage actif"
                        AppSettings.hotspotOn -> "Activé : démarre à la connexion du VPN"
                        else -> "Désactivé"
                    },
                    color = if (running) NmaColors.Connected else NmaColors.TextSecondary, fontSize = 12.sp
                )
            }
            Switch(
                checked = AppSettings.hotspotOn,
                onCheckedChange = {
                    AppSettings.setHotspot(ctx, it)
                    // VPN connecté : on le relance pour que le partage s'active ou s'arrête tout de suite
                    if (TunnelState.status != TunnelState.Status.DISCONNECTED) {
                        ctx.startService(
                            Intent(ctx, NmaVpnService::class.java).setAction(NmaVpnService.ACTION_RESTART)
                        )
                    }
                },
                colors = SwitchDefaults.colors(checkedTrackColor = NmaColors.Accent)
            )
        }
        if (AppSettings.hotspotOn && !running) {
            Text(
                "Connecte le VPN (onglet Home) : l'adresse du proxy s'affichera ici.",
                color = NmaColors.TextSecondary, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp)
            )
        }
        if (running) {
            val ip = addrs.firstOrNull()?.ip
            Spacer(Modifier.height(8.dp))
            if (ip == null) {
                Text(
                    "Aucune adresse trouvée. Active le point d'accès Wi-Fi du téléphone ou connecte-le à un Wi-Fi.",
                    color = NmaColors.Warn, fontSize = 12.sp
                )
            } else {
                listOf("SOCKS5" to AppSettings.socksPort, "HTTP" to AppSettings.httpPort).forEach { (n, port) ->
                    val line = "$ip:$port"
                    Row(
                        Modifier.fillMaxWidth().padding(vertical = 3.dp)
                            .background(NmaColors.Navy, RoundedCornerShape(10.dp))
                            .clickable { clipboard.setText(androidx.compose.ui.text.AnnotatedString(line)) }
                            .padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(n, color = NmaColors.TextSecondary, fontSize = 12.sp, modifier = Modifier.width(60.dp))
                        Text(line, color = NmaColors.Accent, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        Text("Copier", color = NmaColors.TextSecondary, fontSize = 11.sp)
                    }
                }
                if (addrs.size > 1) {
                    Text(
                        "Autres adresses : " + addrs.drop(1).joinToString { "${it.ip} (${it.iface})" },
                        color = NmaColors.TextSecondary, fontSize = 11.sp
                    )
                }
                Text(
                    "Sur l'autre appareil : Wi-Fi > Proxy manuel, saisis cette adresse et ce port. Il doit être sur le même Wi-Fi ou sur ton point d'accès.",
                    color = NmaColors.TextSecondary, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp)
                )
            }
        }
    }
}

/** Résumé d'une carte serveur : « SSH • Performance Mode • Direct → Target » (SSH) ou le protocole, + « Locked ». */
fun serverSummary(s: Server): String {
    val parts = ArrayList<String>()
    if (s.protocol.startsWith("SSH")) {
        parts.add("SSH")
        parts.add(com.nma.tunnel.settings.AppSettings.powerLabel())
        val route = s.protocol.removePrefix("SSH").trim('-').split("-").filter { it.isNotBlank() }
        parts.add((if (route.isEmpty()) listOf("Direct") else route).joinToString(" → ") + " → Target")
    } else {
        parts.add(s.protocol)
    }
    if (s.locked) parts.add("Locked")
    return parts.joinToString(" • ")
}
