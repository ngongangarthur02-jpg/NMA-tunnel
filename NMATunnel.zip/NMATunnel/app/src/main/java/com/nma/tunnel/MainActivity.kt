package com.nma.tunnel

import android.app.Activity
import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.outlined.Dns
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.MoreHoriz
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.nma.tunnel.lock.LockedConfig
import com.nma.tunnel.lock.TrustedTime
import com.nma.tunnel.lock.remainingText
import com.nma.tunnel.model.Server
import com.nma.tunnel.model.ServerStore
import com.nma.tunnel.model.VlessParser
import com.nma.tunnel.model.key
import com.nma.tunnel.model.pingLabel
import com.nma.tunnel.model.pingServer
import com.nma.tunnel.ui.theme.NmaColors
import com.nma.tunnel.ui.theme.NmaTunnelTheme
import com.nma.tunnel.vpn.NmaVpnService
import com.nma.tunnel.vpn.TunnelState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { NmaTunnelTheme { NmaApp() } }
    }
}

private fun pingColor(v: Int?): Color = when {
    v == null || v == -2 -> NmaColors.TextSecondary
    v < 0 -> Color(0xFFFF6B6B)
    v < 200 -> NmaColors.Connected
    v < 500 -> Color(0xFFFFC857)
    else -> Color(0xFFFF6B6B)
}

@Composable
fun NmaApp() {
    var tab by remember { mutableIntStateOf(0) }
    var showAdmin by remember { mutableStateOf(false) }
    var adminUnlocked by remember { mutableStateOf(false) }
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val store = remember { ServerStore(context) }
    val servers = remember {
        mutableStateListOf<Server>().apply {
            addAll(store.load())
            if (isEmpty()) add(Server("Aucun serveur", "VLESS"))
        }
    }
    var selected by remember { mutableStateOf(servers.first()) }

    // Heure de confiance (Internet) + ping de tous les serveurs au démarrage
    LaunchedEffect(Unit) {
        withContext(Dispatchers.IO) { TrustedTime.sync(context) }
    }
    LaunchedEffect(Unit) {
        servers.toList().forEach { s -> scope.launch { pingServer(s) } }
    }

    fun handleImport(raw: String): String? {
        // 1) Configuration verrouillée (code NMA1.…)
        val codes = LockedConfig.extractCodes(raw)
        if (codes.isNotEmpty()) {
            var err: String? = null
            var added = 0
            for (code in codes) {
                if (servers.any { it.code == code }) { err = "Cette configuration est déjà importée"; continue }
                val p = LockedConfig.open(code)
                if (p == null) { err = "Code invalide, altéré ou créé avec une autre clé"; continue }
                val e = LockedConfig.checkImport(p, TrustedTime.now(context))
                if (e != null) { err = e; continue }
                val list = LockedConfig.toServers(p, code)
                if (list.isEmpty()) { err = "Configuration vide"; continue }
                servers.removeAll { it.link == null }
                servers.addAll(list)
                added += list.size
                selected = list.first()
                list.forEach { s -> scope.launch { pingServer(s) } }
            }
            if (added > 0) {
                store.save(servers)
                TunnelState.log("Configuration verrouillée importée")
                return null
            }
            return err
        }

        // 2) Liens vless:// classiques
        val found = VlessParser.extractLinks(raw)
        val parsed = found.mapNotNull { VlessParser.toServer(it) }
        val fresh = parsed.filter { p -> servers.none { it.link == p.link } }
        return when {
            found.isEmpty() -> "Aucun lien vless:// ni code NMA1 trouvé dans le texte collé"
            parsed.isEmpty() -> "Lien invalide : format attendu vless://uuid@hote:port?..."
            fresh.isEmpty() -> "Ce serveur existe déjà"
            else -> {
                servers.removeAll { it.link == null }
                servers.addAll(fresh)
                store.save(servers)
                selected = fresh.last()
                TunnelState.log("${fresh.size} serveur(s) importé(s)")
                fresh.forEach { s -> scope.launch { pingServer(s) } }
                null
            }
        }
    }

    Scaffold(
        containerColor = NmaColors.Navy,
        bottomBar = { BottomBar(tab) { tab = it; showAdmin = false } }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            if (showAdmin) {
                AdminScreen(
                    servers = servers,
                    unlocked = adminUnlocked,
                    onUnlock = { adminUnlocked = true },
                    onBack = { showAdmin = false; adminUnlocked = false }
                )
            } else {
                when (tab) {
                    0 -> HomeScreen(selected = selected, onOpenServers = { tab = 1 })
                    1 -> ServersScreen(
                        servers = servers,
                        selected = selected,
                        onSelect = { selected = it; tab = 0 },
                        onRefresh = { servers.toList().forEach { s -> scope.launch { pingServer(s) } } },
                        onImport = { raw -> handleImport(raw) },
                        onDelete = { s ->
                            if (s.code != null) servers.removeAll { it.code == s.code } else servers.remove(s)
                            store.save(servers)
                            if (servers.isEmpty()) servers.add(Server("Aucun serveur", "VLESS"))
                            if (servers.none { it == selected }) selected = servers.first()
                            TunnelState.log("Serveur supprimé")
                        }
                    )
                    2 -> LogsScreen()
                    else -> MoreScreen(onAdmin = { showAdmin = true })
                }
            }
        }
    }
}

@Composable
fun HomeScreen(selected: Server, onOpenServers: () -> Unit) {
    val ctx = LocalContext.current
    val status = TunnelState.status
    val connected = status == TunnelState.Status.CONNECTED
    val connecting = status == TunnelState.Status.CONNECTING

    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) { now = System.currentTimeMillis(); delay(1000) }
    }
    val trustedNow = remember(now) { TrustedTime.now(ctx) }

    fun startVpn() {
        val i = Intent(ctx, NmaVpnService::class.java)
            .putExtra(NmaVpnService.EXTRA_LINK, selected.link)
            .putExtra(NmaVpnService.EXTRA_EXPIRES, selected.expiresAt)
            .putExtra(NmaVpnService.EXTRA_LOCKED, selected.locked)
        ContextCompat.startForegroundService(ctx, i)
    }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        if (it.resultCode == Activity.RESULT_OK) startVpn()
    }
    fun toggle() {
        if (connected || connecting) {
            ctx.startService(Intent(ctx, NmaVpnService::class.java).setAction(NmaVpnService.ACTION_STOP))
            return
        }
        if (selected.link == null) {
            TunnelState.error = "Importe d'abord un serveur (onglet Servers)"
            return
        }
        if (selected.locked && selected.expiresAt > 0L && TrustedTime.now(ctx) >= selected.expiresAt) {
            TunnelState.error = "Configuration expirée. Demande un nouveau code."
            return
        }
        TunnelState.error = null
        val i = VpnService.prepare(ctx)
        if (i != null) permLauncher.launch(i) else startVpn()
    }

    val statusColor = when {
        connected -> NmaColors.Connected
        connecting -> Color(0xFFFFC857)
        else -> NmaColors.Accent
    }
    val statusText = when {
        connected -> "CONNECTED"
        connecting -> "CONNECTING…"
        else -> "CONNECT"
    }
    val serverPing = TunnelState.pings[selected.key()]
    val pingText = when {
        connected && TunnelState.pingMs >= 0 -> "${TunnelState.pingMs} ms"
        connected -> "— ms"
        serverPing != null && serverPing >= 0 -> "$serverPing ms"
        else -> "— ms"
    }
    val seconds = if (connected && TunnelState.connectedAt > 0)
        ((now - TunnelState.connectedAt) / 1000).coerceAtLeast(0) else 0L

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // En-tête
        Row(Modifier.fillMaxWidth().padding(top = 16.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(50.dp).border(1.dp, NmaColors.NavyBorder, RoundedCornerShape(12.dp))
                    .background(NmaColors.NavyCard, RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center
            ) { Icon(Icons.Filled.Shield, null, tint = NmaColors.Accent) }
            Spacer(Modifier.width(10.dp))
            Column {
                Row {
                    Text("NMA", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
                    Text("TUNNEL", color = NmaColors.Accent, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
                }
                Text("VPN • FAST • SECURE", color = NmaColors.TextSecondary, fontSize = 9.sp)
            }
            Spacer(Modifier.weight(1f))
            Row(
                Modifier.height(50.dp).background(NmaColors.NavyCard, RoundedCornerShape(16.dp))
                    .border(1.dp, NmaColors.NavyBorder, RoundedCornerShape(16.dp))
                    .clickable { onOpenServers() }.padding(horizontal = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(selected.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp, maxLines = 1)
                    Text(selected.protocol, color = NmaColors.TextSecondary, fontSize = 11.sp)
                }
                Icon(Icons.Filled.ChevronRight, null, tint = NmaColors.TextSecondary)
            }
        }

        Spacer(Modifier.height(28.dp))

        // Bouton power avec anneau
        Box(Modifier.size(240.dp).clickable { toggle() }, contentAlignment = Alignment.Center) {
            Canvas(Modifier.fillMaxSize()) {
                val stroke = 10.dp.toPx()
                val brush = when {
                    connected -> Brush.sweepGradient(listOf(NmaColors.Connected, NmaColors.Cyan, NmaColors.Connected))
                    connecting -> Brush.sweepGradient(listOf(Color(0xFFFFC857), NmaColors.Cyan, Color(0xFFFFC857)))
                    else -> Brush.sweepGradient(listOf(NmaColors.Accent, NmaColors.Cyan, NmaColors.AccentSoft, NmaColors.Accent))
                }
                drawArc(
                    brush = brush,
                    startAngle = 0f, sweepAngle = 360f, useCenter = false,
                    topLeft = Offset(stroke / 2, stroke / 2),
                    size = Size(size.width - stroke, size.height - stroke),
                    style = Stroke(stroke, cap = StrokeCap.Round)
                )
            }
            Box(
                Modifier.size(200.dp).clip(CircleShape).background(NmaColors.NavyCard)
                    .border(1.dp, NmaColors.NavyBorder, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Filled.PowerSettingsNew, null, tint = Color.White, modifier = Modifier.size(72.dp))
            }
        }

        Spacer(Modifier.height(16.dp))
        Text(statusText, color = statusColor, fontSize = 32.sp, fontWeight = FontWeight.ExtraBold)
        Text("Tunnel status", color = NmaColors.TextSecondary, fontSize = 14.sp)
        TunnelState.error?.let {
            Spacer(Modifier.height(6.dp))
            Text(it, color = Color(0xFFFF6B6B), fontSize = 13.sp)
        }

        Spacer(Modifier.height(16.dp))

        // Serveur sélectionné (avec son ping)
        Row(
            Modifier.fillMaxWidth().border(BorderStroke(1.5.dp, NmaColors.Accent), RoundedCornerShape(16.dp))
                .clickable { onOpenServers() }.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                if (selected.locked) Icons.Filled.Lock else Icons.Outlined.Dns,
                null, tint = NmaColors.Accent, modifier = Modifier.size(32.dp)
            )
            Spacer(Modifier.width(16.dp))
            Column(Modifier.weight(1f)) {
                Text("SELECTED SERVER", color = NmaColors.TextSecondary, fontSize = 12.sp)
                Text(selected.name, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1)
                Text(selected.protocol, color = NmaColors.TextSecondary, fontSize = 14.sp)
            }
            if (selected.link != null) {
                Text(pingLabel(serverPing), color = pingColor(serverPing), fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Spacer(Modifier.width(8.dp))
            }
            Icon(Icons.Filled.ChevronRight, null, tint = NmaColors.Accent)
        }

        if (selected.locked && selected.expiresAt > 0L) {
            val left = selected.expiresAt - trustedNow
            Spacer(Modifier.height(8.dp))
            Text(
                "Configuration verrouillée • ${remainingText(left)}",
                color = if (left <= 0L) Color(0xFFFF6B6B) else NmaColors.TextSecondary,
                fontSize = 13.sp
            )
        }

        Spacer(Modifier.height(12.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatCard("Download", TunnelState.downBytes, TunnelState.downBps, Modifier.weight(1f))
            StatCard("Upload", TunnelState.upBytes, TunnelState.upBps, Modifier.weight(1f))
        }

        Spacer(Modifier.height(12.dp))

        Row(
            Modifier.fillMaxWidth().background(NmaColors.NavyCard, RoundedCornerShape(16.dp)).padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            val h = seconds / 3600; val m = (seconds % 3600) / 60; val s = seconds % 60
            Text("Duration :  %02d:%02d:%02d".format(h, m, s), color = Color.White, fontWeight = FontWeight.Bold)
            Text("Ping :  $pingText", color = Color.White, fontWeight = FontWeight.Bold)
        }

        Spacer(Modifier.height(12.dp))
        Text("BY NMA", color = NmaColors.TextSecondary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(12.dp))
    }
}

@Composable
fun StatCard(label: String, bytes: Long, bps: Long, modifier: Modifier = Modifier) {
    val mb = bytes / 1048576.0
    val kbps = bps * 8 / 1000.0
    Column(modifier.background(NmaColors.NavyCard, RoundedCornerShape(16.dp)).padding(16.dp)) {
        Text(label, color = NmaColors.TextSecondary, fontSize = 15.sp)
        Row(verticalAlignment = Alignment.Bottom) {
            Text("%.2f".format(mb), color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
            Spacer(Modifier.width(4.dp))
            Text("MB", color = NmaColors.TextSecondary, fontSize = 13.sp, modifier = Modifier.padding(bottom = 4.dp))
        }
        Text("%.2f Kbps".format(kbps), color = NmaColors.TextSecondary, fontSize = 12.sp)
    }
}

@Composable
fun ServersScreen(
    servers: List<Server>,
    selected: Server,
    onSelect: (Server) -> Unit,
    onRefresh: () -> Unit,
    onImport: (String) -> String?,
    onDelete: (Server) -> Unit
) {
    val ctx = LocalContext.current
    var showDialog by remember { mutableStateOf(false) }
    var text by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    val clipboard = LocalClipboardManager.current

    var nowT by remember { mutableLongStateOf(TrustedTime.now(ctx)) }
    LaunchedEffect(Unit) {
        while (true) { delay(30_000); nowT = TrustedTime.now(ctx) }
    }

    if (showDialog) {
        AlertDialog(
            onDismissRequest = { showDialog = false },
            containerColor = NmaColors.NavyCard,
            title = { Text("Importer un serveur", color = Color.White) },
            text = {
                Column {
                    OutlinedTextField(
                        value = text,
                        onValueChange = { text = it; error = null },
                        placeholder = { Text("vless://… ou NMA1.…") },
                        isError = error != null,
                        modifier = Modifier.fillMaxWidth()
                    )
                    error?.let { Text(it, color = Color(0xFFFF6B6B), fontSize = 12.sp) }
                    TextButton(onClick = { clipboard.getText()?.let { text = it.text; error = null } }) {
                        Text("Coller depuis le presse-papiers", color = NmaColors.Accent)
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val err = onImport(text)
                    if (err == null) { showDialog = false; text = "" } else error = err
                }) { Text("Importer", color = NmaColors.Accent) }
            },
            dismissButton = {
                TextButton(onClick = { showDialog = false }) { Text("Annuler", color = NmaColors.TextSecondary) }
            }
        )
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Servers", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold,
                modifier = Modifier.weight(1f))
            IconButton(onClick = onRefresh) {
                Icon(Icons.Filled.Refresh, "Actualiser les pings", tint = NmaColors.Accent)
            }
            Button(
                onClick = { error = null; showDialog = true },
                colors = ButtonDefaults.buttonColors(containerColor = NmaColors.Accent)
            ) { Text("+ Importer") }
        }
        Spacer(Modifier.height(16.dp))
        servers.forEach { s ->
            val active = s == selected
            val ping = TunnelState.pings[s.key()]
            val left = s.expiresAt - nowT
            Row(
                Modifier.fillMaxWidth().padding(bottom = 10.dp)
                    .background(NmaColors.NavyCard, RoundedCornerShape(14.dp))
                    .border(if (active) 1.5.dp else 1.dp, if (active) NmaColors.Accent else NmaColors.NavyBorder, RoundedCornerShape(14.dp))
                    .clickable { onSelect(s) }.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(if (s.locked) Icons.Filled.Lock else Icons.Outlined.Dns, null, tint = NmaColors.Accent)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(s.name, color = Color.White, fontWeight = FontWeight.Bold)
                    Text(
                        if (s.locked) "${s.protocol} • verrouillé" else s.protocol,
                        color = NmaColors.TextSecondary, fontSize = 12.sp
                    )
                    if (s.locked && s.expiresAt > 0L) {
                        Text(
                            remainingText(left),
                            color = if (left <= 0L) Color(0xFFFF6B6B) else NmaColors.TextSecondary,
                            fontSize = 12.sp
                        )
                    }
                }
                if (s.link != null) {
                    Text(pingLabel(ping), color = pingColor(ping), fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    IconButton(onClick = { onDelete(s) }) {
                        Icon(Icons.Filled.Delete, "Supprimer", tint = NmaColors.TextSecondary)
                    }
                }
            }
        }
    }
}

@Composable
fun LogsScreen() {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Text("Logs", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
        Spacer(Modifier.height(16.dp))
        if (TunnelState.logs.isEmpty()) {
            Text("Aucun log pour le moment", color = NmaColors.TextSecondary)
        }
        TunnelState.logs.asReversed().forEach {
            Text("• $it", color = NmaColors.TextSecondary, fontSize = 13.sp, modifier = Modifier.padding(vertical = 3.dp))
        }
    }
}

@Composable
fun MoreScreen(onAdmin: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("More", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
        Spacer(Modifier.height(16.dp))
        Row(
            Modifier.fillMaxWidth().padding(bottom = 10.dp)
                .background(NmaColors.NavyCard, RoundedCornerShape(14.dp))
                .clickable { onAdmin() }.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Filled.Lock, null, tint = NmaColors.Accent)
            Spacer(Modifier.width(12.dp))
            Text("Espace admin (configurations verrouillées)", color = Color.White, modifier = Modifier.weight(1f))
            Icon(Icons.Filled.ChevronRight, null, tint = NmaColors.TextSecondary)
        }
        listOf("À propos de NMA Tunnel", "Version 1.2").forEach {
            Text(
                it, color = Color.White,
                modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp)
                    .background(NmaColors.NavyCard, RoundedCornerShape(14.dp)).padding(16.dp)
            )
        }
    }
}

@Composable
fun BottomBar(current: Int, onSelect: (Int) -> Unit) {
    val items: List<Pair<String, ImageVector>> = listOf(
        "Home" to Icons.Outlined.Home,
        "Servers" to Icons.Outlined.Dns,
        "Logs" to Icons.Outlined.History,
        "More" to Icons.Outlined.MoreHoriz
    )
    NavigationBar(containerColor = NmaColors.Navy) {
        items.forEachIndexed { i, (label, icon) ->
            NavigationBarItem(
                selected = current == i,
                onClick = { onSelect(i) },
                icon = { Icon(icon, label) },
                label = { Text(label) },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = NmaColors.Accent,
                    selectedTextColor = NmaColors.Accent,
                    unselectedIconColor = NmaColors.TextSecondary,
                    unselectedTextColor = NmaColors.TextSecondary,
                    indicatorColor = NmaColors.Navy
                )
            )
        }
    }
}
