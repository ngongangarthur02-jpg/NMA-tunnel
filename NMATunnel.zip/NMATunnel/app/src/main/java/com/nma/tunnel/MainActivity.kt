package com.nma.tunnel

import android.app.Activity
import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.Dns
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.MoreHoriz
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nma.tunnel.model.Server
import com.nma.tunnel.model.ServerStore
import com.nma.tunnel.model.VlessParser
import com.nma.tunnel.ui.theme.NmaColors
import com.nma.tunnel.ui.theme.NmaTunnelTheme
import com.nma.tunnel.vpn.NmaVpnService
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { NmaTunnelTheme { NmaApp() } }
    }
}

@Composable
fun NmaApp() {
    var tab by remember { mutableIntStateOf(0) }
    val context = androidx.compose.ui.platform.LocalContext.current
    val store = remember { ServerStore(context) }
    val servers = remember {
        mutableStateListOf<Server>().apply {
            addAll(store.load())
            if (isEmpty()) add(Server("Aucun serveur", "VLESS"))
        }
    }
    var selected by remember { mutableStateOf(servers.first()) }
    var connected by remember { mutableStateOf(NmaVpnService.running) }
    val logs = remember { mutableStateListOf("Application démarrée") }
    var seconds by remember { mutableIntStateOf(0) }

    LaunchedEffect(connected) {
        seconds = 0
        while (connected) { delay(1000); seconds++ }
    }

    Scaffold(
        containerColor = NmaColors.Navy,
        bottomBar = { BottomBar(tab) { tab = it } }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) {
                0 -> HomeScreen(
                    selected = selected,
                    connected = connected,
                    seconds = seconds,
                    onToggle = { c ->
                        connected = c
                        logs.add(if (c) "Connexion à ${selected.name}…" else "Déconnecté")
                    },
                    onOpenServers = { tab = 1 }
                )
                1 -> ServersScreen(
                    servers = servers,
                    selected = selected,
                    onSelect = { selected = it; tab = 0 },
                    onImport = { raw ->
                        val found = VlessParser.extractLinks(raw)
                        val parsed = found.mapNotNull { VlessParser.toServer(it) }
                        val fresh = parsed.filter { p -> servers.none { it.link == p.link } }
                        when {
                            found.isEmpty() -> "Aucun lien vless:// trouvé dans le texte collé"
                            parsed.isEmpty() -> "Lien invalide : format attendu vless://uuid@hote:port?..."
                            fresh.isEmpty() -> "Ce serveur existe déjà"
                            else -> {
                                servers.removeAll { it.link == null }
                                servers.addAll(fresh)
                                store.save(servers)
                                selected = fresh.last()
                                logs.add("${fresh.size} serveur(s) importé(s)")
                                null
                            }
                        }
                    },
                    onDelete = { s ->
                        servers.remove(s)
                        store.save(servers)
                        if (servers.isEmpty()) servers.add(Server("Aucun serveur", "VLESS"))
                        if (selected == s) selected = servers.first()
                        logs.add("Serveur supprimé : ${s.name}")
                    }
                )
                2 -> LogsScreen(logs)
                else -> MoreScreen()
            }
        }
    }
}

@Composable
fun HomeScreen(
    selected: Server,
    connected: Boolean,
    seconds: Int,
    onToggle: (Boolean) -> Unit,
    onOpenServers: () -> Unit
) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    fun start() {
        ctx.startService(Intent(ctx, NmaVpnService::class.java))
        onToggle(true)
    }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        if (it.resultCode == Activity.RESULT_OK) start()
    }
    fun toggle() {
        if (connected) {
            ctx.startService(Intent(ctx, NmaVpnService::class.java).setAction(NmaVpnService.ACTION_STOP))
            onToggle(false)
        } else {
            val i = VpnService.prepare(ctx)
            if (i != null) permLauncher.launch(i) else start()
        }
    }

    Column(
        Modifier.fillMaxSize().padding(horizontal = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // En-tête
        Row(Modifier.fillMaxWidth().padding(top = 16.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(50.dp).border(1.dp, NmaColors.NavyBorder, RoundedCornerShape(12.dp))
                    .background(NmaColors.NavyCard, RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center
            ) { Icon(Icons.Filled.Shield, null, tint = NmaColors.Accent) }
            Spacer(Modifier.width(10.dp))
            Column {
                Row {
                    Text("NMA", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
                    Text("TUNNEL", color = NmaColors.Accent, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
                }
                Text("VPN • FAST • SECURE", color = NmaColors.TextSecondary, fontSize = 9.sp)
            }
            Spacer(Modifier.weight(1f))
            Row(
                Modifier.height(50.dp).background(NmaColors.NavyCard, RoundedCornerShape(16.dp))
                    .border(1.dp, NmaColors.NavyBorder, RoundedCornerShape(16.dp))
                    .clickable { onOpenServers() }.padding(horizontal = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(selected.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Text(selected.protocol, color = NmaColors.TextSecondary, fontSize = 11.sp)
                }
                Icon(Icons.Filled.ChevronRight, null, tint = NmaColors.TextSecondary)
            }
        }

        Spacer(Modifier.height(36.dp))

        // Bouton power avec anneau
        Box(Modifier.size(240.dp).clickable { toggle() }, contentAlignment = Alignment.Center) {
            Canvas(Modifier.fillMaxSize()) {
                val stroke = 10.dp.toPx()
                val brush = Brush.sweepGradient(
                    listOf(NmaColors.Accent, NmaColors.Cyan, NmaColors.AccentSoft, NmaColors.Accent)
                )
                drawArc(
                    brush = if (connected) Brush.sweepGradient(listOf(NmaColors.Connected, NmaColors.Cyan, NmaColors.Connected)) else brush,
                    startAngle = 0f, sweepAngle = 360f, useCenter = false,
                    topLeft = Offset(stroke / 2, stroke / 2),
                    size = Size(size.width - stroke, size.height - stroke),
                    style = Stroke(stroke, cap = StrokeCap.Round)
                )
            }
            Box(
                Modifier.size(200.dp).clip(CircleShape).background(NmaColors.NavyCard)
                    .border(1.dp, NmaColors.NavyBorder, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Filled.PowerSettingsNew, null, tint = Color.White, modifier = Modifier.size(72.dp))
            }
        }

        Spacer(Modifier.height(20.dp))
        Text(
            if (connected) "CONNECTED" else "CONNECT",
            color = if (connected) NmaColors.Connected else NmaColors.Accent,
            fontSize = 32.sp, fontWeight = FontWeight.ExtraBold
        )
        Text("Tunnel status", color = NmaColors.TextSecondary, fontSize = 14.sp)

        Spacer(Modifier.height(20.dp))

        // Serveur sélectionné
        Row(
            Modifier.fillMaxWidth().border(BorderStroke(1.5.dp, NmaColors.Accent), RoundedCornerShape(16.dp))
                .clickable { onOpenServers() }.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Outlined.Dns, null, tint = NmaColors.Accent, modifier = Modifier.size(32.dp))
            Spacer(Modifier.width(16.dp))
            Column(Modifier.weight(1f)) {
                Text("SELECTED SERVER", color = NmaColors.TextSecondary, fontSize = 12.sp)
                Text(selected.name, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
                Text(selected.protocol, color = NmaColors.TextSecondary, fontSize = 14.sp)
            }
            Icon(Icons.Filled.ChevronRight, null, tint = NmaColors.Accent)
        }

        Spacer(Modifier.height(12.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatCard("Download", "0.00", Modifier.weight(1f))
            StatCard("Upload", "0.00", Modifier.weight(1f))
        }

        Spacer(Modifier.height(12.dp))

        Row(
            Modifier.fillMaxWidth().background(NmaColors.NavyCard, RoundedCornerShape(16.dp)).padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            val h = seconds / 3600; val m = (seconds % 3600) / 60; val s = seconds % 60
            Text("Duration :  %02d:%02d:%02d".format(h, m, s), color = Color.White, fontWeight = FontWeight.Bold)
            Text("Ping :  — ms", color = Color.White, fontWeight = FontWeight.Bold)
        }

        Spacer(Modifier.height(12.dp))
        Text("BY NMA", color = NmaColors.TextSecondary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun StatCard(label: String, mb: String, modifier: Modifier = Modifier) {
    Column(modifier.background(NmaColors.NavyCard, RoundedCornerShape(16.dp)).padding(16.dp)) {
        Text(label, color = NmaColors.TextSecondary, fontSize = 15.sp)
        Row(verticalAlignment = Alignment.Bottom) {
            Text(mb, color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
            Spacer(Modifier.width(4.dp))
            Text("MB", color = NmaColors.TextSecondary, fontSize = 13.sp, modifier = Modifier.padding(bottom = 4.dp))
        }
        Text("0.00 Kbps", color = NmaColors.TextSecondary, fontSize = 12.sp)
    }
}

@Composable
fun ServersScreen(
    servers: List<Server>,
    selected: Server,
    onSelect: (Server) -> Unit,
    onImport: (String) -> String?,
    onDelete: (Server) -> Unit
) {
    var showDialog by remember { mutableStateOf(false) }
    var text by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    val clipboard = androidx.compose.ui.platform.LocalClipboardManager.current

    if (showDialog) {
        AlertDialog(
            onDismissRequest = { showDialog = false },
            containerColor = NmaColors.NavyCard,
            title = { Text("Importer un lien VLESS", color = Color.White) },
            text = {
                Column {
                    OutlinedTextField(
                        value = text,
                        onValueChange = { text = it; error = null },
                        placeholder = { Text("vless://...") },
                        isError = error != null,
                        modifier = Modifier.fillMaxWidth()
                    )
                    error?.let { Text(it, color = Color(0xFFFF6B6B), fontSize = 12.sp) }
                    TextButton(onClick = { clipboard.getText()?.let { text = it.text; error = null } }) {
                        Text("Coller depuis le presse-papiers", color = NmaColors.Accent)
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val err = onImport(text)
                    if (err == null) { showDialog = false; text = "" } else error = err
                }) { Text("Importer", color = NmaColors.Accent) }
            },
            dismissButton = {
                TextButton(onClick = { showDialog = false }) { Text("Annuler", color = NmaColors.TextSecondary) }
            }
        )
    }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Servers", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold,
                modifier = Modifier.weight(1f))
            Button(
                onClick = { error = null; showDialog = true },
                colors = ButtonDefaults.buttonColors(containerColor = NmaColors.Accent)
            ) { Text("+ Importer") }
        }
        Spacer(Modifier.height(16.dp))
        servers.forEach { s ->
            val active = s == selected
            Row(
                Modifier.fillMaxWidth().padding(bottom = 10.dp)
                    .background(NmaColors.NavyCard, RoundedCornerShape(14.dp))
                    .border(if (active) 1.5.dp else 1.dp, if (active) NmaColors.Accent else NmaColors.NavyBorder, RoundedCornerShape(14.dp))
                    .clickable { onSelect(s) }.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Outlined.Dns, null, tint = NmaColors.Accent)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(s.name, color = Color.White, fontWeight = FontWeight.Bold)
                    Text(s.protocol, color = NmaColors.TextSecondary, fontSize = 12.sp)
                }
                if (s.link != null) {
                    IconButton(onClick = { onDelete(s) }) {
                        Icon(Icons.Filled.Delete, "Supprimer", tint = NmaColors.TextSecondary)
                    }
                }
            }
        }
    }
}

@Composable
fun LogsScreen(logs: List<String>) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Logs", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
        Spacer(Modifier.height(16.dp))
        logs.asReversed().forEach {
            Text("• $it", color = NmaColors.TextSecondary, modifier = Modifier.padding(vertical = 3.dp))
        }
    }
}

@Composable
fun MoreScreen() {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("More", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
        Spacer(Modifier.height(16.dp))
        listOf("Paramètres", "À propos de NMA Tunnel", "Version 1.0").forEach {
            Text(
                it, color = Color.White,
                modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp)
                    .background(NmaColors.NavyCard, RoundedCornerShape(14.dp)).padding(16.dp)
            )
        }
    }
}

@Composable
fun BottomBar(current: Int, onSelect: (Int) -> Unit) {
    val items: List<Pair<String, ImageVector>> = listOf(
        "Home" to Icons.Outlined.Home,
        "Servers" to Icons.Outlined.Dns,
        "Logs" to Icons.Outlined.History,
        "More" to Icons.Outlined.MoreHoriz
    )
    NavigationBar(containerColor = NmaColors.Navy) {
        items.forEachIndexed { i, (label, icon) ->
            NavigationBarItem(
                selected = current == i,
                onClick = { onSelect(i) },
                icon = { Icon(icon, label) },
                label = { Text(label) },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = NmaColors.Accent,
                    selectedTextColor = NmaColors.Accent,
                    unselectedIconColor = NmaColors.TextSecondary,
                    unselectedTextColor = NmaColors.TextSecondary,
                    indicatorColor = NmaColors.Navy
                )
            )
        }
    }
}
