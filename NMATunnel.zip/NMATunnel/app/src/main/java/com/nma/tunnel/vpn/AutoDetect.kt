package com.nma.tunnel.vpn

import com.nma.tunnel.model.ProxyConfig
import libv2ray.Libv2ray
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.Callable
import java.util.concurrent.ExecutorCompletionService
import java.util.concurrent.Executors

/**
 * Détection automatique de la configuration qui passe sur le réseau actuel
 * (pour les serveurs VLESS, VMess et Trojan).
 *
 * 1. Teste d'abord la configuration d'origine.
 * 2. Si elle ne répond pas, teste des variantes du même serveur (empreinte TLS,
 *    ALPN, ports usuels) en parallèle et garde la première qui répond.
 */
object AutoDetect {

    class Candidate(val label: String, val cfg: ProxyConfig)
    private class Result(val candidate: Candidate, val delayMs: Long)

    private val PROBE_URLS = listOf(
        "https://www.gstatic.com/generate_204",
        "https://cp.cloudflare.com/generate_204"
    )

    private val SUPPORTED = listOf("vless", "vmess", "trojan")

    fun supports(cfg: ProxyConfig): Boolean = cfg.type in SUPPORTED

    fun candidates(base: ProxyConfig): List<Candidate> {
        val out = ArrayList<Candidate>()
        val seen = HashSet<String>()

        fun add(label: String, cfg: ProxyConfig) {
            val key = cfg.port.toString() + cfg.params.toSortedMap().toString()
            if (seen.add(key)) out.add(Candidate(label, cfg))
        }
        fun variant(label: String, port: Int, extra: Map<String, String>) =
            add(label, base.copy(port = port, params = base.params + extra))

        add("configuration d'origine", base)

        val security = base.security()

        if (security == "tls" || security == "reality") {
            for (fp in listOf("chrome", "firefox", "safari", "android", "randomized")) {
                variant("empreinte TLS $fp", base.port, mapOf("fp" to fp))
            }
        }
        if (security == "tls") {
            variant("ALPN http/1.1", base.port, mapOf("alpn" to "http/1.1"))
            variant("ALPN h2,http/1.1", base.port, mapOf("alpn" to "h2,http/1.1"))
            for (p in listOf(443, 8443, 2053, 2083, 2087, 2096)) {
                variant("port $p", p, emptyMap())
            }
        } else if (security == "none") {
            for (p in listOf(80, 8080, 8880, 2052, 2082, 2086, 2095)) {
                variant("port $p", p, emptyMap())
            }
        }
        return out.take(14)
    }

    private fun tcpOpen(ip: String, port: Int): Boolean = try {
        Socket().use { it.connect(InetSocketAddress(ip, port), 2500) }
        true
    } catch (e: Exception) {
        false
    }

    private fun measure(c: Candidate, ip: String, urls: List<String>): Long {
        val json = XrayConfig.build(c.cfg, ip)
        for (url in urls) {
            try {
                val ms = Libv2ray.measureOutboundDelay(json, url)
                if (ms > 0) return ms
            } catch (e: Throwable) {
                // essai suivant
            }
        }
        return -1
    }

    /** Retourne la configuration qui fonctionne, ou null si aucune ne répond. */
    fun findWorking(
        base: ProxyConfig,
        ip: String,
        log: (String) -> Unit,
        isCancelled: () -> Boolean
    ): Candidate? {
        val all = candidates(base)
        val first = all.first()

        log("Test de la configuration d'origine…")
        val d = measure(first, ip, PROBE_URLS)
        if (d > 0) {
            log("Configuration d'origine OK ($d ms)")
            return first
        }
        log("Pas de réponse. Recherche d'une variante qui passe sur ce réseau…")

        val rest = all.drop(1)
        if (rest.isEmpty()) return null

        val pool = Executors.newFixedThreadPool(4)
        try {
            val service = ExecutorCompletionService<Result?>(pool)
            for (c in rest) {
                service.submit(Callable<Result?> {
                    if (isCancelled()) return@Callable null
                    if (c.cfg.port != base.port && !tcpOpen(ip, c.cfg.port)) {
                        log("Port ${c.cfg.port} fermé")
                        return@Callable null
                    }
                    val ms = measure(c, ip, PROBE_URLS.take(1))
                    if (ms > 0) {
                        log("Variante OK : ${c.label} ($ms ms)")
                        Result(c, ms)
                    } else {
                        log("Échec : ${c.label}")
                        null
                    }
                })
            }
            repeat(rest.size) {
                if (isCancelled()) return null
                val r = try { service.take().get() } catch (e: Exception) { null }
                if (r != null) return r.candidate
            }
            return null
        } finally {
            pool.shutdownNow()
        }
    }
}
