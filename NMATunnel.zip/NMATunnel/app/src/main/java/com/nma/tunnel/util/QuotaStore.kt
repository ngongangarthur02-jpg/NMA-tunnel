package com.nma.tunnel.util

import android.content.Context
import java.security.MessageDigest

/**
 * Consommation par code verrouillé (les serveurs d'un même code partagent le quota).
 * Gardée sur le téléphone ; la clé est une empreinte du code, jamais le code lui-même.
 */
object QuotaStore {
    private fun prefs(ctx: Context) = ctx.applicationContext.getSharedPreferences("nma_quota", Context.MODE_PRIVATE)

    fun key(code: String): String =
        MessageDigest.getInstance("SHA-256").digest(code.trim().toByteArray())
            .take(8).joinToString("") { "%02x".format(it) }

    private fun mac(key: String, v: Long): String {
        val m = javax.crypto.Mac.getInstance("HmacSHA256")
        m.init(javax.crypto.spec.SecretKeySpec(com.nma.tunnel.BuildConfig.MASTER_SECRET.toByteArray(), "HmacSHA256"))
        return m.doFinal("q$key:$v".toByteArray()).take(6).joinToString("") { "%02x".format(it) }
    }

    /** Consommation protégée par une signature : une valeur modifiée à la main est considérée comme épuisée. */
    fun used(ctx: Context, key: String): Long {
        if (key.isEmpty()) return 0L
        val raw = prefs(ctx).getString(key, null) ?: return 0L
        val i = raw.indexOf('|')
        val v = raw.substring(0, if (i < 0) raw.length else i).toLongOrNull()
        if (v == null || i < 0 || raw.substring(i + 1) != mac(key, v)) return Long.MAX_VALUE / 4
        return v
    }

    fun add(ctx: Context, key: String, bytes: Long) {
        if (key.isEmpty() || bytes <= 0L) return
        val v = used(ctx, key).coerceAtMost(Long.MAX_VALUE / 8) + bytes
        prefs(ctx).edit().putString(key, "$v|${mac(key, v)}").apply()
    }

    fun mb(quotaMb: Long): Long = quotaMb * 1024L * 1024L

    fun remaining(ctx: Context, key: String, quotaMb: Long): Long =
        (mb(quotaMb) - used(ctx, key)).coerceAtLeast(0L)

    fun format(bytes: Long): String {
        val units = listOf("B", "KB", "MB", "GB", "TB")
        var v = bytes.toDouble(); var i = 0
        while (v >= 1024.0 && i < units.size - 1) { v /= 1024.0; i++ }
        return (if (i == 0) "%.0f".format(v) else "%.2f".format(v)) + " " + units[i]
    }
}
