package com.nma.tunnel.vpn

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** État partagé entre le service VPN et l'interface. */
object TunnelState {
    enum class Status { DISCONNECTED, CONNECTING, CONNECTED }

    var status by mutableStateOf(Status.DISCONNECTED)
    var error by mutableStateOf<String?>(null)

    var upBytes by mutableLongStateOf(0L)      // total envoyé (octets)
    var downBytes by mutableLongStateOf(0L)    // total reçu (octets)
    var upBps by mutableLongStateOf(0L)        // octets / seconde
    var downBps by mutableLongStateOf(0L)
    var pingMs by mutableIntStateOf(-1)        // ping via le tunnel (-1 = inconnu)
    var connectedAt by mutableLongStateOf(0L)

    /** Ping TCP de chaque serveur : clé = lien. -2 = en cours, -1 = échec. */
    val pings = mutableStateMapOf<String, Int>()
    val logs = mutableStateListOf<String>()

    private val fmt = SimpleDateFormat("HH:mm:ss", Locale.getDefault())

    fun log(msg: String) {
        logs.add("${fmt.format(Date())}  $msg")
        while (logs.size > 200) logs.removeAt(0)
    }

    fun resetCounters() {
        upBytes = 0; downBytes = 0; upBps = 0; downBps = 0; pingMs = -1; connectedAt = 0
    }
}
