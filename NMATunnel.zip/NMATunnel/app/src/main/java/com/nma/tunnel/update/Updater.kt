package com.nma.tunnel.update

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.FileProvider
import com.nma.tunnel.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/**
 * Mise à jour intégrée : lit la dernière « release » GitHub, télécharge l'APK et lance l'installation.
 * Le dépôt doit être public (sinon GitHub refuse l'accès sans mot de passe).
 */
object Updater {
    const val REPO = "ngongangarthur02-jpg/NMA-tunnel"

    enum class Phase { IDLE, CHECKING, UP_TO_DATE, AVAILABLE, DOWNLOADING, READY, ERROR }

    var phase by mutableStateOf(Phase.IDLE)
    var latest by mutableStateOf("")
    var notes by mutableStateOf("")
    var progress by mutableIntStateOf(0)
    var error by mutableStateOf("")
    private var apkUrl = ""

    /** Compare deux versions « 1.10 » > « 1.9 ». */
    fun isNewer(remote: String, local: String): Boolean {
        fun parts(v: String) = v.trim().trimStart('v', 'V').split('.', '-')
            .map { it.takeWhile(Char::isDigit).toIntOrNull() ?: 0 }
        val a = parts(remote); val b = parts(local)
        for (i in 0 until maxOf(a.size, b.size)) {
            val x = a.getOrElse(i) { 0 }; val y = b.getOrElse(i) { 0 }
            if (x != y) return x > y
        }
        return false
    }

    private fun open(url: String): HttpURLConnection =
        (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 12_000
            readTimeout = 20_000
            instanceFollowRedirects = true
            setRequestProperty("User-Agent", "NMA-Tunnel")
            setRequestProperty("Accept", "application/vnd.github+json")
        }

    suspend fun check() {
        if (phase == Phase.CHECKING || phase == Phase.DOWNLOADING) return
        phase = Phase.CHECKING
        error = ""
        try {
            val json = withContext(Dispatchers.IO) {
                val c = open("https://api.github.com/repos/$REPO/releases/latest")
                try {
                    if (c.responseCode == 404) {
                        throw IllegalStateException(
                            "Aucune mise à jour publiée (ou dépôt privé : il doit être public)"
                        )
                    }
                    if (c.responseCode != 200) throw IllegalStateException("Erreur serveur ${c.responseCode}")
                    JSONObject(c.inputStream.bufferedReader().readText())
                } finally { c.disconnect() }
            }
            val tag = json.optString("tag_name")
            val assets = json.optJSONArray("assets")
            var url = ""
            if (assets != null) for (i in 0 until assets.length()) {
                val a = assets.getJSONObject(i)
                if (a.optString("name").endsWith(".apk")) { url = a.optString("browser_download_url"); break }
            }
            latest = tag.trimStart('v', 'V')
            notes = json.optString("body").trim()
            apkUrl = url
            phase = if (url.isNotEmpty() && isNewer(tag, BuildConfig.VERSION_NAME)) Phase.AVAILABLE
                else Phase.UP_TO_DATE
        } catch (e: Exception) {
            error = e.message ?: "Vérification impossible (pas de connexion ?)"
            phase = Phase.ERROR
        }
    }

    private fun apkFile(ctx: Context) = File(File(ctx.cacheDir, "updates"), "NMA-Tunnel.apk")

    suspend fun download(ctx: Context) {
        if (phase == Phase.DOWNLOADING || apkUrl.isEmpty()) return
        phase = Phase.DOWNLOADING
        progress = 0
        try {
            withContext(Dispatchers.IO) {
                val out = apkFile(ctx)
                out.parentFile?.mkdirs()
                val tmp = File(out.parentFile, "dl.tmp")
                val c = open(apkUrl)
                try {
                    if (c.responseCode != 200) throw IllegalStateException("Téléchargement refusé (${c.responseCode})")
                    val total = c.contentLengthLong
                    var done = 0L
                    c.inputStream.use { input ->
                        tmp.outputStream().use { o ->
                            val buf = ByteArray(32 * 1024)
                            while (true) {
                                val n = input.read(buf)
                                if (n < 0) break
                                o.write(buf, 0, n)
                                done += n
                                if (total > 0) progress = (done * 100 / total).toInt()
                            }
                        }
                    }
                    if (done < 1_000_000L) throw IllegalStateException("Fichier incomplet")
                } finally { c.disconnect() }
                out.delete()
                tmp.renameTo(out)
            }
            phase = Phase.READY
            install(ctx)
        } catch (e: Exception) {
            error = e.message ?: "Téléchargement impossible"
            phase = Phase.ERROR
        }
    }

    /** Ouvre l'installateur Android. Retourne un message si l'autorisation « sources inconnues » manque. */
    fun install(ctx: Context): String? {
        val f = apkFile(ctx)
        if (!f.exists()) return "Fichier introuvable, retélécharge la mise à jour"
        if (!ctx.packageManager.canRequestPackageInstalls()) {
            ctx.startActivity(
                Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${ctx.packageName}"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            return "Autorise NMA Tunnel à installer des applications, puis reviens et appuie sur Installer"
        }
        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", f)
        ctx.startActivity(
            Intent(Intent.ACTION_VIEW)
                .setDataAndType(uri, "application/vnd.android.package-archive")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        )
        return null
    }
}
