package com.nma.tunnel.model

import org.json.JSONObject

enum class Kind { TEXT, NUMBER, PASSWORD, CHOICE, MULTILINE }

data class Field(
    val key: String,
    val label: String,
    val kind: Kind = Kind.TEXT,
    val default: String = "",
    val options: List<String> = emptyList(),
    val hint: String = "",
    val showIf: ((Map<String, String>) -> Boolean)? = null
)

/** Description des formulaires « Add config manually ». */
object Forms {

    val V2RAY_TYPES: List<Pair<String, String>> = listOf(
        "VMess" to "vmess",
        "VLESS" to "vless",
        "Trojan" to "trojan",
        "Shadowsocks" to "ss",
        "SOCKS" to "socks",
        "HTTP" to "http",
        "WireGuard" to "wireguard",
        "Hysteria2" to "hysteria2",
        "Custom (JSON)" to "custom"
    )

    val SSH_MODES: List<String> = listOf(
        "SSH-Direct", "SSH-Proxy", "SSH-Payload", "SSH-Proxy-Payload",
        "SSH-TLS", "SSH-TLS-Proxy", "SSH-TLS-Payload", "SSH-TLS-Proxy-Payload", "SSH-DNSTT"
    )

    private val CORE_KEYS = setOf("name", "addr", "port", "secret")

    private fun core(secretLabel: String?, defaultPort: String): List<Field> {
        val list = mutableListOf(
            Field("name", "Nom"),
            Field("addr", "Adresse du serveur (IP ou domaine)"),
            Field("port", "Port", Kind.NUMBER, defaultPort)
        )
        if (secretLabel != null) list.add(Field("secret", secretLabel, Kind.PASSWORD))
        return list
    }

    private fun transport(defaultSecurity: String): List<Field> = listOf(
        Field("type", "Réseau (transport)", Kind.CHOICE, "tcp",
            listOf("tcp", "ws", "grpc", "httpupgrade", "xhttp", "h2")),
        Field("security", "Sécurité", Kind.CHOICE, defaultSecurity, listOf("none", "tls", "reality")),
        Field("sni", "SNI (nom TLS)", showIf = { it["security"] != "none" }),
        Field("fp", "Empreinte TLS", Kind.CHOICE, "chrome",
            listOf("chrome", "firefox", "safari", "ios", "android", "edge", "randomized"),
            showIf = { it["security"] != "none" }),
        Field("alpn", "ALPN (ex : h2,http/1.1)", showIf = { it["security"] == "tls" }),
        Field("allowInsecure", "Accepter un certificat non vérifié", Kind.CHOICE, "false",
            listOf("false", "true"), showIf = { it["security"] == "tls" }),
        Field("pbk", "Reality : clé publique", showIf = { it["security"] == "reality" }),
        Field("sid", "Reality : Short ID", showIf = { it["security"] == "reality" }),
        Field("spx", "Reality : SpiderX", showIf = { it["security"] == "reality" }),
        Field("host", "Host (en-tête HTTP)",
            showIf = { it["type"] in listOf("ws", "httpupgrade", "xhttp", "h2") }),
        Field("path", "Chemin (path)", default = "/",
            showIf = { it["type"] in listOf("ws", "httpupgrade", "xhttp", "h2") }),
        Field("serviceName", "gRPC : nom du service", showIf = { it["type"] == "grpc" })
    )

    fun fields(type: String): List<Field> = when (type) {
        "vless" -> core("UUID", "443") + listOf(
            Field("encryption", "Chiffrement", default = "none"),
            Field("flow", "Flow", Kind.CHOICE, "", listOf("", "xtls-rprx-vision"))
        ) + transport("tls")
        "vmess" -> core("UUID", "443") + listOf(
            Field("aid", "Alter ID", Kind.NUMBER, "0"),
            Field("scy", "Chiffrement", Kind.CHOICE, "auto",
                listOf("auto", "aes-128-gcm", "chacha20-poly1305", "none"))
        ) + transport("tls")
        "trojan" -> core("Mot de passe", "443") + transport("tls")
        "ss" -> core("Mot de passe", "8388") + listOf(
            Field("method", "Méthode de chiffrement", Kind.CHOICE, "aes-256-gcm",
                listOf("aes-256-gcm", "aes-128-gcm", "chacha20-ietf-poly1305",
                    "2022-blake3-aes-128-gcm", "2022-blake3-aes-256-gcm"))
        )
        "socks", "http" -> core(null, "1080") + listOf(
            Field("user", "Utilisateur (optionnel)"),
            Field("pass", "Mot de passe (optionnel)", Kind.PASSWORD)
        )
        "wireguard" -> core(null, "51820") + listOf(
            Field("secretKey", "Clé privée (la tienne)", Kind.PASSWORD),
            Field("wgAddress", "Adresse locale (ex : 10.0.0.2/32)"),
            Field("publicKey", "Clé publique du serveur"),
            Field("preSharedKey", "Clé pré-partagée (optionnel)", Kind.PASSWORD),
            Field("mtu", "MTU", Kind.NUMBER, "1280")
        )
        "hysteria2" -> core("Mot de passe (auth)", "443") + listOf(
            Field("sni", "SNI (nom TLS)"),
            Field("insecure", "Accepter un certificat non vérifié", Kind.CHOICE, "false",
                listOf("false", "true"))
        )
        "custom" -> listOf(
            Field("name", "Nom"),
            Field("json", "Configuration Xray complète (JSON)", Kind.MULTILINE,
                hint = "Colle ici un fichier de configuration Xray (sections « outbounds », etc.). " +
                    "NMA Tunnel remplace seulement les entrées (inbounds).")
        )
        "ssh" -> core(null, "22") + listOf(
            Field("user", "Utilisateur SSH"),
            Field("pass", "Mot de passe SSH", Kind.PASSWORD),
            Field("proxyHost", "Proxy HTTP : adresse",
                showIf = { (it["mode"] ?: "").contains("Proxy") }),
            Field("proxyPort", "Proxy HTTP : port", Kind.NUMBER, "8080",
                showIf = { (it["mode"] ?: "").contains("Proxy") }),
            Field("sni", "SNI / Host TLS (vide = adresse du serveur)",
                showIf = { (it["mode"] ?: "").contains("TLS") }),
            Field("payload", "Payload", Kind.MULTILINE,
                hint = "Variables : [host] [port] [host_port] [crlf] [cr] [lf] [split]",
                showIf = { (it["mode"] ?: "").contains("Payload") }),
            Field("dnsDomain", "DNSTT : domaine du tunnel",
                showIf = { it["mode"] == "SSH-DNSTT" }),
            Field("dnsServer", "DNSTT : serveur DNS",
                showIf = { it["mode"] == "SSH-DNSTT" }),
            Field("dnsKey", "DNSTT : clé publique",
                showIf = { it["mode"] == "SSH-DNSTT" })
        )
        else -> emptyList()
    }

    fun title(type: String, mode: String?): String =
        if (type == "ssh") (mode ?: "SSH-Direct")
        else V2RAY_TYPES.firstOrNull { it.second == type }?.first ?: type

    /** Valeurs de départ d'un nouveau formulaire. */
    fun defaults(type: String, mode: String?): Map<String, String> {
        val m = LinkedHashMap<String, String>()
        fields(type).forEach { if (it.default.isNotEmpty()) m[it.key] = it.default }
        if (type == "ssh") m["mode"] = mode ?: "SSH-Direct"
        return m
    }

    /** Valeurs d'un formulaire à partir d'une configuration existante (modification). */
    fun toValues(cfg: ProxyConfig): Map<String, String> {
        val m = LinkedHashMap<String, String>()
        m.putAll(defaults(cfg.type, cfg.params["mode"]))
        m["name"] = cfg.name
        m["addr"] = cfg.host
        if (cfg.port > 0) m["port"] = cfg.port.toString()
        m["secret"] = cfg.secret
        cfg.params.forEach { (k, v) -> m[k] = v }
        return m
    }

    /** Retourne un message d'erreur, ou null si le formulaire est correct. */
    fun validate(type: String, v: Map<String, String>): String? {
        fun blank(k: String) = v[k].isNullOrBlank()
        if (type == "custom") {
            val text = v["json"] ?: ""
            if (text.isBlank()) return "Colle la configuration JSON"
            return try {
                val o = JSONObject(text)
                if (!o.has("outbounds")) "Le JSON doit contenir une section « outbounds »" else null
            } catch (e: Exception) {
                "JSON invalide : ${e.message}"
            }
        }
        if (blank("addr")) return "Entre l'adresse du serveur"
        val port = v["port"]?.trim()?.toIntOrNull()
        if (port == null || port !in 1..65535) return "Port invalide (1 à 65535)"
        when (type) {
            "vless", "vmess" -> if (blank("secret")) return "Entre l'UUID"
            "trojan", "ss", "hysteria2" -> if (blank("secret")) return "Entre le mot de passe"
            "wireguard" -> {
                if (blank("secretKey")) return "Entre ta clé privée"
                if (blank("wgAddress")) return "Entre l'adresse locale"
                if (blank("publicKey")) return "Entre la clé publique du serveur"
            }
            "ssh" -> {
                if (blank("user")) return "Entre l'utilisateur SSH"
                if (blank("pass")) return "Entre le mot de passe SSH"
                val mode = v["mode"] ?: "SSH-Direct"
                if (mode.contains("Proxy")) {
                    if (blank("proxyHost")) return "Entre l'adresse du proxy"
                    val pp = v["proxyPort"]?.trim()?.toIntOrNull()
                    if (pp == null || pp !in 1..65535) return "Port du proxy invalide"
                }
                if (mode.contains("Payload") && blank("payload")) return "Entre le payload"
                if (mode == "SSH-DNSTT" && (blank("dnsDomain") || blank("dnsServer"))) {
                    return "Entre le domaine et le serveur DNS"
                }
            }
        }
        return null
    }

    /** Construit la configuration à partir du formulaire (à appeler après validate). */
    fun build(type: String, v: Map<String, String>): ProxyConfig {
        val params = LinkedHashMap<String, String>()
        v.forEach { (k, value) ->
            if (k !in CORE_KEYS && value.isNotBlank()) params[k] = value.trim()
        }
        if (type == "custom") {
            val json = (v["json"] ?: "").trim()
            params["json"] = json
            val name = v["name"]?.trim().orEmpty().ifBlank { "Custom" }
            return ProxyConfig(type, "", 0, name, "", params)
        }
        val addr = (v["addr"] ?: "").trim()
        val port = (v["port"] ?: "0").trim().toIntOrNull() ?: 0
        val name = v["name"]?.trim().orEmpty().ifBlank { addr }
        return ProxyConfig(type, addr, port, name, (v["secret"] ?: "").trim(), params)
    }
}
