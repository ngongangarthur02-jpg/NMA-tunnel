package com.nma.tunnel.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import com.nma.tunnel.settings.AppSettings

/** Couleurs de l'application : changent selon le thème (clair ou sombre). */
object NmaColors {
    var dark by mutableStateOf(true)

    val Navy: Color get() = if (dark) Color(0xFF0A1628) else Color(0xFFF2F6FC)
    val NavyCard: Color get() = if (dark) Color(0xFF10213D) else Color(0xFFFFFFFF)
    val NavyBorder: Color get() = if (dark) Color(0xFF1E3A66) else Color(0xFFCBD7EA)
    val Accent: Color get() = if (dark) Color(0xFF4DA3FF) else Color(0xFF1F6FEB)
    val AccentSoft: Color get() = Color(0xFF2F6FD6)
    val Cyan: Color get() = if (dark) Color(0xFF38D5F5) else Color(0xFF0EA5C9)
    val TextPrimary: Color get() = if (dark) Color(0xFFFFFFFF) else Color(0xFF0A1628)
    val TextSecondary: Color get() = if (dark) Color(0xFF8FA3C0) else Color(0xFF5B6B85)
    val Connected: Color get() = if (dark) Color(0xFF2ECC71) else Color(0xFF1FA463)
    val Error: Color get() = Color(0xFFFF6B6B)
    val Warn: Color get() = Color(0xFFFFC857)
}

@Composable
fun NmaTunnelTheme(content: @Composable () -> Unit) {
    val system = isSystemInDarkTheme()
    val dark = when (AppSettings.theme) {
        "light" -> false
        "dark" -> true
        else -> system
    }
    NmaColors.dark = dark

    val scheme = if (dark) {
        darkColorScheme(
            primary = NmaColors.Accent,
            background = NmaColors.Navy,
            surface = NmaColors.NavyCard,
            onPrimary = Color.White,
            onBackground = NmaColors.TextPrimary,
            onSurface = NmaColors.TextPrimary
        )
    } else {
        lightColorScheme(
            primary = NmaColors.Accent,
            background = NmaColors.Navy,
            surface = NmaColors.NavyCard,
            onPrimary = Color.White,
            onBackground = NmaColors.TextPrimary,
            onSurface = NmaColors.TextPrimary
        )
    }
    MaterialTheme(colorScheme = scheme, content = content)
}
