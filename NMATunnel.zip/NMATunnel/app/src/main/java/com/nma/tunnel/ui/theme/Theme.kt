package com.nma.tunnel.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

object NmaColors {
    val Navy = Color(0xFF0A1628)          // fond principal
    val NavyCard = Color(0xFF10213D)      // cartes
    val NavyBorder = Color(0xFF1E3A66)    // bordures
    val Accent = Color(0xFF4DA3FF)        // bleu clair d'accentuation
    val AccentSoft = Color(0xFF2F6FD6)
    val Cyan = Color(0xFF38D5F5)
    val TextPrimary = Color(0xFFFFFFFF)
    val TextSecondary = Color(0xFF8FA3C0)
    val Connected = Color(0xFF2ECC71)
}

private val NmaDarkScheme = darkColorScheme(
    primary = NmaColors.Accent,
    background = NmaColors.Navy,
    surface = NmaColors.NavyCard,
    onPrimary = Color.White,
    onBackground = Color.White,
    onSurface = Color.White
)

@Composable
fun NmaTunnelTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = NmaDarkScheme, content = content)
}
