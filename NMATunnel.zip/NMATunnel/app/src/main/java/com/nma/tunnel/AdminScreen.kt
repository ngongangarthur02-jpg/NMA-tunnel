package com.nma.tunnel

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nma.tunnel.lock.LockedConfig
import com.nma.tunnel.lock.TrustedTime
import com.nma.tunnel.model.Server
import com.nma.tunnel.ui.theme.NmaColors
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val ErrorRed = Color(0xFFFF6B6B)

/** Espace admin : protégé par mot de passe, il exporte des configurations verrouillées. */
@Composable
fun AdminScreen(
    servers: List<Server>,
    unlocked: Boolean,
    onUnlock: () -> Unit,
    onBack: () -> Unit
) {
    if (!unlocked) AdminGate(onUnlock, onBack) else AdminPanel(servers, onBack)
}

@Composable
private fun AdminGate(onUnlock: () -> Unit, onBack: () -> Unit) {
    var pw by remember { mutableStateOf("") }
    var wrong by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Espace admin", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
        Spacer(Modifier.height(8.dp))
        Text("Entre le mot de passe admin.", color = NmaColors.TextSecondary)
        Spacer(Modifier.height(16.dp))
        OutlinedTextField(
            value = pw,
            onValueChange = { pw = it; wrong = false },
            singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
            isError = wrong,
            modifier = Modifier.fillMaxWidth()
        )
        if (wrong) Text("Mot de passe incorrect", color = ErrorRed, fontSize = 13.sp)
        Spacer(Modifier.height(16.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            TextButton(onClick = onBack) { Text("Retour", color = NmaColors.TextSecondary) }
            Button(
                onClick = { if (LockedConfig.checkPassword(pw)) onUnlock() else wrong = true },
                colors = ButtonDefaults.buttonColors(containerColor = NmaColors.Accent)
            ) { Text("Déverrouiller") }
        }
    }
}

@Composable
private fun AdminPanel(servers: List<Server>, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val clipboard = LocalClipboardManager.current

    val exportable = servers.filter { !it.locked && it.link != null }
    val chosen = remember { mutableStateListOf<String>() }
    var name by remember { mutableStateOf("") }
    var days by remember { mutableStateOf("30") }
    var hours by remember { mutableStateOf("0") }
    var code by remember { mutableStateOf<String?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var copied by remember { mutableStateOf(false) }

    val now = TrustedTime.now(ctx)
    val month = LockedConfig.monthOf(now)
    val d = (days.toLongOrNull() ?: 0L).coerceIn(0L, 3650L)
    val h = (hours.toLongOrNull() ?: 0L).coerceIn(0L, 100_000L)
    val durationMs = (d * 24L + h) * 3_600_000L
    val expiryText = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date(now + durationMs))

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Espace admin", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold,
                modifier = Modifier.weight(1f))
            TextButton(onClick = onBack) { Text("Fermer", color = NmaColors.Accent) }
        }
        Spacer(Modifier.height(8.dp))

        Text(
            "Token du mois $month : ${LockedConfig.monthToken(month)}",
            color = NmaColors.Accent, fontWeight = FontWeight.Bold,
            modifier = Modifier.fillMaxWidth().background(NmaColors.NavyCard, RoundedCornerShape(14.dp)).padding(14.dp)
        )
        Text(
            "La clé de chiffrement change chaque mois. La durée de validité du code est celle que tu fixes ci-dessous.",
            color = NmaColors.TextSecondary, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp)
        )

        Spacer(Modifier.height(20.dp))
        Text("1. Nom du client", color = Color.White, fontWeight = FontWeight.Bold)
        OutlinedTextField(
            value = name, onValueChange = { name = it; code = null },
            placeholder = { Text("Ex : Jean") }, singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(Modifier.height(16.dp))
        Text("2. Serveurs à inclure", color = Color.White, fontWeight = FontWeight.Bold)
        if (exportable.isEmpty()) {
            Text("Importe d'abord un serveur (onglet Servers).", color = NmaColors.TextSecondary, fontSize = 13.sp)
        }
        exportable.forEach { s ->
            val link = s.link ?: return@forEach
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(
                    checked = link in chosen,
                    onCheckedChange = { on ->
                        if (on) chosen.add(link) else chosen.remove(link)
                        code = null
                    },
                    colors = CheckboxDefaults.colors(checkedColor = NmaColors.Accent)
                )
                Text(s.name, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }

        Spacer(Modifier.height(16.dp))
        Text("3. Durée avant expiration", color = Color.White, fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedTextField(
                value = days, onValueChange = { days = it.filter(Char::isDigit).take(4); code = null },
                label = { Text("Jours") }, singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.weight(1f)
            )
            OutlinedTextField(
                value = hours, onValueChange = { hours = it.filter(Char::isDigit).take(5); code = null },
                label = { Text("Heures") }, singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.weight(1f)
            )
        }
        Text(
            if (durationMs > 0) "Expire le $expiryText" else "Choisis au moins 1 heure",
            color = NmaColors.TextSecondary, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp)
        )

        Spacer(Modifier.height(20.dp))
        error?.let { Text(it, color = ErrorRed, fontSize = 13.sp, modifier = Modifier.padding(bottom = 8.dp)) }
        Button(
            onClick = {
                copied = false
                when {
                    chosen.isEmpty() -> error = "Coche au moins un serveur"
                    durationMs <= 0L -> error = "Choisis une durée d'au moins 1 heure"
                    else -> {
                        error = null
                        code = LockedConfig.create(name.trim().ifBlank { "NMA" }, chosen.toList(), now, durationMs)
                    }
                }
            },
            colors = ButtonDefaults.buttonColors(containerColor = NmaColors.Accent),
            modifier = Modifier.fillMaxWidth()
        ) { Text("Générer la configuration verrouillée") }

        code?.let { c ->
            Spacer(Modifier.height(20.dp))
            Text("Code à envoyer au client", color = Color.White, fontWeight = FontWeight.Bold)
            Text(
                c, color = NmaColors.TextSecondary, fontSize = 11.sp, maxLines = 5, overflow = TextOverflow.Ellipsis,
                modifier = Modifier.fillMaxWidth().padding(top = 6.dp)
                    .background(NmaColors.NavyCard, RoundedCornerShape(14.dp)).padding(12.dp)
            )
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedButton(
                    onClick = { clipboard.setText(AnnotatedString(c)); copied = true },
                    modifier = Modifier.weight(1f)
                ) { Text(if (copied) "Copié ✓" else "Copier", color = NmaColors.Accent) }
                OutlinedButton(
                    onClick = {
                        val send = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_TEXT, c)
                        }
                        ctx.startActivity(Intent.createChooser(send, "Partager la configuration"))
                    },
                    modifier = Modifier.weight(1f)
                ) { Text("Partager", color = NmaColors.Accent) }
            }
            Text(
                "Le client colle ce code dans Servers > + Importer. Il ne verra jamais le lien du serveur.",
                color = NmaColors.TextSecondary, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp)
            )
        }
        Spacer(Modifier.height(16.dp))
    }
}
