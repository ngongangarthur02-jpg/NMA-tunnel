package com.nma.tunnel

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import com.nma.tunnel.i18n.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nma.tunnel.lock.DeviceId
import com.nma.tunnel.util.HtmlMessage
import com.nma.tunnel.util.MESSAGE_MAX
import com.nma.tunnel.lock.LockedConfig
import com.nma.tunnel.lock.TrustedTime
import com.nma.tunnel.model.Server
import com.nma.tunnel.ui.theme.NmaColors
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val ErrorRed = Color(0xFFFF6B6B)

/** Espace admin : protégé par mot de passe, il exporte des configurations verrouillées. */
@Composable
fun AdminScreen(
    servers: List<Server>,
    unlocked: Boolean,
    onUnlock: () -> Unit,
    onBack: () -> Unit
) {
    if (!unlocked) AdminGate(onUnlock, onBack) else AdminPanel(servers, onBack)
}

@Composable
private fun AdminGate(onUnlock: () -> Unit, onBack: () -> Unit) {
    var pw by remember { mutableStateOf("") }
    var wrong by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Espace admin", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
        Spacer(Modifier.height(8.dp))
        Text("Entre le mot de passe admin.", color = NmaColors.TextSecondary)
        Spacer(Modifier.height(16.dp))
        OutlinedTextField(
            value = pw,
            onValueChange = { pw = it; wrong = false },
            singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
            isError = wrong,
            modifier = Modifier.fillMaxWidth()
        )
        if (wrong) Text("Mot de passe incorrect", color = ErrorRed, fontSize = 13.sp)
        Spacer(Modifier.height(16.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            TextButton(onClick = onBack) { Text("Retour", color = NmaColors.TextSecondary) }
            Button(
                onClick = { if (LockedConfig.checkPassword(pw)) onUnlock() else wrong = true },
                colors = ButtonDefaults.buttonColors(containerColor = NmaColors.Accent)
            ) { Text("Déverrouiller") }
        }
    }
}

@Composable
private fun AdminPanel(servers: List<Server>, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val clipboard = LocalClipboardManager.current

    val exportable = servers.filter { !it.locked && it.link != null }
    val chosen = remember { mutableStateListOf<String>() }
    var name by remember { mutableStateOf("") }
    var days by remember { mutableStateOf("30") }
    var hours by remember { mutableStateOf("0") }
    var minutes by remember { mutableStateOf("0") }
    var blockRoot by remember { mutableStateOf(false) }
    var quota by remember { mutableStateOf("") }
    var mode by remember { mutableStateOf("lock") }
    var openOut by remember { mutableStateOf<String?>(null) }
    var impDays by remember { mutableStateOf("0") }
    var impHours by remember { mutableStateOf("0") }
    var impMinutes by remember { mutableStateOf("0") }
    val importMs = (((impDays.toLongOrNull() ?: 0L).coerceIn(0L, 3650L) * 24L + (impHours.toLongOrNull() ?: 0L).coerceIn(0L, 100_000L)) * 60L + (impMinutes.toLongOrNull() ?: 0L).coerceIn(0L, 10_000_000L)) * 60_000L
    val quotaGb = quota.replace(',', '.').toDoubleOrNull() ?: 0.0
    val quotaMb = Math.round(quotaGb * 1024.0).coerceIn(0L, 10_000_000L)
    var message by remember { mutableStateOf("") }
    var ids by remember { mutableStateOf("") }
    var code by remember { mutableStateOf<String?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var copied by remember { mutableStateOf(false) }

    val now = TrustedTime.now(ctx)
    val month = LockedConfig.monthOf(now)
    val d = (days.toLongOrNull() ?: 0L).coerceIn(0L, 3650L)
    val h = (hours.toLongOrNull() ?: 0L).coerceIn(0L, 100_000L)
    val m = (minutes.toLongOrNull() ?: 0L).coerceIn(0L, 10_000_000L)
    val durationMs = ((d * 24L + h) * 60L + m) * 60_000L
    val expiryText = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date(now + durationMs))

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Espace admin", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold,
                modifier = Modifier.weight(1f))
            TextButton(onClick = onBack) { Text("Fermer", color = NmaColors.Accent) }
        }
        Spacer(Modifier.height(8.dp))

        Text(
            "Token du mois $month : ${LockedConfig.monthToken(month)}",
            color = NmaColors.Accent, fontWeight = FontWeight.Bold,
            modifier = Modifier.fillMaxWidth().background(NmaColors.NavyCard, RoundedCornerShape(14.dp)).padding(14.dp)
        )
        Text(
            "La clé de chiffrement change chaque mois. La durée de validité du code est celle que tu fixes ci-dessous.",
            color = NmaColors.TextSecondary, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp)
        )

        Spacer(Modifier.height(16.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("lock" to "🔒 Lock configurations", "open" to "🔓 Open configurations").forEach { (k, label) ->
                val on = mode == k
                Text(
                    label,
                    color = if (on) Color.White else NmaColors.TextPrimary,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 13.sp,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                    modifier = Modifier.weight(1f)
                        .background(if (on) NmaColors.Accent else NmaColors.NavyCard, RoundedCornerShape(10.dp))
                        .border(1.dp, NmaColors.NavyBorder, RoundedCornerShape(10.dp))
                        .clickable { mode = k; code = null; openOut = null; error = null }
                        .padding(vertical = 12.dp)
                )
            }
        }

        Spacer(Modifier.height(20.dp))
        Text("1. Nom du client", color = Color.White, fontWeight = FontWeight.Bold)
        OutlinedTextField(
            value = name, onValueChange = { name = it; code = null },
            placeholder = { Text("Ex : Jean") }, singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(Modifier.height(16.dp))
        Text("2. Serveurs à inclure", color = Color.White, fontWeight = FontWeight.Bold)
        if (exportable.isEmpty()) {
            Text("Importe d'abord un serveur (onglet Servers).", color = NmaColors.TextSecondary, fontSize = 13.sp)
        }
        exportable.forEach { s ->
            val link = s.link ?: return@forEach
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(
                    checked = link in chosen,
                    onCheckedChange = { on ->
                        if (on) chosen.add(link) else chosen.remove(link)
                        code = null; openOut = null
                    },
                    colors = CheckboxDefaults.colors(checkedColor = NmaColors.Accent)
                )
                Text(s.name, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }

        if (mode == "open") {
            Spacer(Modifier.height(16.dp))
            Text(
                "Configuration ouverte : le client voit les détails du serveur, peut la modifier et elle n'expire jamais. Pas de durée, de quota ni de blocage root.",
                color = NmaColors.TextSecondary, fontSize = 12.sp
            )
            Spacer(Modifier.height(12.dp))
            error?.let { Text(it, color = ErrorRed, fontSize = 13.sp, modifier = Modifier.padding(bottom = 8.dp)) }
            Button(
                onClick = {
                    if (chosen.isEmpty()) { error = "Coche au moins un serveur"; openOut = null }
                    else { error = null; openOut = chosen.joinToString("\n") }
                },
                colors = ButtonDefaults.buttonColors(containerColor = NmaColors.Accent),
                modifier = Modifier.fillMaxWidth()
            ) { Text("Générer la configuration ouverte") }
            openOut?.let { o ->
                Spacer(Modifier.height(16.dp))
                Text("Configuration ouverte à envoyer", color = Color.White, fontWeight = FontWeight.Bold)
                Text(
                    o, color = NmaColors.Accent, fontSize = 12.sp, maxLines = 6, overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.fillMaxWidth().padding(top = 6.dp)
                        .background(NmaColors.NavyCard, RoundedCornerShape(14.dp)).padding(12.dp)
                )
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedButton(
                        onClick = { clipboard.setText(AnnotatedString(o)); copied = true },
                        modifier = Modifier.weight(1f)
                    ) { Text(if (copied) "Copié ✓" else "Copier", color = NmaColors.Accent) }
                    OutlinedButton(
                        onClick = {
                            val send = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, o) }
                            ctx.startActivity(Intent.createChooser(send, "Partager la configuration"))
                        },
                        modifier = Modifier.weight(1f)
                    ) { Text("Partager", color = NmaColors.Accent) }
                }
                OutlinedButton(
                    onClick = {
                        val f = com.nma.tunnel.util.ImportInbox.writeFile(ctx, name.trim().ifBlank { "NMA" }, o)
                        val uri = androidx.core.content.FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", f)
                        val send = Intent(Intent.ACTION_SEND).apply {
                            type = "application/x-nma"
                            putExtra(Intent.EXTRA_STREAM, uri)
                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        }
                        ctx.startActivity(Intent.createChooser(send, "Envoyer le fichier .nma"))
                    },
                    modifier = Modifier.fillMaxWidth().padding(top = 10.dp)
                ) { Text("Exporter en fichier .nma", color = NmaColors.Accent) }
                Text(
                    "Le client colle ce texte (ou ouvre le fichier .nma) dans Servers > + Ajouter. Il verra et pourra modifier la configuration.",
                    color = NmaColors.TextSecondary, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp)
                )
            }
        } else {
        Spacer(Modifier.height(16.dp))
        Text("3. Durée avant expiration", color = Color.White, fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedTextField(
                value = days, onValueChange = { days = it.filter(Char::isDigit).take(4); code = null },
                label = { Text("Jours") }, singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.weight(1f)
            )
            OutlinedTextField(
                value = hours, onValueChange = { hours = it.filter(Char::isDigit).take(5); code = null },
                label = { Text("Heures") }, singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.weight(1f)
            )
            OutlinedTextField(
                value = minutes, onValueChange = { minutes = it.filter(Char::isDigit).take(6); code = null },
                label = { Text("Minutes") }, singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.weight(1f)
            )
        }
        Text(
            if (durationMs > 0) "Expire le $expiryText" else "Choisis au moins 1 minute",
            color = NmaColors.TextSecondary, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp)
        )

        Spacer(Modifier.height(16.dp))
        Text("4. Appareils autorisés (optionnel)", color = Color.White, fontWeight = FontWeight.Bold)
        OutlinedTextField(
            value = ids, onValueChange = { ids = it; code = null },
            placeholder = { Text("Un ID par ligne (NMAID.…)") },
            minLines = 3, modifier = Modifier.fillMaxWidth()
        )
        Text(
            "Chaque utilisateur copie son ID dans More > My public key. Si tu en mets ici, le fichier ne s'ouvre que sur ces appareils (il peut être publié sans risque). Laisse vide pour un code ouvert à tous.",
            color = NmaColors.TextSecondary, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp)
        )

        Spacer(Modifier.height(16.dp))
        Text("5. Message pour l'utilisateur (optionnel)", color = Color.White, fontWeight = FontWeight.Bold)
        OutlinedTextField(
            value = message, onValueChange = { message = it.take(MESSAGE_MAX); code = null },
            placeholder = { Text("Texte simple ou HTML : <b>gras</b>, <i>italique</i>, <big>grand</big>, <font color=\"green\">couleur</font>, <a href=\"https://t.me/…\">lien</a>") },
            minLines = 5, modifier = Modifier.fillMaxWidth()
        )
        Text(
            "${message.length}/$MESSAGE_MAX · Caché dans le code, affiché sur l'écran d'accueil du client. Le HTML est mis en forme chez le client.",
            color = NmaColors.TextSecondary, fontSize = 12.sp
        )

        if (message.isNotBlank()) {
            Text("Aperçu", color = NmaColors.TextSecondary, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
            Column(
                Modifier.fillMaxWidth().padding(top = 4.dp)
                    .background(NmaColors.NavyCard, RoundedCornerShape(12.dp)).padding(12.dp)
            ) { HtmlMessage(message) }
        }

        Spacer(Modifier.height(16.dp))
        Text("6. Sécurité", color = Color.White, fontWeight = FontWeight.Bold)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(
                checked = blockRoot,
                onCheckedChange = { blockRoot = it; code = null },
                colors = CheckboxDefaults.colors(checkedColor = NmaColors.Accent)
            )
            Text("Bloquer les appareils rootés", color = Color.White)
        }
        Text(
            "Le code sera refusé à l'import et à la connexion sur un téléphone rooté. Détection de bon niveau mais pas infaillible (un root bien masqué peut passer).",
            color = NmaColors.TextSecondary, fontSize = 12.sp
        )

        Spacer(Modifier.height(16.dp))
        Text("7. Quota de données (optionnel)", color = Color.White, fontWeight = FontWeight.Bold)
        OutlinedTextField(
            value = quota, onValueChange = { quota = it.filter { c -> c.isDigit() || c == '.' || c == ',' }.take(7); code = null },
            label = { Text("Quota en Go (vide = illimité)") }, singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
            modifier = Modifier.fillMaxWidth()
        )
        Text(
            if (quotaMb > 0L) "Le VPN se coupe quand $quota Go ont été consommés (Download + Upload), même avant l'expiration." else "Aucune limite de données.",
            color = NmaColors.TextSecondary, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp)
        )

        Spacer(Modifier.height(16.dp))
        Text("8. Délai d'importation (optionnel)", color = Color.White, fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedTextField(
                value = impDays, onValueChange = { impDays = it.filter(Char::isDigit).take(4); code = null },
                label = { Text("Jours") }, singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.weight(1f)
            )
            OutlinedTextField(
                value = impHours, onValueChange = { impHours = it.filter(Char::isDigit).take(5); code = null },
                label = { Text("Heures") }, singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.weight(1f)
            )
            OutlinedTextField(
                value = impMinutes, onValueChange = { impMinutes = it.filter(Char::isDigit).take(6); code = null },
                label = { Text("Minutes") }, singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.weight(1f)
            )
        }
        Text(
            if (importMs > 0L) "Le code doit être importé avant le " + SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date(now + importMs)) + ". Passé ce délai, il est refusé à l'import (les configurations déjà importées ne changent pas)."
            else "Aucune limite : le code peut être importé jusqu'à son expiration.",
            color = NmaColors.TextSecondary, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp)
        )

        Spacer(Modifier.height(20.dp))
        error?.let { Text(it, color = ErrorRed, fontSize = 13.sp, modifier = Modifier.padding(bottom = 8.dp)) }
        Button(
            onClick = {
                copied = false
                when {
                    chosen.isEmpty() -> error = "Coche au moins un serveur"
                    durationMs <= 0L -> error = "Choisis une durée d'au moins 1 minute"
                    else -> {
                        val lines = ids.lines().map { it.trim() }.filter { it.isNotEmpty() }
                        val devices = lines.mapNotNull { DeviceId.parseId(it) }
                        if (devices.size != lines.size) {
                            val bad = lines.indexOfFirst { DeviceId.parseId(it) == null } + 1
                            error = "ID invalide (ligne $bad) : il doit commencer par NMAID."
                        } else if (devices.size > LockedConfig.MAX_DEVICES) {
                            error = "Maximum ${LockedConfig.MAX_DEVICES} appareils par code"
                        } else {
                            error = null
                            code = LockedConfig.create(name.trim().ifBlank { "NMA" }, chosen.toList(), now, durationMs, devices, blockRoot, message, quotaMb, importMs)
                        }
                    }
                }
            },
            colors = ButtonDefaults.buttonColors(containerColor = NmaColors.Accent),
            modifier = Modifier.fillMaxWidth()
        ) { Text("Générer la configuration verrouillée") }

        code?.let { c ->
            Spacer(Modifier.height(20.dp))
            Text("Code à envoyer au client", color = Color.White, fontWeight = FontWeight.Bold)
            Text(
                c, color = NmaColors.TextSecondary, fontSize = 11.sp, maxLines = 5, overflow = TextOverflow.Ellipsis,
                modifier = Modifier.fillMaxWidth().padding(top = 6.dp)
                    .background(NmaColors.NavyCard, RoundedCornerShape(14.dp)).padding(12.dp)
            )
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedButton(
                    onClick = { clipboard.setText(AnnotatedString(c)); copied = true },
                    modifier = Modifier.weight(1f)
                ) { Text(if (copied) "Copié ✓" else "Copier", color = NmaColors.Accent) }
                OutlinedButton(
                    onClick = {
                        val send = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_TEXT, c)
                        }
                        ctx.startActivity(Intent.createChooser(send, "Partager la configuration"))
                    },
                    modifier = Modifier.weight(1f)
                ) { Text("Partager", color = NmaColors.Accent) }
            }
            OutlinedButton(
                onClick = {
                    val f = com.nma.tunnel.util.ImportInbox.writeFile(ctx, name.trim().ifBlank { "NMA" }, c)
                    val uri = androidx.core.content.FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", f)
                    val send = Intent(Intent.ACTION_SEND).apply {
                        type = "application/x-nma"
                        putExtra(Intent.EXTRA_STREAM, uri)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    ctx.startActivity(Intent.createChooser(send, "Envoyer le fichier .nma"))
                },
                modifier = Modifier.fillMaxWidth().padding(top = 10.dp)
            ) { Text("Exporter en fichier .nma", color = NmaColors.Accent) }
            Text(
                "Le client colle ce code (ou ouvre le fichier .nma) dans Servers > + Ajouter. Il ne verra jamais le lien du serveur.",
                color = NmaColors.TextSecondary, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp)
            )
        }
        }
        Spacer(Modifier.height(16.dp))
    }
}
