package com.nma.tunnel.vpn

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import androidx.core.app.NotificationCompat
import com.nma.tunnel.lock.TrustedTime
import com.nma.tunnel.model.VlessParser
import libv2ray.CoreCallbackHandler
import libv2ray.CoreController
import libv2ray.Libv2ray
import java.net.InetAddress
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.concurrent.thread

/**
 * Service VPN : ouvre l'interface TUN d'Android et la confie au cœur Xray
 * (libv2ray) qui envoie tout le trafic vers le serveur VLESS choisi.
 * Pour une configuration verrouillée, il masque les détails du serveur dans les logs
 * et coupe le tunnel dès que la date d'expiration est atteinte.
 */
class NmaVpnService : VpnService() {

    private var tun: ParcelFileDescriptor? = null
    private var controller: CoreController? = null
    private var worker: Thread? = null
    @Volatile private var active = false
    @Volatile private var expiresAt = 0L
    @Volatile private var isLocked = false
    private val pinging = AtomicBoolean(false)

    private val handler = object : CoreCallbackHandler {
        override fun onEmitStatus(code: Long, message: String?): Long {
            if (!isLocked && !message.isNullOrBlank()) TunnelState.log(message)
            return 0L
        }
        override fun shutdown(): Long = 0L
        override fun startup(): Long = 0L
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopTunnel()
            return START_NOT_STICKY
        }
        val link = intent?.getStringExtra(EXTRA_LINK)
        if (link.isNullOrBlank()) {
            stopSelf()
            return START_NOT_STICKY
        }
        expiresAt = intent?.getLongExtra(EXTRA_EXPIRES, 0L) ?: 0L
        isLocked = intent?.getBooleanExtra(EXTRA_LOCKED, false) ?: false
        startTunnel(link)
        return START_NOT_STICKY
    }

    private fun startTunnel(link: String) {
        startForeground(NOTIF_ID, buildNotification())
        stopWorkerOnly()
        TunnelState.error = null
        TunnelState.resetCounters()
        TunnelState.status = TunnelState.Status.CONNECTING
        TunnelState.log("Démarrage du tunnel…")

        worker = thread(name = "nma-core") {
            try {
                connect(link)
            } catch (e: InterruptedException) {
                // arrêt demandé
            } catch (e: Throwable) {
                val raw = e.message ?: e.javaClass.simpleName
                // Pour une config verrouillée, on ne montre pas de détails sur le serveur
                val msg = if (isLocked && e !is IllegalStateException) "Connexion impossible" else raw
                TunnelState.log("Erreur : $msg")
                TunnelState.error = msg
                stopTunnel(keepError = true)
            }
        }
    }

    private fun connect(link: String) {
        val say: (String) -> Unit = { if (!isLocked) TunnelState.log(it) }
        val cfg = VlessParser.parse(link) ?: throw IllegalArgumentException("Lien VLESS invalide")

        // Expiration : on vérifie avec l'heure d'Internet avant de démarrer
        if (expiresAt > 0L) {
            TrustedTime.sync(this)
            if (TrustedTime.now(this) >= expiresAt) {
                throw IllegalStateException("Configuration expirée")
            }
        }

        say("Résolution de ${cfg.host}…")
        val ip = InetAddress.getByName(cfg.host).hostAddress ?: cfg.host
        say("Serveur : $ip:${cfg.port}")

        Libv2ray.initCoreEnv(filesDir.absolutePath, "")

        // Détection automatique de la configuration qui passe sur ce réseau
        // (avant d'ouvrir le tunnel, donc le test sort par le réseau normal)
        val me = Thread.currentThread()
        val chosen = AutoDetect.findWorking(cfg, ip, { say(it) }, { me.isInterrupted })
        if (me.isInterrupted) throw InterruptedException()
        val finalCfg = if (chosen != null) {
            say("Configuration retenue : ${chosen.label}")
            chosen.cfg
        } else {
            say("Aucune variante n'a répondu, essai avec la configuration d'origine")
            cfg
        }

        val json = XrayConfig.build(finalCfg, ip)

        val pfd = Builder()
            .setSession("NMA Tunnel")
            .setMtu(1500)
            .addAddress("10.8.0.2", 32)
            .addRoute("0.0.0.0", 0)
            .addDnsServer("1.1.1.1")
            .addDnsServer("8.8.8.8")
            .addDisallowedApplication(packageName) // le trafic du cœur Xray sort hors du tunnel
            .establish() ?: throw IllegalStateException("Permission VPN refusée")
        tun = pfd

        val c = Libv2ray.newCoreController(handler)
        controller = c
        c.startLoop(json, pfd.fd)

        active = true
        TunnelState.connectedAt = System.currentTimeMillis()
        TunnelState.status = TunnelState.Status.CONNECTED
        TunnelState.log(if (isLocked) "Connecté" else "Connecté à ${cfg.name}")

        // Surveillance : trafic chaque seconde, ping toutes les 10 secondes,
        // expiration vérifiée chaque seconde
        var tick = 0
        while (active) {
            Thread.sleep(1000)
            readStats(c)
            if (tick % 10 == 2) measurePing(c)
            if (expiresAt > 0L) {
                if (tick % 600 == 599) {
                    thread(name = "nma-time") { TrustedTime.sync(this@NmaVpnService) }
                }
                if (TrustedTime.now(this) >= expiresAt) {
                    throw IllegalStateException("Configuration expirée")
                }
            }
            tick++
        }
    }

    private fun readStats(c: CoreController) {
        val raw = runCatching { c.queryAllOutboundTrafficStats() }.getOrDefault("")
        var up = 0L
        var down = 0L
        raw.split(";").forEach { entry ->
            val parts = entry.split(",")
            if (parts.size == 3 && parts[0] == "proxy") {
                val v = parts[2].toLongOrNull() ?: 0L
                if (parts[1] == "uplink") up += v else if (parts[1] == "downlink") down += v
            }
        }
        // Les compteurs sont remis à zéro à chaque lecture : la valeur = octets de la dernière seconde
        TunnelState.upBytes += up
        TunnelState.downBytes += down
        TunnelState.upBps = up
        TunnelState.downBps = down
    }

    private fun measurePing(c: CoreController) {
        if (!pinging.compareAndSet(false, true)) return
        thread(name = "nma-ping") {
            try {
                val ms = c.measureDelay("https://www.gstatic.com/generate_204").toInt()
                if (active) TunnelState.pingMs = ms
            } catch (e: Throwable) {
                if (active) TunnelState.pingMs = -1
            } finally {
                pinging.set(false)
            }
        }
    }

    private fun stopWorkerOnly() {
        active = false
        worker?.interrupt()
        worker = null
        runCatching { controller?.stopLoop() }
        controller = null
        runCatching { tun?.close() }
        tun = null
    }

    @Synchronized
    private fun stopTunnel(keepError: Boolean = false) {
        val wasRunning = TunnelState.status != TunnelState.Status.DISCONNECTED
        stopWorkerOnly()
        TunnelState.status = TunnelState.Status.DISCONNECTED
        TunnelState.resetCounters()
        if (!keepError) TunnelState.error = null
        if (wasRunning) TunnelState.log("Tunnel arrêté")
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onRevoke() {
        stopTunnel()
        super.onRevoke()
    }

    override fun onDestroy() {
        stopWorkerOnly()
        TunnelState.status = TunnelState.Status.DISCONNECTED
        super.onDestroy()
    }

    private fun buildNotification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "NMA Tunnel", NotificationManager.IMPORTANCE_LOW)
            )
        }
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("NMA Tunnel")
            .setContentText("Tunnel actif")
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setOngoing(true)
            .build()
    }

    companion object {
        const val ACTION_STOP = "com.nma.tunnel.STOP"
        const val EXTRA_LINK = "link"
        const val EXTRA_EXPIRES = "expires"
        const val EXTRA_LOCKED = "locked"
        private const val CHANNEL_ID = "nma_tunnel"
        private const val NOTIF_ID = 1
    }
}
