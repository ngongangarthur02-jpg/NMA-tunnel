package com.nma.tunnel.vpn

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Intent
import android.net.VpnService
import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import androidx.core.app.NotificationCompat
import com.nma.tunnel.lock.TrustedTime
import com.nma.tunnel.model.Links
import com.nma.tunnel.model.ProxyConfig
import com.nma.tunnel.settings.AppSettings
import libv2ray.CoreCallbackHandler
import libv2ray.CoreController
import libv2ray.Libv2ray
import java.net.InetAddress
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.concurrent.thread

/**
 * Service VPN : ouvre l'interface TUN d'Android et la confie au cœur Xray
 * (libv2ray) qui envoie tout le trafic vers le serveur choisi.
 * Pour une configuration verrouillée, il masque les détails du serveur dans les logs
 * et coupe le tunnel dès que la date d'expiration est atteinte.
 */
class NmaVpnService : VpnService() {

    private var tun: ParcelFileDescriptor? = null
    private var controller: CoreController? = null
    private var worker: Thread? = null
    private var ssh: SshTunnel? = null
    @Volatile private var active = false
    @Volatile private var expiresAt = 0L
    @Volatile private var quotaMb = 0L
    @Volatile private var quotaKey = ""
    @Volatile private var isLocked = false
    private val pinging = AtomicBoolean(false)
    private val restarting = AtomicBoolean(false)
    @Volatile private var failStreak = 0
    @Volatile private var lastDownAtPing = 0L
    @Volatile private var failLimit = 5
    private var netCallback: ConnectivityManager.NetworkCallback? = null
    private var primaryNet: Network? = null
    private var lostPrimary = false
    @Volatile private var lastAutoRestart = 0L
    @Volatile private var autoRestarts = 0

    private val handler = object : CoreCallbackHandler {
        override fun onEmitStatus(code: Long, message: String?): Long {
            if (!isLocked && !message.isNullOrBlank()) TunnelState.log(message)
            return 0L
        }
        override fun shutdown(): Long = 0L
        override fun startup(): Long = 0L
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopTunnel(userStop = true)
            return START_NOT_STICKY
        }
        if (intent?.action == ACTION_RESTART) {
            val l = lastLink
            if (l.isNullOrBlank() || TunnelState.status == TunnelState.Status.DISCONNECTED) {
                stopSelf()
                return START_NOT_STICKY
            }
            startTunnel(l, fresh = false)
            return START_NOT_STICKY
        }
        val link = intent?.getStringExtra(EXTRA_LINK)
        if (link.isNullOrBlank()) {
            stopSelf()
            return START_NOT_STICKY
        }
        expiresAt = intent.getLongExtra(EXTRA_EXPIRES, 0L)
        isLocked = intent.getBooleanExtra(EXTRA_LOCKED, false)
        quotaMb = intent.getLongExtra(EXTRA_QUOTA_MB, 0L)
        quotaKey = intent.getStringExtra(EXTRA_QUOTA_KEY) ?: ""
        if (quotaMb > 0L && com.nma.tunnel.util.QuotaStore.remaining(this, quotaKey, quotaMb) <= 0L) {
            TunnelState.error = "Quota de données épuisé"
            TunnelState.log("Quota de données épuisé")
            com.nma.tunnel.util.NotifStore.add(this, "quota-$quotaKey", "VPN arrêté", "Quota de données épuisé")
            startForeground(NOTIF_ID, buildNotification())
            stopSelf()
            return START_NOT_STICKY
        }
        if (intent.getBooleanExtra(EXTRA_BLOCK_ROOT, false) && com.nma.tunnel.util.RootCheck.isRooted(this)) {
            TunnelState.error = com.nma.tunnel.util.RootCheck.MESSAGE
            TunnelState.log(com.nma.tunnel.util.RootCheck.MESSAGE)
            startForeground(NOTIF_ID, buildNotification())
            stopSelf()
            return START_NOT_STICKY
        }
        lastLink = link
        startTunnel(link, fresh = true)
        return START_NOT_STICKY
    }

    /** [fresh] : vrai pour une connexion demandée par l'utilisateur (compteurs à zéro), faux pour une relance automatique. */
    private fun startTunnel(link: String, fresh: Boolean) {
        startForeground(NOTIF_ID, buildNotification())
        stopWorkerOnly()
        failStreak = 0
        lastDownAtPing = TunnelState.downBytes
        lastStatsNs = 0L
        watchNetwork()
        TunnelState.error = null
        if (fresh) TunnelState.resetCounters()
        TunnelState.hotspotActive = false
        TunnelState.pingMs = -1
        TunnelState.upBps = 0
        TunnelState.downBps = 0
        TunnelState.status = TunnelState.Status.CONNECTING
        TunnelState.log("Démarrage du tunnel…")

        worker = thread(name = "nma-core") {
            try {
                connect(link)
            } catch (e: InterruptedException) {
                // arrêt demandé
            } catch (e: Throwable) {
                val raw = e.message ?: e.javaClass.simpleName
                // Pour une config verrouillée, on ne montre pas de détails sur le serveur
                val msg = if (isLocked && e !is IllegalStateException) "Connexion impossible" else raw
                TunnelState.log("Erreur : $msg")
                com.nma.tunnel.util.NotifStore.add(this, "err-${System.currentTimeMillis() / 60000}", "VPN arrêté", msg)
                TunnelState.error = msg
                stopTunnel(keepError = true)
            }
        }
    }

    private fun connect(link: String) {
        val say: (String) -> Unit = { if (!isLocked) TunnelState.log(it) }
        val cfg = Links.fromLink(link) ?: throw IllegalArgumentException("Configuration invalide")

        // Expiration : on vérifie avec l'heure d'Internet avant de démarrer
        // (sans attendre : la resynchronisation se fait en arrière-plan pour que la connexion démarre tout de suite)
        if (expiresAt > 0L) {
            if (TrustedTime.now(this) >= expiresAt) {
                throw IllegalStateException("Configuration expirée")
            }
            thread(name = "nma-time0") { TrustedTime.sync(this@NmaVpnService) }
        }

        Libv2ray.initCoreEnv(filesDir.absolutePath, "")
        val hotspot = AppSettings.hotspotConfig(this)
        var serverIp = ""
        var sshPort = 0
        var finalCfg: ProxyConfig = cfg

        when (cfg.type) {
            "custom" -> say("Configuration personnalisée")
            "ssh" -> {
                if ((cfg.params["mode"] ?: "") == "SSH-DNSTT") {
                    throw IllegalStateException("SSH-DNSTT n'est pas encore pris en charge dans cette version")
                }
                val t = SshTunnel(cfg) { say(it) }
                ssh = t
                t.start()
                sshPort = t.socksPort
            }
            else -> {
                say("Résolution de ${cfg.host}…")
                serverIp = InetAddress.getByName(cfg.host).hostAddress ?: cfg.host
                say("Serveur : $serverIp:${cfg.port}")

                if (AutoDetect.supports(cfg)) {
                    // Détection automatique de la configuration qui passe sur ce réseau
                    // (avant d'ouvrir le tunnel, donc le test sort par le réseau normal)
                    val me = Thread.currentThread()
                    val chosen = AutoDetect.findWorking(cfg, serverIp, { say(it) }, { me.isInterrupted })
                    if (me.isInterrupted) throw InterruptedException()
                    if (chosen != null) {
                        say("Configuration retenue : ${chosen.label}")
                        finalCfg = chosen.cfg
                    } else {
                        say("Aucune variante n'a répondu, essai avec la configuration d'origine")
                    }
                }
            }
        }

        val json = XrayConfig.build(finalCfg, serverIp, hotspot, sshPort)

        val builder = Builder()
            .setSession("NMA Tunnel")
            .setMtu(adaptiveMtu())
            .addAddress("10.8.0.2", 32)
            .addRoute("0.0.0.0", 0)
            .addDnsServer("1.1.1.1")
            .addDnsServer("8.8.8.8")
            .addDisallowedApplication(packageName) // le trafic du cœur Xray sort hors du tunnel
        // Les applications ne voient pas le VPN comme une connexion « limitée » (téléchargements et vidéos plus fluides)
        if (Build.VERSION.SDK_INT >= 29) builder.setMetered(false)
        val pfd = builder.establish() ?: throw IllegalStateException("Permission VPN refusée")
        tun = pfd
        // Le VPN suit le réseau par défaut (Wi-Fi / 4G) : bascule plus propre quand le réseau change
        runCatching { setUnderlyingNetworks(null) }

        val c = Libv2ray.newCoreController(handler)
        controller = c
        c.startLoop(json, pfd.fd)

        active = true
        if (TunnelState.connectedAt == 0L) TunnelState.connectedAt = System.currentTimeMillis()
        TunnelState.status = TunnelState.Status.CONNECTED
        TunnelState.log(if (isLocked) "Connecté" else "Connecté à ${cfg.name}")
        if (hotspot != null) {
            TunnelState.hotspotActive = true
            TunnelState.log("Partage de connexion actif (SOCKS ${hotspot.socksPort}, HTTP ${hotspot.httpPort})")
        }

        // Surveillance : trafic chaque seconde, ping toutes les 10 secondes,
        // expiration vérifiée chaque seconde
        val eco = AppSettings.eco(this)
        val stepMs = if (eco) 2000L else 1000L
        val pingEvery = if (eco) 15 else 10      // toutes les 30 s (économie) ou 10 s
        val timeEvery = if (eco) 300 else 600    // resynchro de l'heure ~10 min
        failLimit = if (eco) 3 else 5
        var tick = 0
        while (active) {
            Thread.sleep(stepMs)
            readStats(c)
            if (quotaMb > 0L && com.nma.tunnel.util.QuotaStore.remaining(this, quotaKey, quotaMb) <= 0L) {
                throw IllegalStateException("Quota de données épuisé")
            }
            if (tick % pingEvery == 2) measurePing(c)
            val t = ssh
            if (t != null && !t.isAlive) {
                throw IllegalStateException("Connexion SSH perdue")
            }
            if (expiresAt > 0L) {
                if (tick % timeEvery == timeEvery - 1) {
                    thread(name = "nma-time") { TrustedTime.sync(this@NmaVpnService) }
                }
                if (TrustedTime.now(this) >= expiresAt) {
                    throw IllegalStateException("Configuration expirée")
                }
            }
            tick++
        }
    }

    @Volatile private var lastStatsNs = 0L

    /** Vitesse réelle : octets lus ÷ temps réellement écoulé depuis la lecture précédente (pas la durée prévue). */
    private fun readStats(c: CoreController) {
        val nowNs = System.nanoTime()
        val elapsedMs = if (lastStatsNs == 0L) 1000L else ((nowNs - lastStatsNs) / 1_000_000L).coerceAtLeast(200L)
        lastStatsNs = nowNs
        val raw = runCatching { c.queryAllOutboundTrafficStats() }.getOrDefault("")
        var up = 0L
        var down = 0L
        raw.split(";").forEach { entry ->
            val parts = entry.split(",")
            if (parts.size == 3 && parts[0] !in IGNORED_TAGS) {
                val v = parts[2].toLongOrNull() ?: 0L
                if (parts[1] == "uplink") up += v else if (parts[1] == "downlink") down += v
            }
        }
        // Les compteurs sont remis à zéro à chaque lecture : la valeur = octets de la dernière seconde
        if (quotaMb > 0L) com.nma.tunnel.util.QuotaStore.add(this, quotaKey, up + down)
        TunnelState.upBytes += up
        TunnelState.downBytes += down
        TunnelState.upBps = up * 1000L / elapsedMs
        TunnelState.downBps = down * 1000L / elapsedMs
    }

    private fun measurePing(c: CoreController) {
        if (!pinging.compareAndSet(false, true)) return
        thread(name = "nma-ping") {
            try {
                val ms = c.measureDelay("https://www.gstatic.com/generate_204").toInt()
                if (active) TunnelState.pingMs = ms
                lastDownAtPing = TunnelState.downBytes
                failStreak = 0
            } catch (e: Throwable) {
                if (active) TunnelState.pingMs = -3   // timeout : le serveur ne répond plus
                // Si des données circulent encore dans le tunnel, il est vivant : on ne coupe pas le réseau pour un ping raté
                val nowDown = TunnelState.downBytes
                val flowing = nowDown - lastDownAtPing > 2048L
                lastDownAtPing = nowDown
                if (flowing) {
                    failStreak = 0
                } else if (active && ++failStreak >= failLimit) {
                    failStreak = 0
                    restartSoon("Connexion instable, reconnexion automatique…")
                }
            } finally {
                pinging.set(false)
            }
        }
    }

    private fun stopWorkerOnly() {
        active = false
        unwatchNetwork()
        worker?.interrupt()
        worker = null
        runCatching { controller?.stopLoop() }
        controller = null
        runCatching { ssh?.stop() }
        ssh = null
        runCatching { tun?.close() }
        tun = null
    }

    @Synchronized
    /** [userStop] : seul un arrêt demandé par l'utilisateur remet les compteurs à zéro. */
    private fun stopTunnel(keepError: Boolean = false, userStop: Boolean = false) {
        val wasRunning = TunnelState.status != TunnelState.Status.DISCONNECTED
        stopWorkerOnly()
        TunnelState.status = TunnelState.Status.DISCONNECTED
        TunnelState.hotspotActive = false
        TunnelState.pingMs = -1
        TunnelState.upBps = 0
        TunnelState.downBps = 0
        if (userStop) TunnelState.resetCounters()
        if (!keepError) TunnelState.error = null
        if (wasRunning) TunnelState.log("Tunnel arrêté")
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onRevoke() {
        stopTunnel()
        super.onRevoke()
    }

    override fun onDestroy() {
        stopWorkerOnly()
        TunnelState.status = TunnelState.Status.DISCONNECTED
        super.onDestroy()
    }

    /** Relance le tunnel après une courte pause (réseau changé ou connexion devenue instable). */
    /** MTU adapté au réseau : plus petit en 4G/5G (moins de fragmentation, moins de blocages), normal en Wi-Fi. */
    private fun adaptiveMtu(): Int {
        val cm = getSystemService(ConnectivityManager::class.java) ?: return 1400
        val caps = runCatching {
            cm.allNetworks.mapNotNull { cm.getNetworkCapabilities(it) }
                .firstOrNull { it.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) && !it.hasTransport(NetworkCapabilities.TRANSPORT_VPN) && it.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED) }
        }.getOrNull()
        return if (caps != null && caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) 1380 else 1400
    }

    private fun restartSoon(reason: String, force: Boolean = false) {
        val now = System.currentTimeMillis()
        if (force) {
            // changement réel de réseau (Wi-Fi ↔ 4G) : on se reconnecte toujours, sans compter dans la limite
            if (now - lastAutoRestart < 3_000L) return
            if (!restarting.compareAndSet(false, true)) return
            lastAutoRestart = now
        } else {
            // jamais plus d'un redémarrage automatique toutes les 30 s, et pas de boucle sans fin
            if (now - lastAutoRestart < 30_000L) return
            if (now - lastAutoRestart > 300_000L) autoRestarts = 0
            if (autoRestarts >= 3) return
            if (!restarting.compareAndSet(false, true)) return
            lastAutoRestart = now
            autoRestarts++
        }
        TunnelState.log(reason)
        Handler(Looper.getMainLooper()).postDelayed({
            restarting.set(false)
            val l = lastLink
            if (l != null && TunnelState.status != TunnelState.Status.DISCONNECTED) startTunnel(l, fresh = false)
        }, 1500)
    }

    /**
     * Surveille le vrai réseau (Wi-Fi / 4G), jamais le VPN lui-même : sinon l'apparition du VPN
     * serait prise pour un changement de réseau et le tunnel redémarrerait sans fin.
     * On ne relance que si le réseau utilisé a disparu puis qu'un autre est revenu.
     */
    private fun watchNetwork() {
        val cm = getSystemService(ConnectivityManager::class.java) ?: return
        primaryNet = null
        lostPrimary = false
        val req = NetworkRequest.Builder()
            .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .addCapability(NetworkCapabilities.NET_CAPABILITY_NOT_VPN)
            .build()
        val cb = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                synchronized(this@NmaVpnService) {
                    if (primaryNet == null) {
                        val relaunch = lostPrimary
                        primaryNet = network
                        lostPrimary = false
                        if (relaunch && active) restartSoon("Réseau rétabli, reconnexion…", force = true)
                    }
                }
            }
            override fun onLost(network: Network) {
                synchronized(this@NmaVpnService) {
                    if (primaryNet == network) {
                        primaryNet = null
                        lostPrimary = true
                        // Passage Wi-Fi ↔ 4G : l'autre réseau est déjà là, aucun « onAvailable » ne viendra
                        val other = runCatching {
                            cm.allNetworks.firstOrNull { n ->
                                n != network && cm.getNetworkCapabilities(n)?.let {
                                    it.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
                                        !it.hasTransport(NetworkCapabilities.TRANSPORT_VPN)
                                } == true
                            }
                        }.getOrNull()
                        if (other != null) {
                            primaryNet = other
                            lostPrimary = false
                            if (active) restartSoon("Changement de réseau, reconnexion…", force = true)
                        }
                    }
                }
            }
        }
        netCallback = cb
        runCatching { cm.registerNetworkCallback(req, cb) }
    }

    private fun unwatchNetwork() {
        val cb = netCallback ?: return
        netCallback = null
        runCatching { getSystemService(ConnectivityManager::class.java)?.unregisterNetworkCallback(cb) }
    }

    private fun buildNotification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "NMA Tunnel", NotificationManager.IMPORTANCE_LOW)
            )
        }
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("NMA Tunnel")
            .setContentText(com.nma.tunnel.i18n.I18n.tr("Tunnel actif"))
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setOngoing(true)
            .build()
    }

    companion object {
        const val ACTION_STOP = "com.nma.tunnel.STOP"
        const val ACTION_RESTART = "com.nma.tunnel.RESTART"
        @Volatile private var lastLink: String? = null
        const val EXTRA_LINK = "link"
        const val EXTRA_EXPIRES = "expires"
        const val EXTRA_LOCKED = "locked"
        const val EXTRA_BLOCK_ROOT = "blockroot"
        const val EXTRA_QUOTA_MB = "quotamb"
        const val EXTRA_QUOTA_KEY = "quotakey"
        private const val CHANNEL_ID = "nma_tunnel"
        private const val NOTIF_ID = 1
        private val IGNORED_TAGS = setOf("direct", "block", "dns-out")
    }
}
