package com.nma.tunnel.vpn

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import androidx.core.app.NotificationCompat

/**
 * Service VPN de NMA Tunnel.
 *
 * Il ouvre l'interface TUN d'Android. Pour router réellement le trafic via VLESS,
 * il faut brancher un cœur (Xray-core / libv2ray) ici : lire le fd de [tun] et le
 * transmettre au cœur avec la configuration du serveur sélectionné.
 */
class NmaVpnService : VpnService() {

    private var tun: ParcelFileDescriptor? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return when (intent?.action) {
            ACTION_STOP -> {
                stopTunnel()
                START_NOT_STICKY
            }
            else -> {
                startTunnel()
                START_STICKY
            }
        }
    }

    private fun startTunnel() {
        startForeground(NOTIF_ID, buildNotification())
        if (tun != null) return
        tun = Builder()
            .setSession("NMA Tunnel")
            .addAddress("10.8.0.2", 32)
            .addRoute("0.0.0.0", 0)
            .addDnsServer("1.1.1.1")
            .addDnsServer("8.8.8.8")
            .setMtu(1500)
            .establish()
        running = tun != null
    }

    private fun stopTunnel() {
        running = false
        tun?.close()
        tun = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        stopTunnel()
        super.onDestroy()
    }

    private fun buildNotification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "NMA Tunnel", NotificationManager.IMPORTANCE_LOW)
            )
        }
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("NMA Tunnel")
            .setContentText("Tunnel actif")
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setOngoing(true)
            .build()
    }

    companion object {
        const val ACTION_STOP = "com.nma.tunnel.STOP"
        private const val CHANNEL_ID = "nma_tunnel"
        private const val NOTIF_ID = 1
        @Volatile var running = false
    }
}
