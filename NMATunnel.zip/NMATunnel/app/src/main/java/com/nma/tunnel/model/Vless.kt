package com.nma.tunnel.model

import java.net.URLDecoder

data class Server(val name: String, val protocol: String, val link: String? = null)

/** Résultat de l'analyse d'un lien vless:// */
data class VlessConfig(
    val uuid: String,
    val host: String,
    val port: Int,
    val name: String,
    val params: Map<String, String>
)

object VlessParser {

    private val LINK_REGEX = Regex("vless://\\S+", RegexOption.IGNORE_CASE)

    private fun decode(s: String): String =
        runCatching { URLDecoder.decode(s, "UTF-8") }.getOrDefault(s)

    /** Extrait tous les liens vless:// d'un texte (un ou plusieurs). */
    fun extractLinks(text: String): List<String> =
        LINK_REGEX.findAll(text).map { it.value.trim() }.toList()

    /** Analyse manuelle, tolérante : retourne null si le lien est invalide. */
    fun parse(raw: String): VlessConfig? {
        val link = raw.trim()
        if (!link.startsWith("vless://", ignoreCase = true)) return null
        var rest = link.substring("vless://".length)

        // Nom (fragment)
        var name = ""
        val hashIdx = rest.indexOf('#')
        if (hashIdx >= 0) {
            name = decode(rest.substring(hashIdx + 1)).trim()
            rest = rest.substring(0, hashIdx)
        }

        // Paramètres (query)
        var query = ""
        val qIdx = rest.indexOf('?')
        if (qIdx >= 0) {
            query = rest.substring(qIdx + 1)
            rest = rest.substring(0, qIdx)
        }

        // uuid@host:port
        val authority = rest.trimEnd('/')
        val at = authority.lastIndexOf('@')
        if (at <= 0) return null
        val uuid = authority.substring(0, at).trim()
        val hostPort = authority.substring(at + 1)

        val host: String
        val portStr: String
        if (hostPort.startsWith("[")) {
            val end = hostPort.indexOf(']')
            if (end < 0) return null
            host = hostPort.substring(1, end)
            portStr = hostPort.substring(end + 1).removePrefix(":")
        } else {
            val colon = hostPort.lastIndexOf(':')
            if (colon < 0) return null
            host = hostPort.substring(0, colon)
            portStr = hostPort.substring(colon + 1)
        }

        val port = portStr.trim().toIntOrNull() ?: return null
        if (uuid.isEmpty() || host.isBlank() || port !in 1..65535) return null

        val params = query.split("&")
            .filter { it.contains("=") }
            .associate {
                val (k, v) = it.split("=", limit = 2)
                k to decode(v)
            }

        return VlessConfig(uuid, host.trim(), port, name.ifBlank { host.trim() }, params)
    }

    fun toServer(raw: String): Server? =
        parse(raw)?.let { Server(it.name, "VLESS", raw.trim()) }
}
