package com.nma.tunnel.util

import java.net.NetworkInterface

/** Adresse IPv4 locale du téléphone sur une interface réseau. */
data class LocalAddress(val iface: String, val ip: String)

object NetInfo {
    /**
     * Adresses que les autres appareils peuvent joindre : Wi-Fi, point d'accès, USB, Bluetooth.
     * Les interfaces du VPN (tun) et de la boucle locale sont ignorées.
     */
    fun addresses(): List<LocalAddress> = try {
        NetworkInterface.getNetworkInterfaces().toList()
            .filter { it.isUp && !it.isLoopback && !it.name.startsWith("tun") && !it.name.startsWith("dummy") }
            .flatMap { ni ->
                ni.inetAddresses.toList()
                    .filter { !it.isLoopbackAddress && it.address.size == 4 }
                    .mapNotNull { a -> a.hostAddress?.let { LocalAddress(ni.name, it) } }
            }
            // d'abord le Wi-Fi / point d'accès, la 4G/5G (rmnet, ccmni) en dernier
            .sortedBy { if (it.iface.startsWith("rmnet") || it.iface.startsWith("ccmni")) 1 else 0 }
    } catch (e: Exception) {
        emptyList()
    }
}
