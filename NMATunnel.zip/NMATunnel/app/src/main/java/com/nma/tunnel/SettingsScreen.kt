package com.nma.tunnel

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import com.nma.tunnel.i18n.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nma.tunnel.settings.AppSettings
import com.nma.tunnel.ui.theme.NmaColors
import com.nma.tunnel.util.NotifStore
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Réglages : notifications de l'application (mises à jour, messages, expiration) et boîte de réception. */
@Composable
fun SettingsScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    var showPrivacy by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(false) }
    if (showPrivacy) {
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { showPrivacy = false },
            containerColor = NmaColors.NavyCard,
            title = { Text("Privacy policy", color = NmaColors.TextPrimary, fontWeight = FontWeight.Bold) },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    androidx.compose.material3.Text(
                        com.nma.tunnel.i18n.Privacy.updated(),
                        color = NmaColors.TextSecondary, fontSize = 12.sp
                    )
                    Spacer(Modifier.height(8.dp))
                    androidx.compose.material3.Text(
                        com.nma.tunnel.i18n.Privacy.text(),
                        color = NmaColors.TextPrimary, fontSize = 13.sp, lineHeight = 19.sp
                    )
                }
            },
            confirmButton = { TextButton(onClick = { showPrivacy = false }) { Text("Fermer", color = NmaColors.Accent) } }
        )
    }
    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    val fmt = SimpleDateFormat("dd/MM HH:mm", Locale.getDefault())

    // Les pastilles « non lu » restent visibles pendant la visite, puis tout passe en « lu » en quittant
    DisposableEffect(Unit) { onDispose { NotifStore.markAllRead(ctx) } }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Settings", color = NmaColors.TextPrimary, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold,
                modifier = Modifier.weight(1f))
            TextButton(onClick = onBack) { Text("Retour", color = NmaColors.TextSecondary) }
        }
        Spacer(Modifier.height(12.dp))

        Column(
            Modifier.fillMaxWidth().background(NmaColors.NavyCard, RoundedCornerShape(14.dp))
                .border(1.dp, NmaColors.NavyBorder, RoundedCornerShape(14.dp)).padding(16.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Notifications", color = NmaColors.TextPrimary, fontWeight = FontWeight.Bold)
                    Text(
                        "Être prévenu des mises à jour, des messages de ton fournisseur et de l'expiration de tes configurations.",
                        color = NmaColors.TextSecondary, fontSize = 12.sp
                    )
                }
                Switch(
                    checked = AppSettings.notifOn,
                    onCheckedChange = {
                        AppSettings.setNotif(ctx, it)
                        if (it && Build.VERSION.SDK_INT >= 33) permission.launch(Manifest.permission.POST_NOTIFICATIONS)
                    },
                    colors = SwitchDefaults.colors(checkedTrackColor = NmaColors.Accent)
                )
            }
        }

        Spacer(Modifier.height(16.dp))
        Column(
            Modifier.fillMaxWidth().background(NmaColors.NavyCard, RoundedCornerShape(14.dp))
                .border(1.dp, NmaColors.NavyBorder, RoundedCornerShape(14.dp)).padding(16.dp)
        ) {
            Text("Language", color = NmaColors.TextPrimary, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("auto" to "Auto", "fr" to "Français", "en" to "English").forEach { (k, label) ->
                    val on = AppSettings.lang == k
                    Text(
                        label,
                        color = if (on) androidx.compose.ui.graphics.Color.White else NmaColors.TextPrimary,
                        fontWeight = FontWeight.SemiBold,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                        modifier = Modifier.weight(1f)
                            .background(if (on) NmaColors.Accent else NmaColors.Navy, RoundedCornerShape(10.dp))
                            .border(1.dp, NmaColors.NavyBorder, RoundedCornerShape(10.dp))
                            .clickable { AppSettings.setLang(ctx, k) }
                            .padding(vertical = 12.dp)
                    )
                }
            }
        }

        Spacer(Modifier.height(16.dp))
        Row(
            Modifier.fillMaxWidth().background(NmaColors.NavyCard, RoundedCornerShape(14.dp))
                .border(1.dp, NmaColors.NavyBorder, RoundedCornerShape(14.dp))
                .clickable { showPrivacy = true }.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Privacy policy", color = NmaColors.TextPrimary, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Text("›", color = NmaColors.Accent, fontSize = 20.sp)
        }

        Spacer(Modifier.height(16.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Boîte de réception", color = NmaColors.TextPrimary, fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f))
            if (NotifStore.items.isNotEmpty()) {
                IconButton(onClick = { NotifStore.clear(ctx) }) {
                    Icon(Icons.Filled.Delete, "Tout effacer", tint = NmaColors.TextSecondary)
                }
            }
        }
        if (NotifStore.items.isEmpty()) {
            Text("Aucune notification pour le moment.", color = NmaColors.TextSecondary, fontSize = 13.sp)
        }
        NotifStore.items.forEach { n ->
            Row(
                Modifier.fillMaxWidth().padding(vertical = 5.dp)
                    .background(NmaColors.NavyCard, RoundedCornerShape(12.dp))
                    .border(1.dp, if (!n.read) NmaColors.Accent else NmaColors.NavyBorder, RoundedCornerShape(12.dp))
                    .padding(12.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Box(
                    Modifier.padding(top = 5.dp).size(8.dp)
                        .background(if (!n.read) NmaColors.Accent else NmaColors.NavyCard, CircleShape)
                )
                Column(Modifier.weight(1f)) {
                    Row {
                        Text(n.title, color = NmaColors.TextPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp,
                            modifier = Modifier.weight(1f))
                        Spacer(Modifier.width(8.dp))
                        Text(fmt.format(Date(n.time)), color = NmaColors.TextSecondary, fontSize = 11.sp)
                    }
                    Text(n.text, color = NmaColors.TextSecondary, fontSize = 13.sp, modifier = Modifier.padding(top = 2.dp))
                }
            }
        }
    }
}
