package com.nma.tunnel.lock

import android.content.Context
import android.os.SystemClock
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.abs

/**
 * Heure de confiance pour les configurations qui expirent.
 *
 * - Quand le téléphone est en ligne, on lit l'heure d'un serveur web (en-tête Date)
 *   puis on la fait avancer avec l'horloge interne, qui ne dépend pas de l'heure réglée.
 * - Hors ligne, on prend le plus grand entre l'heure du téléphone et la dernière heure vue :
 *   reculer l'horloge ne permet donc pas de gagner du temps.
 */
object TrustedTime {

    private fun prefs(ctx: Context) =
        ctx.applicationContext.getSharedPreferences("nma_time", Context.MODE_PRIVATE)

    @Synchronized
    fun now(ctx: Context): Long {
        val p = prefs(ctx)
        val sys = System.currentTimeMillis()
        val el = SystemClock.elapsedRealtime()
        val last = p.getLong("last", 0L)
        val netBase = p.getLong("net", 0L)
        val elBase = p.getLong("el", 0L)
        val bootBase = p.getLong("boot", 0L)

        val sameBoot = netBase > 0L && el >= elBase && abs((sys - el) - bootBase) < 10 * 60_000L
        val t = if (sameBoot) netBase + (el - elBase) else maxOf(sys, last)
        if (t > last) p.edit().putLong("last", t).apply()
        return t
    }

    /** Lit l'heure sur Internet. Bloquant : à appeler hors du thread principal. */
    fun sync(ctx: Context) {
        try {
            val conn = URL("https://www.gstatic.com/generate_204").openConnection() as HttpURLConnection
            conn.requestMethod = "HEAD"
            conn.connectTimeout = 5000
            conn.readTimeout = 5000
            conn.instanceFollowRedirects = false
            val date = try {
                conn.connect()
                conn.date
            } finally {
                conn.disconnect()
            }
            if (date > 0L) {
                val el = SystemClock.elapsedRealtime()
                val sys = System.currentTimeMillis()
                prefs(ctx).edit()
                    .putLong("net", date)
                    .putLong("el", el)
                    .putLong("boot", sys - el)
                    .putLong("last", date)
                    .apply()
            }
        } catch (e: Exception) {
            // hors ligne : on garde l'heure locale protégée
        }
    }
}

/** Texte « 2 j 3 h », « 5 h 12 min », « Expiré »… */
fun remainingText(ms: Long): String {
    if (ms <= 0L) return "Expiré"
    val d = ms / 86_400_000L
    val h = (ms % 86_400_000L) / 3_600_000L
    val m = (ms % 3_600_000L) / 60_000L
    return when {
        d > 0 -> "Expire dans $d j $h h"
        h > 0 -> "Expire dans $h h $m min"
        else -> "Expire dans ${maxOf(m, 1)} min"
    }
}
