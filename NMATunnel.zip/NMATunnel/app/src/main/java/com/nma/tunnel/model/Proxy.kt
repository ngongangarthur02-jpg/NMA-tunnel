package com.nma.tunnel.model

import android.util.Base64
import org.json.JSONObject
import java.net.URLDecoder

data class Server(
    val name: String,
    val protocol: String,
    val link: String? = null,
    val locked: Boolean = false,
    val expiresAt: Long = 0L,
    val code: String? = null
)

/**
 * Configuration d'un serveur, quel que soit le protocole.
 * type : vless, vmess, trojan, ss, socks, http, wireguard, hysteria2, custom, ssh
 */
data class ProxyConfig(
    val type: String,
    val host: String,
    val port: Int,
    val name: String,
    val secret: String,
    val params: Map<String, String>
) {
    fun label(): String = when (type) {
        "vless" -> "VLESS"
        "vmess" -> "VMess"
        "trojan" -> "Trojan"
        "ss" -> "Shadowsocks"
        "socks" -> "SOCKS"
        "http" -> "HTTP"
        "wireguard" -> "WireGuard"
        "hysteria2" -> "Hysteria2"
        "custom" -> "Custom"
        "ssh" -> params["mode"] ?: "SSH-Direct"
        else -> type.uppercase()
    }

    /** Sécurité du transport (none, tls, reality). */
    fun security(): String =
        (params["security"] ?: if (type == "trojan") "tls" else "none").lowercase()

    /** Vrai si on peut mesurer un ping TCP vers host:port. */
    fun tcpPingable(): Boolean =
        host.isNotBlank() && type in listOf("vless", "vmess", "trojan", "ss", "socks", "http", "ssh")

    /** Forme texte interne (chiffrée plus tard dans les codes verrouillés). */
    fun toLink(): String {
        val q = JSONObject()
        params.forEach { (k, v) -> q.put(k, v) }
        val o = JSONObject()
            .put("t", type)
            .put("n", name)
            .put("h", host)
            .put("p", port)
            .put("s", secret)
            .put("q", q)
        return "nma:" + Links.b64Encode(o.toString().toByteArray(Charsets.UTF_8))
    }
}

/** Lecture et écriture des liens de partage (vless://, vmess://, trojan://, ss://, hysteria2://, nma:). */
object Links {

    private val LINK_REGEX = Regex("(?i)\\b(?:vless|vmess|trojan|ss|hysteria2|hy2)://\\S+")

    fun b64Encode(bytes: ByteArray): String =
        Base64.encodeToString(bytes, Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING)

    /** Décode du base64 classique ou URL-safe, avec ou sans « = ». */
    fun b64Decode(s: String): ByteArray =
        Base64.decode(s.trim().replace('-', '+').replace('_', '/'), Base64.DEFAULT)

    private fun urlDecode(s: String): String =
        try { URLDecoder.decode(s, "UTF-8") } catch (e: Exception) { s }

    fun extract(text: String): List<String> =
        LINK_REGEX.findAll(text).map { it.value.trim() }.distinct().toList()

    fun toServer(raw: String): Server? =
        fromLink(raw)?.let { Server(it.name, it.label(), raw.trim()) }

    fun fromLink(raw: String): ProxyConfig? = try {
        val link = raw.trim()
        val lower = link.lowercase()
        when {
            lower.startsWith("nma:") -> fromNma(link.substring(4))
            lower.startsWith("vless://") -> parseVless(link.substring(8))
            lower.startsWith("vmess://") -> parseVmess(link.substring(8))
            lower.startsWith("trojan://") -> parseTrojan(link.substring(9))
            lower.startsWith("ss://") -> parseSs(link.substring(5))
            lower.startsWith("hysteria2://") -> parseHy2(link.substring(12))
            lower.startsWith("hy2://") -> parseHy2(link.substring(6))
            else -> null
        }
    } catch (e: Exception) {
        null
    }

    // ---- nma: (format interne) ----
    private fun fromNma(b64: String): ProxyConfig? {
        val o = JSONObject(String(b64Decode(b64), Charsets.UTF_8))
        val q = o.optJSONObject("q")
        val params = LinkedHashMap<String, String>()
        if (q != null) {
            val it = q.keys()
            while (it.hasNext()) {
                val k = it.next()
                params[k] = q.optString(k)
            }
        }
        val type = o.getString("t")
        val host = o.optString("h")
        val port = o.optInt("p", 0)
        val name = o.optString("n").ifBlank { host.ifBlank { type } }
        return ProxyConfig(type, host, port, name, o.optString("s"), params)
    }

    // ---- morceaux communs d'une URL : userinfo@host:port?query#nom ----
    private class Url(
        val userInfo: String,
        val host: String,
        val port: Int,
        val query: Map<String, String>,
        val fragment: String
    )

    private fun splitUrl(rest: String): Url? {
        var s = rest
        var frag = ""
        val h = s.indexOf('#')
        if (h >= 0) {
            frag = urlDecode(s.substring(h + 1)).trim()
            s = s.substring(0, h)
        }
        var q = ""
        val qi = s.indexOf('?')
        if (qi >= 0) {
            q = s.substring(qi + 1)
            s = s.substring(0, qi)
        }
        s = s.trimEnd('/')
        val at = s.lastIndexOf('@')
        val userInfo = if (at >= 0) s.substring(0, at) else ""
        val hostPort = if (at >= 0) s.substring(at + 1) else s

        val host: String
        val portStr: String
        if (hostPort.startsWith("[")) {
            val end = hostPort.indexOf(']')
            if (end < 0) return null
            host = hostPort.substring(1, end)
            portStr = hostPort.substring(end + 1).removePrefix(":")
        } else {
            val colon = hostPort.lastIndexOf(':')
            if (colon < 0) return null
            host = hostPort.substring(0, colon)
            portStr = hostPort.substring(colon + 1)
        }
        val port = portStr.trim().toIntOrNull() ?: return null
        if (host.isBlank() || port !in 1..65535) return null

        val params = LinkedHashMap<String, String>()
        q.split("&").filter { it.contains("=") }.forEach {
            val kv = it.split("=", limit = 2)
            params[kv[0]] = urlDecode(kv[1])
        }
        return Url(userInfo, host.trim(), port, params, frag)
    }

    private fun parseVless(rest: String): ProxyConfig? {
        val u = splitUrl(rest) ?: return null
        if (u.userInfo.isEmpty()) return null
        return ProxyConfig("vless", u.host, u.port, u.fragment.ifBlank { u.host }, u.userInfo, u.query)
    }

    private fun parseTrojan(rest: String): ProxyConfig? {
        val u = splitUrl(rest) ?: return null
        if (u.userInfo.isEmpty()) return null
        return ProxyConfig("trojan", u.host, u.port, u.fragment.ifBlank { u.host }, urlDecode(u.userInfo), u.query)
    }

    private fun parseHy2(rest: String): ProxyConfig? {
        val u = splitUrl(rest) ?: return null
        val params = LinkedHashMap(u.query)
        if (params["insecure"] == "1") params["insecure"] = "true"
        return ProxyConfig("hysteria2", u.host, u.port, u.fragment.ifBlank { u.host }, urlDecode(u.userInfo), params)
    }

    private fun parseVmess(rest: String): ProxyConfig? {
        val body = rest.substringBefore('#').trimEnd('/')
        val j = JSONObject(String(b64Decode(body), Charsets.UTF_8))
        val host = j.optString("add")
        val port = j.optString("port").toIntOrNull() ?: return null
        val id = j.optString("id")
        if (host.isBlank() || id.isBlank() || port !in 1..65535) return null

        val net = j.optString("net").ifBlank { "tcp" }
        val params = LinkedHashMap<String, String>()
        params["type"] = net
        params["security"] = if (j.optString("tls").equals("tls", true)) "tls" else "none"
        params["aid"] = j.optString("aid").ifBlank { "0" }
        params["scy"] = j.optString("scy").ifBlank { "auto" }
        val sni = j.optString("sni")
        if (sni.isNotBlank()) params["sni"] = sni
        val hostHeader = j.optString("host")
        if (hostHeader.isNotBlank()) params["host"] = hostHeader
        val path = j.optString("path")
        if (path.isNotBlank()) {
            if (net == "grpc") params["serviceName"] = path else params["path"] = path
        }
        val alpn = j.optString("alpn")
        if (alpn.isNotBlank()) params["alpn"] = alpn
        val fp = j.optString("fp")
        if (fp.isNotBlank()) params["fp"] = fp
        return ProxyConfig("vmess", host, port, j.optString("ps").ifBlank { host }, id, params)
    }

    private fun parseSs(rest: String): ProxyConfig? {
        var s = rest
        var name = ""
        val h = s.indexOf('#')
        if (h >= 0) {
            name = urlDecode(s.substring(h + 1)).trim()
            s = s.substring(0, h)
        }
        val plugin = s.substringAfter('?', "")
        s = s.substringBefore('?').trimEnd('/')

        val userInfo: String
        val hostPort: String
        val at = s.lastIndexOf('@')
        if (at >= 0) {
            // SIP002 : base64(méthode:mot de passe)@hôte:port
            val raw = s.substring(0, at)
            userInfo = if (raw.contains(":")) urlDecode(raw) else String(b64Decode(raw), Charsets.UTF_8)
            hostPort = s.substring(at + 1)
        } else {
            // ancien format : base64(méthode:mot de passe@hôte:port)
            val all = String(b64Decode(s), Charsets.UTF_8)
            val i = all.lastIndexOf('@')
            if (i < 0) return null
            userInfo = all.substring(0, i)
            hostPort = all.substring(i + 1)
        }
        val colon = userInfo.indexOf(':')
        if (colon < 0) return null
        val method = userInfo.substring(0, colon)
        val password = userInfo.substring(colon + 1)

        val hpColon = hostPort.lastIndexOf(':')
        if (hpColon < 0) return null
        val host = hostPort.substring(0, hpColon).trim('[', ']')
        val port = hostPort.substring(hpColon + 1).trim().toIntOrNull() ?: return null
        if (host.isBlank() || port !in 1..65535) return null

        val params = LinkedHashMap<String, String>()
        params["method"] = method
        if (plugin.isNotBlank()) params["plugin"] = plugin
        return ProxyConfig("ss", host, port, name.ifBlank { host }, password, params)
    }
}
