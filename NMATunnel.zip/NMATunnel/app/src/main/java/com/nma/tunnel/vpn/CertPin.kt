package com.nma.tunnel.vpn

import java.net.InetSocketAddress
import java.security.MessageDigest
import java.security.SecureRandom
import java.security.cert.X509Certificate
import javax.net.ssl.SNIHostName
import javax.net.ssl.SSLContext
import javax.net.ssl.SSLSocket
import javax.net.ssl.TrustManager
import javax.net.ssl.X509TrustManager

/**
 * Les versions récentes de Xray ont supprimé « allowInsecure ». Pour les serveurs dont le certificat n'est pas
 * reconnu (auto-signé, nom différent…), on relève l'empreinte SHA-256 du certificat du serveur et on la fixe
 * (« pinnedPeerCertSha256 ») : la connexion reste chiffrée et liée à CE certificat.
 */
object CertPin {
    private val cache = HashMap<String, String>()

    private object TrustAll : X509TrustManager {
        override fun checkClientTrusted(chain: Array<out X509Certificate>?, authType: String?) {}
        override fun checkServerTrusted(chain: Array<out X509Certificate>?, authType: String?) {}
        override fun getAcceptedIssuers(): Array<X509Certificate> = emptyArray()
    }

    @Synchronized
    fun fetch(ip: String, port: Int, sni: String): String? {
        val key = "$ip:$port/$sni"
        cache[key]?.let { return it }
        return runCatching {
            val ctx = SSLContext.getInstance("TLS")
            ctx.init(null, arrayOf<TrustManager>(TrustAll), SecureRandom())
            val raw = java.net.Socket()
            raw.connect(InetSocketAddress(ip, port), 5000)
            raw.soTimeout = 5000
            val ssl = ctx.socketFactory.createSocket(raw, sni, port, true) as SSLSocket
            ssl.use {
                val params = it.sslParameters
                if (sni.isNotBlank() && !sni.contains(":") && !sni.matches(Regex("[0-9.]+"))) {
                    params.serverNames = listOf(SNIHostName(sni))
                }
                it.sslParameters = params
                it.startHandshake()
                val leaf = it.session.peerCertificates.first() as X509Certificate
                MessageDigest.getInstance("SHA-256").digest(leaf.encoded).joinToString("") { b -> "%02x".format(b) }
            }
        }.getOrNull()?.also { cache[key] = it }
    }
}
