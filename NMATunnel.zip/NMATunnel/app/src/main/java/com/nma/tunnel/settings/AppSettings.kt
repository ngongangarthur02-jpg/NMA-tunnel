package com.nma.tunnel.settings

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** Réglages de l'application (thème, partage de connexion). */
object AppSettings {
    private const val PREFS = "nma_settings"

    /** light, dark ou auto */
    var theme by mutableStateOf("auto")
    var hotspotOn by mutableStateOf(false)
    /** Mode économie (par défaut) : moins de relevés et de tests réseau, donc moins de chauffe et de batterie. */
    var ecoMode by mutableStateOf(true)
    /** Notifications Android (mises à jour, messages, expiration). */
    var notifOn by mutableStateOf(true)
    /** Langue : auto (celle du téléphone), fr ou en. */
    var lang by mutableStateOf("auto")
    var socksPort by mutableIntStateOf(1080)
    var httpPort by mutableIntStateOf(8080)

    private fun prefs(ctx: Context) =
        ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun load(ctx: Context) {
        val p = prefs(ctx)
        theme = p.getString("theme", "auto") ?: "auto"
        hotspotOn = p.getBoolean("hotspot", false)
        ecoMode = p.getBoolean("eco", true)
        notifOn = p.getBoolean("notif", true)
        lang = p.getString("lang", "auto") ?: "auto"
        socksPort = p.getInt("socks", 1080)
        httpPort = p.getInt("http", 8080)
    }

    fun setTheme(ctx: Context, value: String) {
        theme = value
        prefs(ctx).edit().putString("theme", value).apply()
    }

    fun setLang(ctx: Context, l: String) {
        lang = l
        prefs(ctx).edit().putString("lang", l).apply()
    }

    fun setNotif(ctx: Context, on: Boolean) {
        notifOn = on
        prefs(ctx).edit().putBoolean("notif", on).apply()
    }

    fun notif(ctx: Context): Boolean = prefs(ctx).getBoolean("notif", true)

    fun setEco(ctx: Context, on: Boolean) {
        ecoMode = on
        prefs(ctx).edit().putBoolean("eco", on).apply()
    }

    /** Lu par le service VPN (qui peut démarrer sans l'écran principal). */
    fun eco(ctx: Context): Boolean = prefs(ctx).getBoolean("eco", true)

    fun setHotspot(ctx: Context, on: Boolean) {
        hotspotOn = on
        prefs(ctx).edit().putBoolean("hotspot", on).apply()
    }

    /** Lu par le service VPN au démarrage du tunnel. */
    fun hotspotConfig(ctx: Context): HotspotConfig? {
        val p = prefs(ctx)
        return if (p.getBoolean("hotspot", false)) {
            HotspotConfig(p.getInt("socks", 1080), p.getInt("http", 8080))
        } else null
    }
}
