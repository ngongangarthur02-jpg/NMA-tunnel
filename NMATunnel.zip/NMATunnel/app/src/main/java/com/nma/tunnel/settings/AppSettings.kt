package com.nma.tunnel.settings

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** Réglages de l'application (thème, partage de connexion). */
object AppSettings {
    private const val PREFS = "nma_settings"

    /** light, dark ou auto */
    var theme by mutableStateOf("auto")
    var hotspotOn by mutableStateOf(false)
    /** Mode économie (par défaut) : moins de relevés et de tests réseau, donc moins de chauffe et de batterie. */
    var ecoMode by mutableStateOf(true)
    /** Mode performance : mesures plus fréquentes et tampons plus grands (plus de chauffe et de batterie). */
    var perfMode by mutableStateOf(false)
    /** Notifications Android (mises à jour, messages, expiration). */
    var notifOn by mutableStateOf(true)
    /** Langue : auto (celle du téléphone), fr ou en. */
    var lang by mutableStateOf("auto")
    /** Réglages avancés : DNS, MTU (0 = automatique), coupure du VPN si le réseau disparaît. */
    var dns1 by mutableStateOf("1.1.1.1")
    var dns2 by mutableStateOf("8.8.8.8")
    var mtu by mutableIntStateOf(0)
    var killOnLoss by mutableStateOf(false)
    var socksPort by mutableIntStateOf(1080)
    var httpPort by mutableIntStateOf(8080)

    private fun prefs(ctx: Context) =
        ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun load(ctx: Context) {
        val p = prefs(ctx)
        theme = p.getString("theme", "auto") ?: "auto"
        hotspotOn = p.getBoolean("hotspot", false)
        ecoMode = p.getBoolean("eco", true)
        perfMode = p.getBoolean("perf", false)
        notifOn = p.getBoolean("notif", true)
        lang = p.getString("lang", "auto") ?: "auto"
        dns1 = p.getString("dns1", "1.1.1.1") ?: "1.1.1.1"
        dns2 = p.getString("dns2", "8.8.8.8") ?: "8.8.8.8"
        mtu = p.getInt("mtu", 0)
        killOnLoss = p.getBoolean("kill", false)
        socksPort = p.getInt("socks", 1080)
        httpPort = p.getInt("http", 8080)
    }

    fun setTheme(ctx: Context, value: String) {
        theme = value
        prefs(ctx).edit().putString("theme", value).apply()
    }

    private val IPV4 = Regex("^((25[0-5]|2[0-4]\\d|1?\\d?\\d)\\.){3}(25[0-5]|2[0-4]\\d|1?\\d?\\d)$")
    fun validIp(s: String) = IPV4.matches(s.trim())

    fun setDns(ctx: Context, first: Boolean, v: String) {
        if (first) dns1 = v else dns2 = v
        if (validIp(v)) prefs(ctx).edit().putString(if (first) "dns1" else "dns2", v.trim()).apply()
    }
    fun setMtu(ctx: Context, v: Int) {
        mtu = if (v == 0) 0 else v.coerceIn(1200, 1500)
        prefs(ctx).edit().putInt("mtu", mtu).apply()
    }
    fun setKill(ctx: Context, on: Boolean) {
        killOnLoss = on
        prefs(ctx).edit().putBoolean("kill", on).apply()
    }
    /** Lus par le service VPN. */
    fun dnsServers(ctx: Context): Pair<String, String> {
        val p = prefs(ctx)
        val a = p.getString("dns1", "1.1.1.1") ?: "1.1.1.1"
        val b = p.getString("dns2", "8.8.8.8") ?: "8.8.8.8"
        return (if (validIp(a)) a.trim() else "1.1.1.1") to (if (validIp(b)) b.trim() else "8.8.8.8")
    }
    fun mtuSetting(ctx: Context): Int = prefs(ctx).getInt("mtu", 0)
    fun killOnLoss(ctx: Context): Boolean = prefs(ctx).getBoolean("kill", false)

    fun setLang(ctx: Context, l: String) {
        lang = l
        prefs(ctx).edit().putString("lang", l).apply()
    }

    fun setNotif(ctx: Context, on: Boolean) {
        notifOn = on
        prefs(ctx).edit().putBoolean("notif", on).apply()
    }

    fun notif(ctx: Context): Boolean = prefs(ctx).getBoolean("notif", true)

    /** Trois niveaux : "eco", "balanced", "perf". */
    fun setPower(ctx: Context, level: String) {
        ecoMode = level == "eco"
        perfMode = level == "perf"
        prefs(ctx).edit().putBoolean("eco", ecoMode).putBoolean("perf", perfMode).apply()
    }
    fun perf(ctx: Context): Boolean = prefs(ctx).getBoolean("perf", false)
    fun powerLabel(): String = if (perfMode) "Performance Mode" else if (ecoMode) "Eco Mode" else "Balanced Mode"

    fun setEco(ctx: Context, on: Boolean) {
        ecoMode = on
        prefs(ctx).edit().putBoolean("eco", on).apply()
    }

    /** Lu par le service VPN (qui peut démarrer sans l'écran principal). */
    fun eco(ctx: Context): Boolean = prefs(ctx).getBoolean("eco", true)

    fun setHotspot(ctx: Context, on: Boolean) {
        hotspotOn = on
        prefs(ctx).edit().putBoolean("hotspot", on).apply()
    }

    /** Lu par le service VPN au démarrage du tunnel. */
    fun hotspotConfig(ctx: Context): HotspotConfig? {
        val p = prefs(ctx)
        return if (p.getBoolean("hotspot", false)) {
            HotspotConfig(p.getInt("socks", 1080), p.getInt("http", 8080))
        } else null
    }
}
