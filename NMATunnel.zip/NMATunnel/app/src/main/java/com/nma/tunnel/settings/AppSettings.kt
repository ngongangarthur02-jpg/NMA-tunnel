package com.nma.tunnel.settings

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** Réglages de l'application (thème, partage de connexion). */
object AppSettings {
    private const val PREFS = "nma_settings"

    /** light, dark ou auto */
    var theme by mutableStateOf("auto")
    var hotspotOn by mutableStateOf(false)
    var socksPort by mutableIntStateOf(10808)
    var httpPort by mutableIntStateOf(10809)

    private fun prefs(ctx: Context) =
        ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun load(ctx: Context) {
        val p = prefs(ctx)
        theme = p.getString("theme", "auto") ?: "auto"
        hotspotOn = p.getBoolean("hotspot", false)
        socksPort = p.getInt("socks", 10808)
        httpPort = p.getInt("http", 10809)
    }

    fun setTheme(ctx: Context, value: String) {
        theme = value
        prefs(ctx).edit().putString("theme", value).apply()
    }

    fun setHotspot(ctx: Context, on: Boolean) {
        hotspotOn = on
        prefs(ctx).edit().putBoolean("hotspot", on).apply()
    }

    /** Lu par le service VPN au démarrage du tunnel. */
    fun hotspotConfig(ctx: Context): HotspotConfig? {
        val p = prefs(ctx)
        return if (p.getBoolean("hotspot", false)) {
            HotspotConfig(p.getInt("socks", 10808), p.getInt("http", 10809))
        } else null
    }
}
