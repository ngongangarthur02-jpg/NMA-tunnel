package com.nma.tunnel.vpn

import com.nma.tunnel.model.VlessConfig
import org.json.JSONArray
import org.json.JSONObject

/** Construit la configuration JSON de Xray à partir d'un lien VLESS. */
object XrayConfig {

    fun build(cfg: VlessConfig, serverIp: String): String {
        val p = cfg.params
        val network = when (val t = (p["type"] ?: "tcp").lowercase()) {
            "raw" -> "tcp"
            "http" -> "h2"
            else -> t
        }
        val security = (p["security"] ?: "none").lowercase()
        val sni = p["sni"]?.takeIf { it.isNotBlank() }
        val hostHeader = p["host"]?.takeIf { it.isNotBlank() }
        val path = p["path"]?.takeIf { it.isNotBlank() } ?: "/"

        // --- streamSettings ---
        val stream = JSONObject().put("network", network).put("security", security)

        when (security) {
            "tls" -> stream.put("tlsSettings", JSONObject().apply {
                put("serverName", sni ?: hostHeader ?: cfg.host)
                put("allowInsecure", p["allowInsecure"] == "1" || p["allowInsecure"] == "true")
                p["fp"]?.takeIf { it.isNotBlank() }?.let { put("fingerprint", it) }
                p["alpn"]?.takeIf { it.isNotBlank() }?.let {
                    put("alpn", JSONArray(it.split(",").map { a -> a.trim() }))
                }
            })
            "reality" -> stream.put("realitySettings", JSONObject().apply {
                put("serverName", sni ?: cfg.host)
                put("fingerprint", p["fp"]?.takeIf { it.isNotBlank() } ?: "chrome")
                put("publicKey", p["pbk"] ?: "")
                put("shortId", p["sid"] ?: "")
                put("spiderX", p["spx"] ?: "")
            })
        }

        when (network) {
            "ws" -> stream.put("wsSettings", JSONObject().apply {
                put("path", path)
                put("headers", JSONObject().put("Host", hostHeader ?: sni ?: cfg.host))
            })
            "grpc" -> stream.put("grpcSettings", JSONObject().apply {
                put("serviceName", p["serviceName"] ?: "")
                put("multiMode", p["mode"] == "multi")
            })
            "httpupgrade" -> stream.put("httpupgradeSettings", JSONObject().apply {
                put("path", path)
                put("host", hostHeader ?: sni ?: cfg.host)
            })
            "xhttp", "splithttp" -> stream.put("xhttpSettings", JSONObject().apply {
                put("path", path)
                put("host", hostHeader ?: sni ?: cfg.host)
                p["mode"]?.takeIf { it.isNotBlank() }?.let { put("mode", it) }
            })
            "h2" -> stream.put("httpSettings", JSONObject().apply {
                put("path", path)
                put("host", JSONArray(listOf(hostHeader ?: sni ?: cfg.host)))
            })
        }

        // --- outbound VLESS ---
        val user = JSONObject().apply {
            put("id", cfg.uuid)
            put("encryption", p["encryption"]?.takeIf { it.isNotBlank() } ?: "none")
            p["flow"]?.takeIf { it.isNotBlank() }?.let { put("flow", it) }
            put("level", 0)
        }
        val proxy = JSONObject().apply {
            put("tag", "proxy")
            put("protocol", "vless")
            put("settings", JSONObject().put("vnext", JSONArray().put(JSONObject().apply {
                put("address", serverIp)
                put("port", cfg.port)
                put("users", JSONArray().put(user))
            })))
            put("streamSettings", stream)
        }
        val direct = JSONObject().put("tag", "direct").put("protocol", "freedom")

        // --- inbound TUN (le descripteur vient du VpnService) ---
        val tunIn = JSONObject().apply {
            put("tag", "tun-in")
            put("protocol", "tun")
            put("settings", JSONObject().put("name", "xray0").put("MTU", 1500).put("userLevel", 0))
            put("sniffing", JSONObject()
                .put("enabled", true)
                .put("destOverride", JSONArray(listOf("http", "tls", "quic"))))
        }

        return JSONObject().apply {
            put("log", JSONObject().put("loglevel", "warning"))
            put("stats", JSONObject())
            put("policy", JSONObject().put("system", JSONObject()
                .put("statsOutboundUplink", true)
                .put("statsOutboundDownlink", true)))
            put("dns", JSONObject().put("servers", JSONArray(listOf("1.1.1.1", "8.8.8.8"))))
            put("inbounds", JSONArray().put(tunIn))
            put("outbounds", JSONArray().put(proxy).put(direct))
            put("routing", JSONObject()
                .put("domainStrategy", "AsIs")
                .put("rules", JSONArray()))
        }.toString()
    }
}
