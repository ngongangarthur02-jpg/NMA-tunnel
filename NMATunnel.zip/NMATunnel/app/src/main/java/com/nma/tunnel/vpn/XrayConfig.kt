package com.nma.tunnel.vpn

import com.nma.tunnel.model.ProxyConfig
import com.nma.tunnel.settings.HotspotConfig
import org.json.JSONArray
import org.json.JSONObject

/** Construit la configuration JSON de Xray à partir d'une configuration serveur. */
object XrayConfig {

    /**
     * [serverIp] : adresse IP du serveur (déjà résolue).
     * [hotspot] : si présent, ouvre aussi un proxy local pour partager la connexion.
     * [sshPort] : port du proxy SOCKS local fourni par le tunnel SSH (modes SSH).
     */
    fun build(
        cfg: ProxyConfig,
        serverIp: String,
        hotspot: HotspotConfig? = null,
        sshPort: Int = 0,
        dns1: String = "1.1.1.1",
        dns2: String = "8.8.8.8"
    ): String {
        if (cfg.type == "custom") return buildCustom(cfg, hotspot)

        val isSsh = cfg.type == "ssh"
        val proxy = if (isSsh) sshOutbound(sshPort) else outbound(cfg, serverIp)
        val direct = JSONObject().put("tag", "direct").put("protocol", "freedom")
        val outbounds = JSONArray().put(proxy).put(direct)
        val rules = JSONArray()
        var dnsServers = listOf(dns1, dns2)

        if (isSsh) {
            // Le SOCKS du tunnel SSH ne transporte pas l'UDP : le DNS est résolu en TCP par Xray,
            // et l'UDP restant est bloqué pour que les applications reviennent en TCP.
            dnsServers = listOf("tcp://$dns1", "tcp://$dns2")
            outbounds.put(JSONObject().put("tag", "dns-out").put("protocol", "dns"))
            outbounds.put(JSONObject().put("tag", "block").put("protocol", "blackhole"))
            rules.put(JSONObject().put("type", "field").put("port", "53").put("outboundTag", "dns-out"))
            rules.put(JSONObject().put("type", "field").put("network", "udp").put("outboundTag", "block"))
        }

        return JSONObject().apply {
            put("log", JSONObject().put("loglevel", "warning"))
            put("stats", JSONObject())
            put("policy", JSONObject()
                .put("levels", levels())
                .put("system", JSONObject()
                    .put("statsOutboundUplink", true)
                    .put("statsOutboundDownlink", true)))
            put("dns", JSONObject()
                .put("servers", JSONArray(dnsServers))
                .put("queryStrategy", "UseIPv4"))
            put("inbounds", inbounds(hotspot))
            put("outbounds", outbounds)
            put("routing", JSONObject()
                .put("domainStrategy", "AsIs")
                .put("rules", rules))
        }.toString()
    }

    /**
     * Réglages de stabilité et de débit : grand tampon par connexion, aucune coupure
     * prématurée d'une connexion qui n'envoie ou ne reçoit plus pendant un moment.
     */
    /** Mode performance : tampons plus grands (débit plus élevé au prix de plus de mémoire). */
    @Volatile var perf = false

    private fun levels(): JSONObject = JSONObject().put("0", JSONObject()
        .put("handshake", 8)
        .put("connIdle", 900)
        .put("uplinkOnly", 0)
        .put("downlinkOnly", 0)
        .put("bufferSize", if (perf) 1024 else 512))

    // ---------------------------------------------------------------- entrées

    private fun sniffing(): JSONObject = JSONObject()
        .put("enabled", true)
        .put("destOverride", JSONArray(listOf("http", "tls", "quic")))

    private fun inbounds(hotspot: HotspotConfig?): JSONArray {
        val list = JSONArray()
        list.put(JSONObject().apply {
            put("tag", "tun-in")
            put("protocol", "tun")
            put("settings", JSONObject().put("name", "xray0").put("MTU", 1500).put("userLevel", 0))
            put("sniffing", sniffing())
        })
        if (hotspot != null) {
            // Proxy local ouvert aux autres appareils (point d'accès Wi-Fi du téléphone)
            list.put(JSONObject().apply {
                put("tag", "socks-in")
                put("protocol", "socks")
                put("listen", "0.0.0.0")
                put("port", hotspot.socksPort)
                put("settings", JSONObject().put("auth", "noauth").put("udp", true))
                put("sniffing", sniffing())
            })
            list.put(JSONObject().apply {
                put("tag", "http-in")
                put("protocol", "http")
                put("listen", "0.0.0.0")
                put("port", hotspot.httpPort)
                put("settings", JSONObject())
                put("sniffing", sniffing())
            })
        }
        return list
    }

    // ---------------------------------------------------------------- JSON personnalisé

    private fun buildCustom(cfg: ProxyConfig, hotspot: HotspotConfig?): String {
        val root = JSONObject(cfg.params["json"] ?: "{}")
        root.put("inbounds", inbounds(hotspot))
        stripAllowInsecure(root)
        if (!root.has("stats")) root.put("stats", JSONObject())
        val policy = root.optJSONObject("policy") ?: JSONObject().also { root.put("policy", it) }
        val system = policy.optJSONObject("system") ?: JSONObject().also { policy.put("system", it) }
        system.put("statsOutboundUplink", true)
        system.put("statsOutboundDownlink", true)
        if (!policy.has("levels")) policy.put("levels", levels())
        return root.toString()
    }

    /** Retire « allowInsecure », refusé par les versions récentes de Xray (sinon la configuration ne démarre pas). */
    private fun stripAllowInsecure(node: Any?) {
        when (node) {
            is JSONObject -> {
                node.remove("allowInsecure")
                val keys = node.keys().asSequence().toList()
                keys.forEach { stripAllowInsecure(node.opt(it)) }
            }
            is JSONArray -> for (i in 0 until node.length()) stripAllowInsecure(node.opt(i))
        }
    }

    // ---------------------------------------------------------------- sorties

    private fun endpoint(ip: String, port: Int): String =
        if (ip.contains(":")) "[$ip]:$port" else "$ip:$port"

    private fun sshOutbound(port: Int): JSONObject = JSONObject().apply {
        put("tag", "proxy")
        put("protocol", "socks")
        put("settings", JSONObject().put("servers", JSONArray().put(JSONObject()
            .put("address", "127.0.0.1")
            .put("port", port))))
    }

    private fun outbound(cfg: ProxyConfig, ip: String): JSONObject {
        val p = cfg.params
        return when (cfg.type) {
            "vless" -> JSONObject().apply {
                put("tag", "proxy")
                put("protocol", "vless")
                val user = JSONObject().apply {
                    put("id", cfg.secret)
                    put("encryption", p["encryption"]?.takeIf { it.isNotBlank() } ?: "none")
                    p["flow"]?.takeIf { it.isNotBlank() }?.let { put("flow", it) }
                    put("level", 0)
                }
                put("settings", JSONObject().put("vnext", JSONArray().put(JSONObject().apply {
                    put("address", ip)
                    put("port", cfg.port)
                    put("users", JSONArray().put(user))
                })))
                put("streamSettings", stream(cfg, ip))
            }
            "vmess" -> JSONObject().apply {
                put("tag", "proxy")
                put("protocol", "vmess")
                val user = JSONObject().apply {
                    put("id", cfg.secret)
                    put("alterId", p["aid"]?.toIntOrNull() ?: 0)
                    put("security", p["scy"]?.takeIf { it.isNotBlank() } ?: "auto")
                    put("level", 0)
                }
                put("settings", JSONObject().put("vnext", JSONArray().put(JSONObject().apply {
                    put("address", ip)
                    put("port", cfg.port)
                    put("users", JSONArray().put(user))
                })))
                put("streamSettings", stream(cfg, ip))
            }
            "trojan" -> JSONObject().apply {
                put("tag", "proxy")
                put("protocol", "trojan")
                put("settings", JSONObject().put("servers", JSONArray().put(JSONObject()
                    .put("address", ip)
                    .put("port", cfg.port)
                    .put("password", cfg.secret)
                    .put("level", 0))))
                put("streamSettings", stream(cfg, ip))
            }
            "ss" -> JSONObject().apply {
                put("tag", "proxy")
                put("protocol", "shadowsocks")
                put("settings", JSONObject().put("servers", JSONArray().put(JSONObject()
                    .put("address", ip)
                    .put("port", cfg.port)
                    .put("method", p["method"]?.takeIf { it.isNotBlank() } ?: "aes-256-gcm")
                    .put("password", cfg.secret)
                    .put("level", 0))))
            }
            "socks", "http" -> JSONObject().apply {
                put("tag", "proxy")
                put("protocol", if (cfg.type == "socks") "socks" else "http")
                val server = JSONObject().put("address", ip).put("port", cfg.port)
                val user = p["user"].orEmpty()
                if (user.isNotEmpty()) {
                    server.put("users", JSONArray().put(JSONObject()
                        .put("user", user)
                        .put("pass", p["pass"].orEmpty())))
                }
                put("settings", JSONObject().put("servers", JSONArray().put(server)))
            }
            "wireguard" -> JSONObject().apply {
                put("tag", "proxy")
                put("protocol", "wireguard")
                val peer = JSONObject()
                    .put("publicKey", p["publicKey"].orEmpty())
                    .put("endpoint", endpoint(ip, cfg.port))
                p["preSharedKey"]?.takeIf { it.isNotBlank() }?.let { peer.put("preSharedKey", it) }
                val addresses = (p["wgAddress"] ?: "").split(",").map { it.trim() }.filter { it.isNotEmpty() }
                put("settings", JSONObject()
                    .put("secretKey", p["secretKey"].orEmpty())
                    .put("address", JSONArray(addresses))
                    .put("peers", JSONArray().put(peer))
                    .put("mtu", p["mtu"]?.toIntOrNull() ?: 1280)
                    .put("noKernelTun", true))
            }
            "hysteria2" -> JSONObject().apply {
                put("tag", "proxy")
                put("protocol", "hysteria")
                put("settings", JSONObject()
                    .put("version", 2)
                    .put("address", ip)
                    .put("port", cfg.port))
                val tls = JSONObject()
                    .put("serverName", p["sni"]?.takeIf { it.isNotBlank() } ?: cfg.host)
                    .put("alpn", JSONArray(listOf("h3")))
                p["pcs"]?.takeIf { it.isNotBlank() }?.let { tls.put("pinnedPeerCertSha256", it) }
                put("streamSettings", JSONObject()
                    .put("network", "hysteria")
                    .put("security", "tls")
                    .put("tlsSettings", tls)
                    .put("hysteriaSettings", JSONObject()
                        .put("version", 2)
                        .put("auth", cfg.secret)))
            }
            else -> throw IllegalArgumentException("Type de serveur non pris en charge : ${cfg.type}")
        }
    }

    /** Transport (tcp, ws, grpc…) et sécurité (tls, reality) pour VLESS / VMess / Trojan. */
    private fun stream(cfg: ProxyConfig, ip: String): JSONObject {
        val p = cfg.params
        val network = when (val t = (p["type"] ?: "tcp").lowercase()) {
            "raw" -> "tcp"
            "http" -> "h2"
            else -> t
        }
        val security = cfg.security()
        val sni = p["sni"]?.takeIf { it.isNotBlank() }
        val hostHeader = p["host"]?.takeIf { it.isNotBlank() }
        val path = p["path"]?.takeIf { it.isNotBlank() } ?: "/"

        val stream = JSONObject().put("network", network).put("security", security)
        // Garde la connexion vivante (évite les coupures silencieuses des réseaux mobiles)
        stream.put("sockopt", JSONObject()
            .put("tcpKeepAliveIdle", 30)
            .put("tcpKeepAliveInterval", 15))

        when (security) {
            "tls" -> stream.put("tlsSettings", JSONObject().apply {
                val serverName = sni ?: hostHeader ?: cfg.host
                put("serverName", serverName)
                // « allowInsecure » n'existe plus dans Xray récent : on fixe l'empreinte du certificat à la place
                if (p["allowInsecure"] == "1" || p["allowInsecure"] == "true") {
                    val pin = p["pcs"]?.takeIf { it.isNotBlank() }
                        ?: (if (network == "tcp" || network == "ws" || network == "grpc" || network == "h2" || network == "httpupgrade" || network == "xhttp" || network == "splithttp")
                            CertPin.fetch(ip, cfg.port, serverName) else null)
                    if (pin != null) put("pinnedPeerCertSha256", pin)
                }
                p["pcs"]?.takeIf { it.isNotBlank() }?.let { put("pinnedPeerCertSha256", it) }
                p["vcn"]?.takeIf { it.isNotBlank() }?.let { put("verifyPeerCertByName", it) }
                p["fp"]?.takeIf { it.isNotBlank() }?.let { put("fingerprint", it) }
                p["alpn"]?.takeIf { it.isNotBlank() }?.let {
                    put("alpn", JSONArray(it.split(",").map { a -> a.trim() }))
                }
            })
            "reality" -> stream.put("realitySettings", JSONObject().apply {
                put("serverName", sni ?: cfg.host)
                put("fingerprint", p["fp"]?.takeIf { it.isNotBlank() } ?: "chrome")
                put("publicKey", p["pbk"] ?: "")
                put("shortId", p["sid"] ?: "")
                put("spiderX", p["spx"] ?: "")
            })
        }

        when (network) {
            "ws" -> stream.put("wsSettings", JSONObject().apply {
                put("path", path)
                put("headers", JSONObject().put("Host", hostHeader ?: sni ?: cfg.host))
            })
            "grpc" -> stream.put("grpcSettings", JSONObject().apply {
                put("serviceName", p["serviceName"] ?: "")
                put("multiMode", p["mode"] == "multi")
            })
            "httpupgrade" -> stream.put("httpupgradeSettings", JSONObject().apply {
                put("path", path)
                put("host", hostHeader ?: sni ?: cfg.host)
            })
            "xhttp", "splithttp" -> stream.put("xhttpSettings", JSONObject().apply {
                put("path", path)
                put("host", hostHeader ?: sni ?: cfg.host)
                p["mode"]?.takeIf { it.isNotBlank() }?.let { put("mode", it) }
            })
            "h2" -> stream.put("httpSettings", JSONObject().apply {
                put("path", path)
                put("host", JSONArray(listOf(hostHeader ?: sni ?: cfg.host)))
            })
        }
        return stream
    }
}
