package com.nma.tunnel.vpn

import com.jcraft.jsch.ChannelDirectTCPIP
import com.jcraft.jsch.JSch
import com.jcraft.jsch.Session
import com.jcraft.jsch.SocketFactory
import com.nma.tunnel.model.ProxyConfig
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.io.PushbackInputStream
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.security.SecureRandom
import java.security.cert.X509Certificate
import javax.net.ssl.SNIHostName
import javax.net.ssl.SNIServerName
import javax.net.ssl.SSLContext
import javax.net.ssl.SSLSocket
import javax.net.ssl.TrustManager
import javax.net.ssl.X509TrustManager
import kotlin.concurrent.thread

/**
 * Tunnel SSH : ouvre une session SSH vers le serveur et expose un petit proxy SOCKS5 local
 * (127.0.0.1) dont chaque connexion passe par un canal « direct-tcpip » de la session.
 * Xray envoie ensuite le trafic du téléphone vers ce proxy local.
 *
 * Modes : Direct, Proxy (proxy HTTP CONNECT), Payload (requête HTTP personnalisée envoyée
 * avant SSH), TLS (SSH dans une couche TLS avec SNI), et leurs combinaisons.
 */
class SshTunnel(private val cfg: ProxyConfig, private val log: (String) -> Unit) {

    @Volatile private var session: Session? = null
    @Volatile private var running = false
    private var server: ServerSocket? = null

    var socksPort: Int = 0
        private set

    val isAlive: Boolean
        get() = running && session?.isConnected == true

    fun start() {
        val p = cfg.params
        val mode = p["mode"] ?: "SSH-Direct"
        val useProxy = mode.contains("Proxy")
        val useTls = mode.contains("TLS")
        val payload = if (mode.contains("Payload")) p["payload"].orEmpty() else ""

        val connectHost = if (useProxy) p["proxyHost"].orEmpty() else cfg.host
        val connectPort = if (useProxy) (p["proxyPort"]?.toIntOrNull() ?: 8080) else cfg.port
        val sni = p["sni"].orEmpty().ifBlank { cfg.host }

        log("Connexion SSH ($mode) vers $connectHost:$connectPort…")
        val s = JSch().getSession(p["user"].orEmpty(), cfg.host, cfg.port)
        s.setPassword(p["pass"].orEmpty())
        s.setConfig("StrictHostKeyChecking", "no")
        s.setConfig("PreferredAuthentications", "password,keyboard-interactive")
        if (mode != "SSH-Direct") {
            s.setProxy(TunnelProxy(connectHost, connectPort, useProxy, useTls, sni, payload, cfg.host, cfg.port))
        }
        s.setServerAliveInterval(20000)
        s.setServerAliveCountMax(3)
        s.connect(20000)
        session = s
        running = true
        log("Session SSH ouverte")
        startSocks()
    }

    fun stop() {
        running = false
        try { server?.close() } catch (e: Exception) { }
        try { session?.disconnect() } catch (e: Exception) { }
        server = null
        session = null
    }

    // ------------------------------------------------------------ proxy SOCKS5 local

    private fun startSocks() {
        val ss = ServerSocket(0, 64, InetAddress.getByName("127.0.0.1"))
        server = ss
        socksPort = ss.localPort
        thread(name = "ssh-socks-accept", isDaemon = true) {
            while (running) {
                val c = try { ss.accept() } catch (e: Exception) { break }
                thread(name = "ssh-socks-conn", isDaemon = true) { handle(c) }
            }
        }
    }

    private fun readFully(ins: InputStream, n: Int): ByteArray {
        val b = ByteArray(n)
        var off = 0
        while (off < n) {
            val r = ins.read(b, off, n - off)
            if (r < 0) throw IOException("fin de flux")
            off += r
        }
        return b
    }

    private fun reply(out: OutputStream, code: Int) {
        out.write(byteArrayOf(5, code.toByte(), 0, 1, 0, 0, 0, 0, 0, 0))
        out.flush()
    }

    private fun closeQuiet(c: Socket) {
        try { c.close() } catch (e: Exception) { }
    }

    private fun pump(input: InputStream, output: OutputStream) {
        val buf = ByteArray(16 * 1024)
        try {
            while (true) {
                val n = input.read(buf)
                if (n < 0) break
                output.write(buf, 0, n)
                output.flush()
            }
        } catch (e: Exception) {
            // connexion fermée
        }
    }

    private fun handle(c: Socket) {
        var channel: ChannelDirectTCPIP? = null
        try {
            c.tcpNoDelay = true
            val cin = c.getInputStream()
            val cout = c.getOutputStream()

            val head = readFully(cin, 2)
            if (head[0].toInt() != 5) return
            readFully(cin, head[1].toInt() and 0xFF)
            cout.write(byteArrayOf(5, 0))
            cout.flush()

            val req = readFully(cin, 4)
            if (req[1].toInt() != 1) {
                reply(cout, 7)
                return
            }
            val host: String = when (req[3].toInt()) {
                1 -> InetAddress.getByAddress(readFully(cin, 4)).hostAddress ?: return
                4 -> InetAddress.getByAddress(readFully(cin, 16)).hostAddress ?: return
                3 -> {
                    val len = readFully(cin, 1)[0].toInt() and 0xFF
                    String(readFully(cin, len), Charsets.UTF_8)
                }
                else -> {
                    reply(cout, 8)
                    return
                }
            }
            val pb = readFully(cin, 2)
            val port = ((pb[0].toInt() and 0xFF) shl 8) or (pb[1].toInt() and 0xFF)

            val sess = session
            if (sess == null || !sess.isConnected) {
                reply(cout, 1)
                return
            }
            val ch = sess.openChannel("direct-tcpip") as ChannelDirectTCPIP
            channel = ch
            ch.setHost(host)
            ch.setPort(port)
            val remoteIn = ch.getInputStream()
            val remoteOut = ch.getOutputStream()
            try {
                ch.connect(15000)
            } catch (e: Exception) {
                reply(cout, 5)
                return
            }
            reply(cout, 0)

            thread(name = "ssh-pump", isDaemon = true) {
                pump(remoteIn, cout)
                closeQuiet(c)
            }
            pump(cin, remoteOut)
        } catch (e: Exception) {
            // connexion client interrompue
        } finally {
            try { channel?.disconnect() } catch (e: Exception) { }
            closeQuiet(c)
        }
    }

    // ------------------------------------------------------------ connexion physique

    private class TunnelProxy(
        private val connectHost: String,
        private val connectPort: Int,
        private val viaProxy: Boolean,
        private val tls: Boolean,
        private val sni: String,
        private val payload: String,
        private val targetHost: String,
        private val targetPort: Int
    ) : com.jcraft.jsch.Proxy {

        private var sock: Socket? = null
        private var input: InputStream? = null
        private var output: OutputStream? = null

        override fun connect(socketFactory: SocketFactory?, host: String?, port: Int, timeout: Int) {
            val t = if (timeout > 0) timeout else 20000
            val raw = Socket()
            raw.connect(InetSocketAddress(connectHost, connectPort), t)
            raw.tcpNoDelay = true
            raw.soTimeout = t

            var s: Socket = raw
            var ins = PushbackInputStream(raw.getInputStream(), 8)
            var outs: OutputStream = raw.getOutputStream()

            if (viaProxy) {
                if (payload.isEmpty()) {
                    val req = "CONNECT $targetHost:$targetPort HTTP/1.1\r\n" +
                        "Host: $targetHost:$targetPort\r\n\r\n"
                    outs.write(req.toByteArray(Charsets.ISO_8859_1))
                    outs.flush()
                    val status = readHttpHeader(ins)
                    val first = status.lineSequence().firstOrNull().orEmpty()
                    if (status.isNotEmpty() && !first.contains(" 200")) {
                        throw IOException("Le proxy a refusé la connexion : $first")
                    }
                } else {
                    sendPayload(outs)
                    readHttpHeader(ins)
                }
            }
            if (tls) {
                val ssl = wrapTls(s, sni, connectPort)
                s = ssl
                ins = PushbackInputStream(ssl.getInputStream(), 8)
                outs = ssl.getOutputStream()
            }
            if (!viaProxy && payload.isNotEmpty()) {
                sendPayload(outs)
                readHttpHeader(ins)
            }
            raw.soTimeout = 0
            s.soTimeout = 0
            sock = s
            input = ins
            output = outs
        }

        override fun getInputStream(): InputStream = input ?: throw IOException("non connecté")

        override fun getOutputStream(): OutputStream = output ?: throw IOException("non connecté")

        override fun getSocket(): Socket? = sock

        override fun close() {
            try { sock?.close() } catch (e: Exception) { }
            sock = null
        }

        private fun sendPayload(outs: OutputStream) {
            val text = payload
                .replace("\r\n", "\n").replace("\n", "\r\n")
                .replace("[host_port]", "$targetHost:$targetPort")
                .replace("[host]", targetHost)
                .replace("[port]", targetPort.toString())
                .replace("[crlf]", "\r\n")
                .replace("[cr]", "\r")
                .replace("[lf]", "\n")
                .replace("\\r", "\r")
                .replace("\\n", "\n")
            val parts = text.split("[split]")
            parts.forEachIndexed { i, part ->
                if (part.isNotEmpty()) {
                    outs.write(part.toByteArray(Charsets.ISO_8859_1))
                    outs.flush()
                }
                if (i < parts.size - 1) Thread.sleep(250)
            }
        }

        /** Lit l'en-tête HTTP de réponse. Si le serveur commence directement par « SSH- », ne consomme rien. */
        private fun readHttpHeader(ins: PushbackInputStream): String {
            val first = ByteArray(4)
            var n = 0
            while (n < 4) {
                val r = ins.read(first, n, 4 - n)
                if (r < 0) throw IOException("Connexion fermée par le serveur")
                n += r
            }
            if (String(first, Charsets.ISO_8859_1) == "SSH-") {
                ins.unread(first)
                return ""
            }
            val sb = StringBuilder(String(first, Charsets.ISO_8859_1))
            while (!sb.endsWith("\r\n\r\n")) {
                val b = ins.read()
                if (b < 0) throw IOException("Connexion fermée par le serveur")
                sb.append(b.toChar())
                if (sb.length > 16384) throw IOException("Réponse HTTP trop longue")
            }
            return sb.toString()
        }

        private fun wrapTls(base: Socket, host: String, port: Int): SSLSocket {
            val ctx = SSLContext.getInstance("TLS")
            ctx.init(null, arrayOf<TrustManager>(TrustAll), SecureRandom())
            val ssl = ctx.socketFactory.createSocket(base, host, port, true) as SSLSocket
            val params = ssl.sslParameters
            try {
                params.serverNames = listOf<SNIServerName>(SNIHostName(host))
            } catch (e: IllegalArgumentException) {
                // adresse IP : pas de SNI
            }
            ssl.sslParameters = params
            ssl.startHandshake()
            return ssl
        }
    }

    /** Le tunnel SSH vérifie lui-même l'utilisateur : on n'impose pas de certificat TLS (comme les clients d'injection). */
    private object TrustAll : X509TrustManager {
        override fun checkClientTrusted(chain: Array<out X509Certificate>?, authType: String?) {}
        override fun checkServerTrusted(chain: Array<out X509Certificate>?, authType: String?) {}
        override fun getAcceptedIssuers(): Array<X509Certificate> = emptyArray()
    }
}
