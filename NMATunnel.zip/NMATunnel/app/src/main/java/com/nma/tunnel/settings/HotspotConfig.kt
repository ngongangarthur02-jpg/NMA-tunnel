package com.nma.tunnel.settings

/** Ports du proxy local partagé avec les autres appareils (Hotspot). */
data class HotspotConfig(val socksPort: Int, val httpPort: Int)
