package com.nma.tunnel.lock

import android.content.Context
import android.util.Base64
import com.nma.tunnel.BuildConfig
import com.nma.tunnel.model.Links
import com.nma.tunnel.model.Server
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.security.MessageDigest
import java.security.SecureRandom
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.UUID
import javax.crypto.Cipher
import javax.crypto.Mac
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * Configuration verrouillée : un code qui contient les serveurs chiffrés, avec une date d'expiration.
 *
 * - NMA1.AAAA-MM.… : code « public » (n'importe quelle installation de l'application peut l'importer).
 * - NMA2.AAAA-MM.… : code lié à des appareils précis. Il ne s'ouvre que sur les appareils dont
 *   l'ID (clé publique) a été ajouté par l'admin.
 *
 * Dans les deux cas, la clé dépend aussi du mois d'émission (token mensuel).
 */
object LockedConfig {

    data class Payload(
        val id: String,
        val name: String,
        val issuedAt: Long,
        val expiresAt: Long,
        val links: List<String>
    )

    private val CODE_REGEX = Regex("NMA[12]\\.\\d{4}-\\d{2}\\.[A-Za-z0-9_-]+")
    private val rnd = SecureRandom()
    const val MAX_DEVICES = 50

    fun extractCodes(text: String): List<String> =
        CODE_REGEX.findAll(text).map { it.value }.distinct().toList()

    fun monthOf(ts: Long): String {
        val f = SimpleDateFormat("yyyy-MM", Locale.US)
        f.timeZone = TimeZone.getTimeZone("UTC")
        return f.format(Date(ts))
    }

    private fun monthKey(month: String): ByteArray {
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(BuildConfig.MASTER_SECRET.toByteArray(Charsets.UTF_8), "HmacSHA256"))
        return mac.doFinal("nma-token-$month".toByteArray(Charsets.UTF_8))
    }

    /** Empreinte courte du token du mois, affichée à l'admin. */
    fun monthToken(month: String): String =
        monthKey(month).take(4).joinToString("") { "%02X".format(it) }

    fun checkPassword(pw: String): Boolean {
        val hash = MessageDigest.getInstance("SHA-256")
            .digest(pw.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }
        return hash == BuildConfig.ADMIN_PASSWORD_HASH
    }

    private fun random(n: Int): ByteArray = ByteArray(n).also { rnd.nextBytes(it) }

    private fun gcm(mode: Int, key: ByteArray, iv: ByteArray, aad: String, data: ByteArray): ByteArray {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(mode, SecretKeySpec(key, "AES"), GCMParameterSpec(128, iv))
        cipher.updateAAD(aad.toByteArray(Charsets.UTF_8))
        return cipher.doFinal(data)
    }

    /** Clé qui protège la clé du contenu : dépend du secret ECDH ET du token du mois. */
    private fun kek(shared: ByteArray, month: String): ByteArray {
        val md = MessageDigest.getInstance("SHA-256")
        md.update(shared)
        md.update(monthKey(month))
        md.update("nma-kek".toByteArray(Charsets.UTF_8))
        return md.digest()
    }

    private fun fp4(raw: ByteArray): ByteArray =
        MessageDigest.getInstance("SHA-256").digest(raw).copyOfRange(0, 4)

    private fun payloadJson(name: String, links: List<String>, now: Long, durationMs: Long): JSONObject =
        JSONObject()
            .put("v", 1)
            .put("id", UUID.randomUUID().toString())
            .put("name", name)
            .put("iat", now)
            .put("exp", now + durationMs)
            .put("links", JSONArray(links))

    /**
     * Crée un code verrouillé valable [durationMs] à partir de [now].
     * [devices] : clés publiques (65 octets) des appareils autorisés. Vide = code public.
     */
    fun create(
        name: String,
        links: List<String>,
        now: Long,
        durationMs: Long,
        devices: List<ByteArray> = emptyList()
    ): String {
        val month = monthOf(now)
        val json = payloadJson(name, links, now, durationMs).toString().toByteArray(Charsets.UTF_8)
        val b64 = Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING

        if (devices.isEmpty()) {
            val header = "NMA1.$month"
            val iv = random(12)
            val ct = gcm(Cipher.ENCRYPT_MODE, monthKey(month), iv, header, json)
            return "$header." + Base64.encodeToString(iv + ct, b64)
        }

        require(devices.size <= MAX_DEVICES) { "Trop d'appareils (maximum $MAX_DEVICES)" }
        val header = "NMA2.$month"
        val contentKey = random(32)
        val eph = DeviceId.newKeyPair()
        val out = ByteArrayOutputStream()
        out.write(DeviceId.rawOf(eph.public))
        out.write(devices.size)
        for (dev in devices) {
            val shared = DeviceId.agree(eph.private, DeviceId.publicFromRaw(dev))
            val iv = random(12)
            val wrapped = gcm(Cipher.ENCRYPT_MODE, kek(shared, month), iv, header, contentKey)
            out.write(fp4(dev))
            out.write(iv)
            out.write(wrapped)
        }
        val iv = random(12)
        out.write(iv)
        out.write(gcm(Cipher.ENCRYPT_MODE, contentKey, iv, header, json))
        return "$header." + Base64.encodeToString(out.toByteArray(), b64)
    }

    private fun toPayload(json: JSONObject): Payload {
        val arr = json.getJSONArray("links")
        return Payload(
            id = json.getString("id"),
            name = json.getString("name"),
            issuedAt = json.getLong("iat"),
            expiresAt = json.getLong("exp"),
            links = (0 until arr.length()).map { arr.getString(it) }
        )
    }

    /** Déchiffre un code. Retourne le contenu, ou un message d'erreur lisible. */
    fun tryOpen(code: String, ctx: Context): Pair<Payload?, String?> = try {
        val parts = code.trim().split(".", limit = 3)
        if (parts.size != 3) {
            Pair(null, "Code invalide")
        } else {
            val month = parts[1]
            val raw = Links.b64Decode(parts[2])
            when (parts[0]) {
                "NMA1" -> {
                    val header = "NMA1.$month"
                    val iv = raw.copyOfRange(0, 12)
                    val ct = raw.copyOfRange(12, raw.size)
                    val plain = gcm(Cipher.DECRYPT_MODE, monthKey(month), iv, header, ct)
                    Pair(toPayload(JSONObject(String(plain, Charsets.UTF_8))), null)
                }
                "NMA2" -> openForDevice(raw, month, ctx)
                else -> Pair(null, "Code invalide")
            }
        }
    } catch (e: Exception) {
        Pair(null, "Code invalide, altéré ou créé avec une autre clé")
    }

    private fun openForDevice(raw: ByteArray, month: String, ctx: Context): Pair<Payload?, String?> {
        val header = "NMA2.$month"
        val size = DeviceId.RAW_SIZE
        val ephRaw = raw.copyOfRange(0, size)
        val count = raw[size].toInt() and 0xFF
        val entriesStart = size + 1
        val entrySize = 4 + 12 + 48
        val myFp = fp4(DeviceId.publicRaw(ctx))
        val shared = DeviceId.agree(DeviceId.privateKey(ctx), DeviceId.publicFromRaw(ephRaw))
        val key = kek(shared, month)

        var contentKey: ByteArray? = null
        for (i in 0 until count) {
            val o = entriesStart + i * entrySize
            val fp = raw.copyOfRange(o, o + 4)
            if (!fp.contentEquals(myFp)) continue
            val iv = raw.copyOfRange(o + 4, o + 16)
            val wrapped = raw.copyOfRange(o + 16, o + entrySize)
            contentKey = try {
                gcm(Cipher.DECRYPT_MODE, key, iv, header, wrapped)
            } catch (e: Exception) {
                null
            }
            break
        }
        if (contentKey == null) {
            return Pair(null, "Ce code n'est pas destiné à cet appareil")
        }
        val bodyStart = entriesStart + count * entrySize
        val iv = raw.copyOfRange(bodyStart, bodyStart + 12)
        val ct = raw.copyOfRange(bodyStart + 12, raw.size)
        val plain = gcm(Cipher.DECRYPT_MODE, contentKey, iv, header, ct)
        return Pair(toPayload(JSONObject(String(plain, Charsets.UTF_8))), null)
    }

    fun open(code: String, ctx: Context): Payload? = tryOpen(code, ctx).first

    /** Seule la date d'expiration fixée par l'admin compte. */
    fun checkImport(p: Payload, now: Long): String? =
        if (now >= p.expiresAt) "Cette configuration a déjà expiré" else null

    fun toServers(p: Payload, code: String): List<Server> {
        val valid = p.links.mapNotNull { Links.fromLink(it)?.let { cfg -> it to cfg } }
        return valid.mapIndexed { i, (link, cfg) ->
            Server(
                name = if (valid.size > 1) "${p.name} ${i + 1}" else p.name,
                protocol = cfg.label(),
                link = link,
                locked = true,
                expiresAt = p.expiresAt,
                code = code
            )
        }
    }
}
