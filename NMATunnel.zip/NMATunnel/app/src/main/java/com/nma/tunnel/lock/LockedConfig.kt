package com.nma.tunnel.lock

import android.content.Context
import android.util.Base64
import com.nma.tunnel.BuildConfig
import com.nma.tunnel.model.Links
import com.nma.tunnel.model.Server
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.security.MessageDigest
import java.security.SecureRandom
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.zip.Deflater
import java.util.zip.Inflater
import javax.crypto.Cipher
import javax.crypto.Mac
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * Configuration verrouillée : un code qui contient les serveurs chiffrés, avec une date d'expiration.
 *
 * - NMA1.AAAA-MM.… : code « public » (n'importe quelle installation de l'application peut l'importer).
 * - NMA2.AAAA-MM.… : code lié à des appareils précis. Il ne s'ouvre que sur les appareils dont
 *   l'ID (clé publique) a été ajouté par l'admin.
 *
 * Dans les deux cas, la clé dépend aussi du mois d'émission (token mensuel).
 */
object LockedConfig {

    data class Payload(
        val id: String = "",
        val name: String,
        val issuedAt: Long = 0L,
        val expiresAt: Long,
        val links: List<String>,
        val blockRoot: Boolean = false,
        val message: String = "",
        val quotaMb: Long = 0L,
        /** Date limite d'import (0 = pas de limite). */
        val importBy: Long = 0L
    )

    private val CODE_REGEX = Regex("(?:NMA[12]\\.\\d{4}-\\d{2}|N[34]\\.\\d{4})\\.[A-Za-z0-9_-]+")
    private val rnd = SecureRandom()
    const val MAX_DEVICES = 50

    fun extractCodes(text: String): List<String> =
        CODE_REGEX.findAll(text).map { it.value }.distinct().toList()

    fun monthOf(ts: Long): String {
        val f = SimpleDateFormat("yyyy-MM", Locale.US)
        f.timeZone = TimeZone.getTimeZone("UTC")
        return f.format(Date(ts))
    }

    private fun monthKey(month: String): ByteArray {
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(BuildConfig.MASTER_SECRET.toByteArray(Charsets.UTF_8), "HmacSHA256"))
        return mac.doFinal("nma-token-$month".toByteArray(Charsets.UTF_8))
    }

    /** Empreinte courte du token du mois, affichée à l'admin. */
    fun monthToken(month: String): String =
        monthKey(month).take(4).joinToString("") { "%02X".format(it) }

    fun checkPassword(pw: String): Boolean {
        val hash = MessageDigest.getInstance("SHA-256")
            .digest(pw.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }
        return hash == BuildConfig.ADMIN_PASSWORD_HASH
    }

    private fun random(n: Int): ByteArray = ByteArray(n).also { rnd.nextBytes(it) }

    private fun gcm(mode: Int, key: ByteArray, iv: ByteArray, aad: String, data: ByteArray): ByteArray {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(mode, SecretKeySpec(key, "AES"), GCMParameterSpec(128, iv))
        cipher.updateAAD(aad.toByteArray(Charsets.UTF_8))
        return cipher.doFinal(data)
    }

    /** Clé qui protège la clé du contenu : dépend du secret ECDH ET du token du mois. */
    private fun kek(shared: ByteArray, month: String): ByteArray {
        val md = MessageDigest.getInstance("SHA-256")
        md.update(shared)
        md.update(monthKey(month))
        md.update("nma-kek".toByteArray(Charsets.UTF_8))
        return md.digest()
    }

    private fun fp4(raw: ByteArray): ByteArray =
        MessageDigest.getInstance("SHA-256").digest(raw).copyOfRange(0, 4)

    // ---------------------------------------------------------------- format compact (N3 / N4)

    private fun ymOf(month: String) = month.replace("-", "").substring(2)
    private fun monthOfYm(ym: String) = "20" + ym.substring(0, 2) + "-" + ym.substring(2)

    /** Contenu court : un « nma: » est inséré comme objet JSON (bien plus court qu'en base64 dans du JSON). */
    private fun compactJson(name: String, links: List<String>, expiresAt: Long, blockRoot: Boolean, message: String, quotaMb: Long = 0L, importBy: Long = 0L): ByteArray {
        val arr = JSONArray()
        for (l in links) {
            if (l.startsWith("nma:")) {
                try {
                    arr.put(JSONObject(String(Links.b64Decode(l.substring(4)), Charsets.UTF_8)))
                    continue
                } catch (e: Exception) {
                    // lien illisible : gardé tel quel
                }
            }
            arr.put(l)
        }
        val o = JSONObject()
            .put("n", name)
            .put("e", (expiresAt + 59_999L) / 60_000L)
            .put("l", arr)
        if (blockRoot) o.put("r", 1)
        if (quotaMb > 0L) o.put("q", quotaMb)
        if (importBy > 0L) o.put("i", (importBy + 59_999L) / 60_000L)
        if (message.isNotBlank()) o.put("m", message.trim())
        return deflate(o.toString().toByteArray(Charsets.UTF_8))
    }

    private fun fromCompact(data: ByteArray): Payload {
        val o = JSONObject(String(inflate(data), Charsets.UTF_8))
        val arr = o.getJSONArray("l")
        val links = (0 until arr.length()).map {
            val v = arr.get(it)
            if (v is JSONObject) "nma:" + Links.b64Encode(v.toString().toByteArray(Charsets.UTF_8))
            else v.toString()
        }
        return Payload(
            name = o.getString("n"),
            expiresAt = o.getLong("e") * 60_000L,
            links = links,
            blockRoot = o.optInt("r", 0) == 1,
            message = o.optString("m", ""),
            quotaMb = o.optLong("q", 0L),
            importBy = o.optLong("i", 0L) * 60_000L
        )
    }

    /** Dictionnaire de compression commun (NE JAMAIS LE MODIFIER : il sert à relire les anciens codes). */
    private val DICT = ("\"hysteria2\"\"wireguard\"\"shadowsocks\"\"socks\"\"http\"\"trojan\"\"vmess\"\"ssh\"" +
        "\"serviceName\"\"httpupgrade\"\"xhttp\"\"grpc\"\"reality\"\"pbk\"\"sid\"\"spx\"\"proxyHost\"\"proxyPort\"" +
        "\"payload\"\"mode\"\"user\"\"pass\"\"method\"\"aes-256-gcm\"\"chacha20-ietf-poly1305\"\"aid\"\"scy\"\"auto\"" +
        "\"flow\"\"xtls-rprx-vision\"\"encryption\"\"none\"\"allowInsecure\"\"alpn\"\"h2,http/1.1\"\"chrome\"\"firefox\"" +
        "\"fp\"\"host\"\"path\"\"/\"\"tcp\"\"ws\"\"tls\"\"sni\"\"security\"\"type\"{\"n\":\"\",\"e\":,\"l\":[{\"t\":\"vless\"," +
        "\"n\":\"\",\"h\":\"\",\"p\":443,\"s\":\"\",\"q\":{\"type\":\"ws\",\"security\":\"tls\",\"sni\":\"\",\"host\":\"\"," +
        "\"path\":\"/\"}}],\"r\":1}vless://@:443?type=ws&security=tls&sni=&host=&path=%2F#").toByteArray(Charsets.UTF_8)

    private fun deflate(data: ByteArray): ByteArray {
        val d = Deflater(9, true)
        d.setDictionary(DICT)
        d.setInput(data); d.finish()
        val out = ByteArrayOutputStream()
        val buf = ByteArray(1024)
        while (!d.finished()) out.write(buf, 0, d.deflate(buf))
        d.end()
        return out.toByteArray()
    }

    private fun inflate(data: ByteArray): ByteArray {
        val i = Inflater(true)
        i.setDictionary(DICT)
        i.setInput(data)
        val out = ByteArrayOutputStream()
        val buf = ByteArray(1024)
        while (!i.finished()) {
            val n = i.inflate(buf)
            if (n == 0 && (i.needsInput() || i.needsDictionary())) break
            out.write(buf, 0, n)
        }
        i.end()
        return out.toByteArray()
    }

    private val ZERO_IV = ByteArray(12)
    private val b64 = Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING

    private fun saltKey(month: String, salt: ByteArray): ByteArray {
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(monthKey(month), "HmacSHA256"))
        mac.update("n3".toByteArray(Charsets.UTF_8))
        return mac.doFinal(salt)
    }

    /**
     * Crée un code verrouillé valable [durationMs] à partir de [now].
     * [devices] : clés publiques (65 octets) des appareils autorisés. Vide = code public (N3),
     * sinon code lié aux appareils (N4).
     * Les clés de chiffrement sont à usage unique : un vecteur d'initialisation fixe est donc sans risque
     * et ne prend aucune place dans le code.
     */
    fun create(
        name: String,
        links: List<String>,
        now: Long,
        durationMs: Long,
        devices: List<ByteArray> = emptyList(),
        blockRoot: Boolean = false,
        message: String = "",
        quotaMb: Long = 0L,
        importWindowMs: Long = 0L
    ): String {
        val month = monthOf(now)
        val ym = ymOf(month)
        val plain = compactJson(name, links, now + durationMs, blockRoot, message, quotaMb, if (importWindowMs > 0L) now + importWindowMs else 0L)

        if (devices.isEmpty()) {
            val header = "N3.$ym"
            val salt = random(8)
            val ct = gcm(Cipher.ENCRYPT_MODE, saltKey(month, salt), ZERO_IV, header, plain)
            return "$header." + Base64.encodeToString(salt + ct, b64)
        }

        require(devices.size <= MAX_DEVICES) { "Trop d'appareils (maximum $MAX_DEVICES)" }
        val header = "N4.$ym"
        val eph = DeviceId.newKeyPair()
        val out = ByteArrayOutputStream()
        out.write(DeviceId.compress(DeviceId.rawOf(eph.public)))
        out.write(devices.size)
        val contentKey: ByteArray
        if (devices.size == 1) {
            // un seul appareil : la clé dérivée sert directement, rien à emballer
            val shared = DeviceId.agree(eph.private, DeviceId.publicFromRaw(devices[0]))
            contentKey = kek(shared, month)
        } else {
            contentKey = random(32)
            for (dev in devices) {
                val shared = DeviceId.agree(eph.private, DeviceId.publicFromRaw(dev))
                out.write(fp2(dev))
                out.write(gcm(Cipher.ENCRYPT_MODE, kek(shared, month), ZERO_IV, header, contentKey))
            }
        }
        out.write(gcm(Cipher.ENCRYPT_MODE, contentKey, ZERO_IV, header, plain))
        return "$header." + Base64.encodeToString(out.toByteArray(), b64)
    }

    private fun fp2(raw: ByteArray): ByteArray = fp4(raw).copyOfRange(0, 2)

    private fun openN4(raw: ByteArray, ym: String, ctx: Context): Pair<Payload?, String?> {
        val month = monthOfYm(ym)
        val header = "N4.$ym"
        val eph = DeviceId.decompress(raw.copyOfRange(0, 33))
        val count = raw[33].toInt() and 0xFF
        val shared = DeviceId.agree(DeviceId.privateKey(ctx), DeviceId.publicFromRaw(eph))
        val key = kek(shared, month)
        val notForMe = Pair<Payload?, String?>(null, "Ce code n'est pas destiné à cet appareil")
        val contentKey: ByteArray
        val bodyStart: Int
        if (count == 1) {
            contentKey = key
            bodyStart = 34
        } else {
            val entrySize = 2 + 48
            val myFp = fp2(DeviceId.publicRaw(ctx))
            var found: ByteArray? = null
            for (i in 0 until count) {
                val o = 34 + i * entrySize
                if (!raw.copyOfRange(o, o + 2).contentEquals(myFp)) continue
                found = try {
                    gcm(Cipher.DECRYPT_MODE, key, ZERO_IV, header, raw.copyOfRange(o + 2, o + entrySize))
                } catch (e: Exception) {
                    null
                }
                if (found != null) break
            }
            contentKey = found ?: return notForMe
            bodyStart = 34 + count * entrySize
        }
        val plain = try {
            gcm(Cipher.DECRYPT_MODE, contentKey, ZERO_IV, header, raw.copyOfRange(bodyStart, raw.size))
        } catch (e: Exception) {
            // une seule clé possible : si elle échoue, le code n'est pas pour cet appareil (ou est altéré)
            return if (count == 1) notForMe else Pair(null, "Code invalide, altéré ou créé avec une autre clé")
        }
        return Pair(fromCompact(plain), null)
    }

    private fun toPayload(json: JSONObject): Payload {
        val arr = json.getJSONArray("links")
        return Payload(
            id = json.getString("id"),
            name = json.getString("name"),
            issuedAt = json.getLong("iat"),
            expiresAt = json.getLong("exp"),
            links = (0 until arr.length()).map { arr.getString(it) },
            blockRoot = json.optBoolean("nr", false)
        )
    }

    /** Déchiffre un code. Retourne le contenu, ou un message d'erreur lisible. */
    fun tryOpen(code: String, ctx: Context): Pair<Payload?, String?> = try {
        val parts = code.trim().split(".", limit = 3)
        if (parts.size != 3) {
            Pair(null, "Code invalide")
        } else {
            val month = parts[1]
            val raw = Links.b64Decode(parts[2])
            when (parts[0]) {
                "N3" -> {
                    val header = "N3.$month"
                    val salt = raw.copyOfRange(0, 8)
                    val plain = gcm(Cipher.DECRYPT_MODE, saltKey(monthOfYm(month), salt), ZERO_IV, header,
                        raw.copyOfRange(8, raw.size))
                    Pair(fromCompact(plain), null)
                }
                "N4" -> openN4(raw, month, ctx)
                "NMA1" -> {
                    val header = "NMA1.$month"
                    val iv = raw.copyOfRange(0, 12)
                    val ct = raw.copyOfRange(12, raw.size)
                    val plain = gcm(Cipher.DECRYPT_MODE, monthKey(month), iv, header, ct)
                    Pair(toPayload(JSONObject(String(plain, Charsets.UTF_8))), null)
                }
                "NMA2" -> openForDevice(raw, month, ctx)
                else -> Pair(null, "Code invalide")
            }
        }
    } catch (e: Exception) {
        Pair(null, "Code invalide, altéré ou créé avec une autre clé")
    }

    private fun openForDevice(raw: ByteArray, month: String, ctx: Context): Pair<Payload?, String?> {
        val header = "NMA2.$month"
        val size = DeviceId.RAW_SIZE
        val ephRaw = raw.copyOfRange(0, size)
        val count = raw[size].toInt() and 0xFF
        val entriesStart = size + 1
        val entrySize = 4 + 12 + 48
        val myFp = fp4(DeviceId.publicRaw(ctx))
        val shared = DeviceId.agree(DeviceId.privateKey(ctx), DeviceId.publicFromRaw(ephRaw))
        val key = kek(shared, month)

        var contentKey: ByteArray? = null
        for (i in 0 until count) {
            val o = entriesStart + i * entrySize
            val fp = raw.copyOfRange(o, o + 4)
            if (!fp.contentEquals(myFp)) continue
            val iv = raw.copyOfRange(o + 4, o + 16)
            val wrapped = raw.copyOfRange(o + 16, o + entrySize)
            contentKey = try {
                gcm(Cipher.DECRYPT_MODE, key, iv, header, wrapped)
            } catch (e: Exception) {
                null
            }
            break
        }
        if (contentKey == null) {
            return Pair(null, "Ce code n'est pas destiné à cet appareil")
        }
        val bodyStart = entriesStart + count * entrySize
        val iv = raw.copyOfRange(bodyStart, bodyStart + 12)
        val ct = raw.copyOfRange(bodyStart + 12, raw.size)
        val plain = gcm(Cipher.DECRYPT_MODE, contentKey, iv, header, ct)
        return Pair(toPayload(JSONObject(String(plain, Charsets.UTF_8))), null)
    }

    fun open(code: String, ctx: Context): Payload? = tryOpen(code, ctx).first

    /** Seule la date d'expiration fixée par l'admin compte. */
    fun checkImport(p: Payload, now: Long): String? =
        if (now >= p.expiresAt) "Cette configuration a déjà expiré"
        else if (p.importBy > 0L && now >= p.importBy) "Ce code n'est plus importable : le délai d'importation est dépassé"
        else null

    fun toServers(p: Payload, code: String): List<Server> {
        val valid = p.links.mapNotNull { Links.fromLink(it)?.let { cfg -> it to cfg } }
        return valid.mapIndexed { i, (link, cfg) ->
            Server(
                name = if (valid.size > 1) "${p.name} ${i + 1}" else p.name,
                protocol = cfg.label(),
                link = link,
                locked = true,
                expiresAt = p.expiresAt,
                code = code,
                blockRoot = p.blockRoot,
                message = p.message,
                quotaMb = p.quotaMb
            )
        }
    }
}
