package com.nma.tunnel.lock

import android.util.Base64
import com.nma.tunnel.BuildConfig
import com.nma.tunnel.model.Server
import com.nma.tunnel.model.VlessParser
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest
import java.security.SecureRandom
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.UUID
import javax.crypto.Cipher
import javax.crypto.Mac
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * Configuration verrouillée : un code « NMA1.AAAA-MM.xxxxx » qui contient les liens
 * des serveurs, chiffrés en AES-256-GCM, avec une date d'expiration.
 *
 * La clé de chiffrement change chaque mois (token mensuel) : elle est dérivée de la
 * clé secrète de l'application et du mois d'émission.
 */
object LockedConfig {

    data class Payload(
        val id: String,
        val name: String,
        val issuedAt: Long,
        val expiresAt: Long,
        val links: List<String>
    )

    private val CODE_REGEX = Regex("NMA1\\.\\d{4}-\\d{2}\\.[A-Za-z0-9_-]+")
    private const val GRACE_DAYS = 3
    private const val B64 = Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING

    fun extractCodes(text: String): List<String> =
        CODE_REGEX.findAll(text).map { it.value }.distinct().toList()

    fun monthOf(ts: Long): String {
        val f = SimpleDateFormat("yyyy-MM", Locale.US)
        f.timeZone = TimeZone.getTimeZone("UTC")
        return f.format(Date(ts))
    }

    private fun monthKey(month: String): ByteArray {
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(BuildConfig.MASTER_SECRET.toByteArray(Charsets.UTF_8), "HmacSHA256"))
        return mac.doFinal("nma-token-$month".toByteArray(Charsets.UTF_8))
    }

    /** Empreinte courte du token du mois, affichée à l'admin. */
    fun monthToken(month: String): String =
        monthKey(month).take(4).joinToString("") { "%02X".format(it) }

    fun checkPassword(pw: String): Boolean {
        val hash = MessageDigest.getInstance("SHA-256")
            .digest(pw.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }
        return hash == BuildConfig.ADMIN_PASSWORD_HASH
    }

    /** Crée un code verrouillé valable [durationMs] à partir de [now]. */
    fun create(name: String, links: List<String>, now: Long, durationMs: Long): String {
        val month = monthOf(now)
        val json = JSONObject()
            .put("v", 1)
            .put("id", UUID.randomUUID().toString())
            .put("name", name)
            .put("iat", now)
            .put("exp", now + durationMs)
            .put("links", JSONArray(links))

        val iv = ByteArray(12).also { SecureRandom().nextBytes(it) }
        val header = "NMA1.$month"
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, SecretKeySpec(monthKey(month), "AES"), GCMParameterSpec(128, iv))
        cipher.updateAAD(header.toByteArray(Charsets.UTF_8))
        val ct = cipher.doFinal(json.toString().toByteArray(Charsets.UTF_8))
        return "$header." + Base64.encodeToString(iv + ct, B64)
    }

    /** Déchiffre un code. Retourne null s'il est invalide ou altéré. */
    fun open(code: String): Payload? = try {
        val parts = code.trim().split(".", limit = 3)
        if (parts.size != 3 || parts[0] != "NMA1") {
            null
        } else {
            val month = parts[1]
            val raw = Base64.decode(parts[2], B64)
            val iv = raw.copyOfRange(0, 12)
            val ct = raw.copyOfRange(12, raw.size)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, SecretKeySpec(monthKey(month), "AES"), GCMParameterSpec(128, iv))
            cipher.updateAAD("NMA1.$month".toByteArray(Charsets.UTF_8))
            val json = JSONObject(String(cipher.doFinal(ct), Charsets.UTF_8))
            val arr = json.getJSONArray("links")
            Payload(
                id = json.getString("id"),
                name = json.getString("name"),
                issuedAt = json.getLong("iat"),
                expiresAt = json.getLong("exp"),
                links = (0 until arr.length()).map { arr.getString(it) }
            )
        }
    } catch (e: Exception) {
        null
    }

    /**
     * Vérifie qu'on peut importer ce code maintenant.
     * Le token est valable pour l'import pendant son mois d'émission + [GRACE_DAYS] jours.
     */
    fun checkImport(p: Payload, now: Long): String? {
        if (now >= p.expiresAt) return "Cette configuration a déjà expiré"
        val cal = Calendar.getInstance(TimeZone.getTimeZone("UTC"))
        cal.timeInMillis = p.issuedAt
        cal.set(Calendar.DAY_OF_MONTH, 1)
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        cal.add(Calendar.MONTH, 1)
        cal.add(Calendar.DAY_OF_MONTH, GRACE_DAYS)
        if (now > cal.timeInMillis) {
            return "Token du mois ${monthOf(p.issuedAt)} périmé : demande un nouveau code"
        }
        return null
    }

    fun toServers(p: Payload, code: String): List<Server> {
        val valid = p.links.filter { VlessParser.parse(it) != null }
        return valid.mapIndexed { i, link ->
            Server(
                name = if (valid.size > 1) "${p.name} ${i + 1}" else p.name,
                protocol = "VLESS",
                link = link,
                locked = true,
                expiresAt = p.expiresAt,
                code = code
            )
        }
    }
}
