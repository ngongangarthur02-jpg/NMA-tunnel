package com.nma.tunnel.ads

import android.content.Context
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.MobileAds

/** Publicité AdMob (bannière). */
object Ads {
    /**
     * true  = identifiants de TEST de Google (à utiliser pendant les essais : ne jamais cliquer sur de vraies pubs de son propre compte).
     * false = vrais blocs d'annonces de ton compte AdMob.
     */
    const val USE_TEST_ADS = true

    private const val TEST_BANNER = "ca-app-pub-3940256099942544/6300978111"
    private const val LIVE_BANNER = "ca-app-pub-1268164806308146/7248452439"

    val bannerId: String get() = if (USE_TEST_ADS) TEST_BANNER else LIVE_BANNER

    @Volatile private var started = false

    fun init(ctx: Context) {
        if (started) return
        started = true
        runCatching { MobileAds.initialize(ctx.applicationContext) {} }
    }
}

@Composable
fun AdBanner(modifier: Modifier = Modifier) {
    val holder = remember { arrayOfNulls<AdView>(1) }
    DisposableEffect(Unit) { onDispose { holder[0]?.destroy() } }
    Box(modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
        AndroidView(factory = { c ->
            AdView(c).apply {
                setAdSize(AdSize.BANNER)
                adUnitId = Ads.bannerId
                holder[0] = this
                runCatching { loadAd(AdRequest.Builder().build()) }
            }
        })
    }
}
