package com.nma.tunnel.util

import android.content.Context
import android.os.Build
import java.io.File

/**
 * Détection d'un appareil rooté (meilleure estimation). Un root bien caché (Magisk avec
 * masquage, par exemple) peut échapper à ces tests : ce n'est pas une protection absolue.
 */
object RootCheck {
    private val SU_PATHS = listOf(
        "/system/bin/su", "/system/xbin/su", "/sbin/su", "/system/su", "/vendor/bin/su",
        "/su/bin/su", "/system/sbin/su", "/data/local/su", "/data/local/bin/su",
        "/data/local/xbin/su", "/system/app/Superuser.apk", "/system/bin/.ext/.su",
        "/system/usr/we-need-root/su", "/data/adb/magisk", "/data/adb/ksu", "/sbin/.magisk"
    )
    private val ROOT_APPS = listOf(
        "com.topjohnwu.magisk", "io.github.vvb2060.magisk", "me.weishu.kernelsu",
        "com.noshufou.android.su", "com.thirdparty.superuser", "eu.chainfire.supersu",
        "com.koushikdutta.superuser", "com.zachspong.temprootremovejb", "com.ramdroid.appquarantine",
        "com.topjohnwu.magisk.lite", "com.kingouser.com", "com.yellowes.su"
    )

    fun isRooted(ctx: Context): Boolean {
        if (SU_PATHS.any { runCatching { File(it).exists() }.getOrDefault(false) }) return true
        if (Build.TAGS?.contains("test-keys") == true) return true
        val pm = ctx.packageManager
        if (ROOT_APPS.any { pkg -> runCatching { pm.getPackageInfo(pkg, 0); true }.getOrDefault(false) }) return true
        // « which su » : présent dans le PATH ?
        val inPath = System.getenv("PATH").orEmpty().split(":")
            .any { runCatching { File(it, "su").exists() }.getOrDefault(false) }
        if (inPath) return true
        // Partition système montée en écriture
        return runCatching {
            File("/proc/mounts").readLines().any {
                val p = it.split(" ")
                p.size > 3 && (p[1] == "/system" || p[1] == "/") && p[3].split(",").contains("rw") &&
                    p[2] != "tmpfs" && p[2] != "rootfs"
            }
        }.getOrDefault(false)
    }

    const val MESSAGE = "Cette configuration est interdite sur les appareils rootés"
}
