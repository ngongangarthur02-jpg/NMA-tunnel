package com.nma.tunnel.model

import android.content.Context

/** Sauvegarde les liens vless:// importés (un par ligne). */
class ServerStore(context: Context) {
    private val prefs = context.getSharedPreferences("nma_servers", Context.MODE_PRIVATE)

    fun load(): List<Server> =
        prefs.getString("links", "").orEmpty()
            .lines()
            .mapNotNull { VlessParser.toServer(it) }

    fun save(servers: List<Server>) {
        val text = servers.mapNotNull { it.link }.joinToString("\n")
        prefs.edit().putString("links", text).apply()
    }
}
