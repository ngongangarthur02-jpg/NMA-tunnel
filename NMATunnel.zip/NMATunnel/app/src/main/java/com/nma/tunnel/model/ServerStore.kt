package com.nma.tunnel.model

import android.content.Context
import com.nma.tunnel.lock.LockedConfig

/**
 * Sauvegarde les serveurs.
 * - Liens normaux : un par ligne.
 * - Configurations verrouillées : on ne garde que le code chiffré, jamais le lien en clair.
 */
class ServerStore(context: Context) {
    private val prefs = context.getSharedPreferences("nma_servers", Context.MODE_PRIVATE)

    fun load(): List<Server> {
        val plain = prefs.getString("links", "").orEmpty()
            .lines()
            .mapNotNull { VlessParser.toServer(it) }
        val locked = prefs.getString("locked", "").orEmpty()
            .lines()
            .filter { it.isNotBlank() }
            .flatMap { code ->
                val p = LockedConfig.open(code)
                if (p == null) emptyList() else LockedConfig.toServers(p, code)
            }
        return plain + locked
    }

    fun save(servers: List<Server>) {
        val links = servers.filter { !it.locked }.mapNotNull { it.link }.joinToString("\n")
        val codes = servers.filter { it.locked }.mapNotNull { it.code }.distinct().joinToString("\n")
        prefs.edit().putString("links", links).putString("locked", codes).apply()
    }
}
