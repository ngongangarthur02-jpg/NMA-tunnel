package com.nma.tunnel.model

import android.content.Context
import com.nma.tunnel.lock.LockedConfig

/**
 * Sauvegarde les serveurs.
 * - Serveurs normaux : un lien par ligne (vless://, nma:…, etc.).
 * - Configurations verrouillées : on ne garde que le code chiffré, jamais le lien en clair.
 */
class ServerStore(private val context: Context) {
    private val prefs = context.getSharedPreferences("nma_servers", Context.MODE_PRIVATE)

    fun load(): List<Server> {
        val plain = prefs.getString("links", "").orEmpty()
            .lines()
            .filter { it.isNotBlank() }
            .mapNotNull { Links.toServer(it) }
        val locked = prefs.getString("locked", "").orEmpty()
            .lines()
            .filter { it.isNotBlank() }
            .flatMap { code ->
                val p = LockedConfig.open(code, context)
                if (p == null) emptyList() else LockedConfig.toServers(p, code)
            }
        return plain + locked
    }

    fun save(servers: List<Server>) {
        val links = servers.filter { !it.locked }.mapNotNull { it.link }.joinToString("\n")
        val codes = servers.filter { it.locked }.mapNotNull { it.code }.distinct().joinToString("\n")
        prefs.edit().putString("links", links).putString("locked", codes).apply()
    }

    /** Serveur choisi par l'utilisateur : retrouvé à la réouverture de l'application. */
    fun saveSelected(key: String?) {
        prefs.edit().putString("selected", key).apply()
    }

    fun loadSelected(): String? = prefs.getString("selected", null)
}
