package com.nma.tunnel.model

import com.nma.tunnel.vpn.TunnelState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.InetSocketAddress
import java.net.Socket

/** Clé utilisée pour stocker le ping d'un serveur. */
fun Server.key(): String = link ?: name

/** Ping TCP (temps de connexion) vers le serveur, en millisecondes. -1 si échec. */
suspend fun tcpPing(host: String, port: Int, timeoutMs: Int = 3000): Int =
    withContext(Dispatchers.IO) {
        try {
            val t0 = System.nanoTime()
            Socket().use { it.connect(InetSocketAddress(host, port), timeoutMs) }
            ((System.nanoTime() - t0) / 1_000_000).toInt().coerceAtLeast(1)
        } catch (e: Exception) {
            -1
        }
    }

/** Mesure le ping d'un serveur et le range dans [TunnelState.pings]. */
suspend fun pingServer(s: Server) {
    val link = s.link ?: return
    val cfg = Links.fromLink(link) ?: return
    if (!cfg.tcpPingable()) return
    // Pour un proxy HTTP/SSH, le ping mesuré est celui du serveur final
    TunnelState.pings[s.key()] = -2
    TunnelState.pings[s.key()] = tcpPing(cfg.host, cfg.port)
}

fun pingLabel(v: Int?): String = when (v) {
    null -> ""
    -2 -> "…"
    -1 -> "timeout"
    else -> "$v ms"
}
