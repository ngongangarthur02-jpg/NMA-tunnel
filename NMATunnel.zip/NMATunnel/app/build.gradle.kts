import java.io.File
import java.net.URL
import java.security.MessageDigest
import java.util.Base64

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// Clé secrète et mot de passe admin : lus dans gradle.properties
// Ordre de lecture : variable d'environnement (secrets GitHub), puis gradle.properties.
// Sur GitHub Actions (CI), l'absence d'un secret fait échouer la compilation : on évite
// ainsi de fabriquer par erreur une application avec une mauvaise clé.
fun secret(name: String, fallback: String): String {
    val v = System.getenv(name)?.takeIf { it.isNotBlank() }
        ?: (project.findProperty(name) as String?)?.takeIf { it.isNotBlank() }
    if (v != null) return v
    if (System.getenv("CI") != null) {
        throw GradleException("Secret GitHub manquant : $name (Settings > Secrets and variables > Actions)")
    }
    return fallback
}
val nmaMasterSecret: String = secret("NMA_MASTER_SECRET", "CHANGE-ME")
val nmaAdminPassword: String = secret("NMA_ADMIN_PASSWORD", "change-me-now")

// Clé de signature fixe : indispensable pour que les mises à jour s'installent par-dessus l'ancienne version.
val ksB64: String? = System.getenv("NMA_KEYSTORE_B64")?.takeIf { it.isNotBlank() }
val ksPassword: String? = System.getenv("NMA_KEYSTORE_PASSWORD")?.takeIf { it.isNotBlank() }
val nmaAdminPasswordHash: String = MessageDigest.getInstance("SHA-256")
    .digest(nmaAdminPassword.toByteArray(Charsets.UTF_8))
    .joinToString("") { "%02x".format(it) }

android {
    namespace = "com.nma.tunnel"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.nma.tunnel"
        minSdk = 24
        targetSdk = 34
        versionCode = 5
        versionName = "1.4"

        buildConfigField("String", "MASTER_SECRET", "\"$nmaMasterSecret\"")
        buildConfigField("String", "ADMIN_PASSWORD_HASH", "\"$nmaAdminPasswordHash\"")

        ndk {
            abiFilters += listOf("arm64-v8a", "armeabi-v7a")
        }
    }

    signingConfigs {
        if (ksB64 != null && ksPassword != null) {
            create("nma") {
                val f = File(rootDir, "build/nma-keystore.p12")
                f.parentFile.mkdirs()
                f.writeBytes(Base64.getMimeDecoder().decode(ksB64))
                storeFile = f
                storeType = "pkcs12"
                storePassword = ksPassword
                keyAlias = "nma"
                keyPassword = ksPassword
            }
        }
    }
    buildTypes {
        getByName("debug") {
            signingConfigs.findByName("nma")?.let { signingConfig = it }
        }
        release {
            isMinifyEnabled = false
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
        buildConfig = true
    }
    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.14"
    }
}

// Télécharge automatiquement le moteur Xray (libv2ray.aar) s'il est absent.
val xrayAar = layout.projectDirectory.file("libs/libv2ray.aar").asFile
if (!xrayAar.exists() || xrayAar.length() < 1_000_000L) {
    xrayAar.parentFile.mkdirs()
    println("Téléchargement de libv2ray.aar ...")
    val tmp = File(xrayAar.parentFile, "libv2ray.aar.tmp")
    URL("https://github.com/2dust/AndroidLibXrayLite/releases/latest/download/libv2ray.aar")
        .openStream().use { input ->
            tmp.outputStream().use { output -> input.copyTo(output) }
        }
    tmp.renameTo(xrayAar)
}

dependencies {
    implementation(files("libs/libv2ray.aar"))
    implementation("com.github.mwiede:jsch:2.28.8")
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-compose:1.9.1")
    implementation(platform("androidx.compose:compose-bom:2024.06.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
}
