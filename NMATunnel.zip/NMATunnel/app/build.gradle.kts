import java.net.URL

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.nma.tunnel"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.nma.tunnel"
        minSdk = 24
        targetSdk = 34
        versionCode = 2
        versionName = "1.1"

        ndk {
            abiFilters += listOf("arm64-v8a", "armeabi-v7a")
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
    }
    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.14"
    }
}

// Télécharge automatiquement le moteur Xray (libv2ray.aar) s'il est absent.
val xrayAar = layout.projectDirectory.file("libs/libv2ray.aar").asFile
val downloadXray by tasks.registering {
    outputs.file(xrayAar)
    doLast {
        if (!xrayAar.exists() || xrayAar.length() < 1_000_000L) {
            xrayAar.parentFile.mkdirs()
            println("Téléchargement de libv2ray.aar ...")
            URL("https://github.com/2dust/AndroidLibXrayLite/releases/latest/download/libv2ray.aar")
                .openStream().use { input ->
                    xrayAar.outputStream().use { output -> input.copyTo(output) }
                }
        }
    }
}
tasks.configureEach {
    if (name == "preBuild") dependsOn(downloadXray)
}

dependencies {
    implementation(files("libs/libv2ray.aar"))
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-compose:1.9.1")
    implementation(platform("androidx.compose:compose-bom:2024.06.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
}
