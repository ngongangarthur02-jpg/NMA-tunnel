# NMA Tunnel

Application Android (Kotlin + Jetpack Compose) : client VPN VLESS au thème **bleu marine**,
avec le moteur Xray (libv2ray) pour une vraie connexion.

## Fonctions
- Import de liens `vless://` (onglet Servers → + Importer), plusieurs liens à la fois
- Vraie connexion via Xray (TCP, WebSocket, gRPC, HTTPUpgrade, XHTTP ; TLS et REALITY)
- Trafic Download / Upload en direct (MB et Kbps)
- Ping de chaque serveur (onglet Servers, bouton ↻) et ping dans le tunnel quand connecté
- Détection automatique : avant de se connecter, l'application teste le serveur importé ;
  si la configuration d'origine ne répond pas, elle essaie des variantes (empreinte TLS,
  ALPN, ports usuels) et garde la première qui passe (`vpn/AutoDetect.kt`)
- Logs de connexion

## Compiler
Le fichier `app/libs/libv2ray.aar` (moteur Xray, ~60 Mo) est téléchargé automatiquement
par Gradle au premier build (internet requis). Rien à ajouter à la main.

- **Android Studio** (JDK 17) : ouvrir le dossier, `Build > Build APK(s)`.
- **GitHub Actions** : voir `.github/workflows/build.yml`.

## Structure
- `vpn/NmaVpnService.kt` : service VPN, démarre/arrête Xray, lit le trafic et le ping
- `vpn/XrayConfig.kt` : transforme un lien VLESS en configuration Xray
- `vpn/TunnelState.kt` : état partagé (statut, trafic, ping, logs)
- `model/Vless.kt`, `model/Ping.kt`, `model/ServerStore.kt` : liens, ping, sauvegarde
- `MainActivity.kt` : écrans Home, Servers, Logs, More
