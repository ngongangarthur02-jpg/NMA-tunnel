# NMA Tunnel

Application Android (Kotlin + Jetpack Compose) avec l'interface de type « tunnel VPN » en thème **bleu marine**.

## Ouvrir et compiler
1. Installer Android Studio (Koala ou plus récent) avec JDK 17.
2. `File > Open` → choisir le dossier `NMATunnel`.
3. Laisser Gradle synchroniser, puis `Run` sur un téléphone ou `Build > Build APK(s)`.

## Structure
- `app/src/main/java/com/nma/tunnel/MainActivity.kt` : écrans Home, Servers, Logs, More
- `app/src/main/java/com/nma/tunnel/ui/theme/Theme.kt` : couleurs bleu marine
- `app/src/main/java/com/nma/tunnel/vpn/NmaVpnService.kt` : service VPN (interface TUN)
- `app/src/main/res` : icône, thème, textes

## Important
Le service ouvre l'interface VPN d'Android, mais ne route pas encore le trafic vers un
serveur VLESS. Pour cela, il faut intégrer un cœur Xray / libv2ray dans `NmaVpnService`
et ajouter la configuration de vos serveurs (liste `servers` dans `MainActivity.kt`).
Les compteurs Download/Upload et le ping sont des valeurs d'affichage pour l'instant.
