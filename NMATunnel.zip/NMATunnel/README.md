# NMA Tunnel v1.3
Application VPN Android (Kotlin / Jetpack Compose, cœur Xray).

Nouveautés 1.3 : ID d'appareil (More > My public key), configurations verrouillées par appareil,
ajout manuel (V2Ray : VMess, VLESS, Trojan, Shadowsocks, SOCKS, HTTP, WireGuard, Hysteria2, JSON ; SSH : 8 modes),
crayon de modification (configs déverrouillées), thème clair/sombre/auto, interface adaptative, Host pot (proxy SOCKS5/HTTP).

Compilation : envoyer le zip sur GitHub, le workflow publie NMA-Tunnel.apk dans Releases.
Limites : SSH-DNSTT non pris en charge ; TLS des modes SSH ne vérifie pas les certificats.
